import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';
import Button from './Button';

const NotificationCenter = ({ isOpen, onClose, notifications = [] }) => {
  const [localNotifications, setLocalNotifications] = useState([
    {
      id: 1,
      type: 'representative',
      title: 'New Update from MP Sharma',
      message: 'Posted about infrastructure development in your constituency',
      time: '2 hours ago',
      unread: true,
      category: 'Representative Updates'
    },
    {
      id: 2,
      type: 'issue',
      title: 'Issue Status Update',
      message: 'Your reported pothole issue has been acknowledged by local authorities',
      time: '1 day ago',
      unread: true,
      category: 'Issue Reports'
    },
    {
      id: 3,
      type: 'community',
      title: 'Community Discussion',
      message: 'New discussion about local water supply started in your area',
      time: '2 days ago',
      unread: false,
      category: 'Community'
    },
    {
      id: 4,
      type: 'system',
      title: 'Profile Update Required',
      message: 'Please update your constituency information for better service',
      time: '3 days ago',
      unread: false,
      category: 'System'
    },
    {
      id: 5,
      type: 'representative',
      title: 'MLA Office Hours',
      message: 'Your local MLA will be available for public meetings this Friday',
      time: '1 week ago',
      unread: false,
      category: 'Representative Updates'
    }
  ]);

  const [filter, setFilter] = useState('all');

  const notificationData = notifications.length > 0 ? notifications : localNotifications;

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'representative':
        return 'Users';
      case 'issue':
        return 'AlertTriangle';
      case 'community':
        return 'MessageSquare';
      case 'system':
        return 'Settings';
      default:
        return 'Bell';
    }
  };

  const getNotificationColor = (type) => {
    switch (type) {
      case 'representative':
        return 'text-primary';
      case 'issue':
        return 'text-warning';
      case 'community':
        return 'text-accent';
      case 'system':
        return 'text-muted-foreground';
      default:
        return 'text-muted-foreground';
    }
  };

  const filteredNotifications = filter === 'all' 
    ? notificationData 
    : notificationData.filter(n => n.type === filter);

  const unreadCount = notificationData.filter(n => n.unread).length;

  const markAsRead = (id) => {
    setLocalNotifications(prev => 
      prev.map(notification => 
        notification.id === id 
          ? { ...notification, unread: false }
          : notification
      )
    );
  };

  const markAllAsRead = () => {
    setLocalNotifications(prev => 
      prev.map(notification => ({ ...notification, unread: false }))
    );
  };

  const clearNotification = (id) => {
    setLocalNotifications(prev => 
      prev.filter(notification => notification.id !== id)
    );
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (isOpen && !event.target.closest('.notification-center')) {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="notification-center absolute right-0 top-12 w-96 bg-popover border border-border rounded-lg shadow-civic-lg z-notification">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-semibold text-foreground">
            Notifications
            {unreadCount > 0 && (
              <span className="ml-2 bg-destructive text-destructive-foreground text-xs rounded-full px-2 py-1 font-caption">
                {unreadCount} new
              </span>
            )}
          </h3>
          <div className="flex items-center space-x-2">
            {unreadCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={markAllAsRead}
                className="text-xs"
              >
                Mark all read
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
            >
              <Icon name="X" size={16} />
            </Button>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center space-x-1 mt-3">
          {['all', 'representative', 'issue', 'community', 'system'].map((filterType) => (
            <button
              key={filterType}
              onClick={() => setFilter(filterType)}
              className={`px-3 py-1 text-xs rounded-full font-caption transition-civic ${
                filter === filterType
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              {filterType === 'all' ? 'All' : filterType.charAt(0).toUpperCase() + filterType.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Notifications List */}
      <div className="max-h-96 overflow-y-auto">
        {filteredNotifications.length === 0 ? (
          <div className="p-8 text-center">
            <Icon name="Bell" size={48} className="text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground font-body">No notifications found</p>
          </div>
        ) : (
          filteredNotifications.map((notification) => (
            <div
              key={notification.id}
              className={`p-4 border-b border-border hover:bg-muted cursor-pointer transition-civic group ${
                notification.unread ? 'bg-accent/5' : ''
              }`}
              onClick={() => markAsRead(notification.id)}
            >
              <div className="flex items-start space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  notification.unread ? 'bg-accent/10' : 'bg-muted'
                }`}>
                  <Icon 
                    name={getNotificationIcon(notification.type)} 
                    size={16} 
                    className={getNotificationColor(notification.type)}
                  />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-body font-semibold text-sm text-foreground">
                        {notification.title}
                      </h4>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                        {notification.message}
                      </p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-muted-foreground">
                          {notification.time}
                        </span>
                        <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                          {notification.category}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-1 ml-2">
                      {notification.unread && (
                        <div className="w-2 h-2 bg-accent rounded-full" />
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={(e) => {
                          e.stopPropagation();
                          clearNotification(notification.id);
                        }}
                        className="opacity-0 group-hover:opacity-100 transition-civic w-6 h-6"
                      >
                        <Icon name="X" size={12} />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer */}
      {filteredNotifications.length > 0 && (
        <div className="p-4 border-t border-border">
          <Button variant="ghost" size="sm" className="w-full">
            View All Notifications
          </Button>
        </div>
      )}
    </div>
  );
};

export default NotificationCenter;