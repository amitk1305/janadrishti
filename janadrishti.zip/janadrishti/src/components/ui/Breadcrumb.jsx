import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const Breadcrumb = ({ items = [] }) => {
  const location = useLocation();

  // Auto-generate breadcrumbs based on current path if no items provided
  const generateBreadcrumbs = () => {
    const pathMap = {
      '/civic-dashboard': { label: 'Dashboard', path: '/civic-dashboard' },
      '/political-representatives-directory': { label: 'Representatives', path: '/political-representatives-directory' },
      '/representative-profile-details': [
        { label: 'Representatives', path: '/political-representatives-directory' },
        { label: 'Profile Details', path: '/representative-profile-details' }
      ],
      '/civic-issue-reporting': { label: 'Report Issue', path: '/civic-issue-reporting' },
      '/user-profile-settings': { label: 'Profile Settings', path: '/user-profile-settings' }
    };

    const currentPath = location.pathname;
    const breadcrumbData = pathMap[currentPath];

    if (Array.isArray(breadcrumbData)) {
      return breadcrumbData;
    } else if (breadcrumbData) {
      return [breadcrumbData];
    }

    return [];
  };

  const breadcrumbItems = items.length > 0 ? items : generateBreadcrumbs();
  const isAuthPage = location.pathname === '/user-registration-login';

  // Don't show breadcrumbs on auth page or dashboard (home page)
  if (isAuthPage || location.pathname === '/civic-dashboard' || breadcrumbItems.length <= 1) {
    return null;
  }

  return (
    <nav className="flex items-center space-x-2 text-sm font-body mb-6" aria-label="Breadcrumb">
      <Link
        to="/civic-dashboard"
        className="text-muted-foreground hover:text-foreground transition-civic flex items-center"
      >
        <Icon name="Home" size={16} className="mr-1" />
        Home
      </Link>
      
      {breadcrumbItems.map((item, index) => {
        const isLast = index === breadcrumbItems.length - 1;
        
        return (
          <React.Fragment key={item.path || index}>
            <Icon name="ChevronRight" size={16} className="text-muted-foreground" />
            {isLast ? (
              <span className="text-foreground font-medium" aria-current="page">
                {item.label}
              </span>
            ) : (
              <Link
                to={item.path}
                className="text-muted-foreground hover:text-foreground transition-civic"
              >
                {item.label}
              </Link>
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
};

export default Breadcrumb;