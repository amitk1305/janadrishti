import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = () => {
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const notifications = [
    {
      id: 1,
      type: 'representative',
      title: 'New Update from MP Sharma',
      message: 'Posted about infrastructure development in your constituency',
      time: '2 hours ago',
      unread: true
    },
    {
      id: 2,
      type: 'issue',
      title: 'Issue Status Update',
      message: 'Your reported pothole issue has been acknowledged',
      time: '1 day ago',
      unread: true
    },
    {
      id: 3,
      type: 'community',
      title: 'Community Discussion',
      message: 'New discussion about local water supply started',
      time: '2 days ago',
      unread: false
    }
  ];

  const unreadCount = notifications.filter(n => n.unread).length;

  const handleNotificationClick = () => {
    setIsNotificationOpen(!isNotificationOpen);
    setIsProfileOpen(false);
  };

  const handleProfileClick = () => {
    setIsProfileOpen(!isProfileOpen);
    setIsNotificationOpen(false);
  };

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const isAuthPage = location.pathname === '/user-registration-login';

  if (isAuthPage) {
    return null;
  }

  return (
    <>
      <header className="fixed top-0 left-0 right-0 bg-card border-b border-border z-header">
        <div className="flex items-center justify-between h-16 px-4 lg:px-6">
          {/* Logo */}
          <Link to="/civic-dashboard" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Icon name="Vote" size={20} color="white" />
            </div>
            <span className="font-heading font-bold text-xl text-foreground">
              Janadrishti
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            {/* Search */}
            <div className="relative">
              <Icon 
                name="Search" 
                size={20} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
              />
              <input
                type="text"
                placeholder="Search representatives, issues..."
                className="pl-10 pr-4 py-2 w-80 bg-muted border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent font-body"
              />
            </div>

            {/* Notifications */}
            <div className="relative">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleNotificationClick}
                className="relative"
              >
                <Icon name="Bell" size={20} />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center font-caption">
                    {unreadCount}
                  </span>
                )}
              </Button>

              {/* Notification Dropdown */}
              {isNotificationOpen && (
                <div className="absolute right-0 top-12 w-80 bg-popover border border-border rounded-lg shadow-civic-lg z-dropdown">
                  <div className="p-4 border-b border-border">
                    <h3 className="font-heading font-semibold text-foreground">Notifications</h3>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    {notifications.map((notification) => (
                      <div
                        key={notification.id}
                        className={`p-4 border-b border-border hover:bg-muted cursor-pointer transition-civic ${
                          notification.unread ? 'bg-accent/5' : ''
                        }`}
                      >
                        <div className="flex items-start space-x-3">
                          <div className={`w-2 h-2 rounded-full mt-2 ${
                            notification.unread ? 'bg-accent' : 'bg-muted-foreground'
                          }`} />
                          <div className="flex-1">
                            <h4 className="font-body font-semibold text-sm text-foreground">
                              {notification.title}
                            </h4>
                            <p className="text-sm text-muted-foreground mt-1">
                              {notification.message}
                            </p>
                            <span className="text-xs text-muted-foreground mt-2 block">
                              {notification.time}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="p-4 border-t border-border">
                    <Button variant="ghost" size="sm" className="w-full">
                      View All Notifications
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* Profile */}
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleProfileClick}
                className="flex items-center space-x-2"
              >
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <Icon name="User" size={16} color="white" />
                </div>
                <span className="font-body text-sm text-foreground">Profile</span>
                <Icon name="ChevronDown" size={16} />
              </Button>

              {/* Profile Dropdown */}
              {isProfileOpen && (
                <div className="absolute right-0 top-12 w-48 bg-popover border border-border rounded-lg shadow-civic-lg z-dropdown">
                  <div className="p-2">
                    <Link
                      to="/user-profile-settings"
                      className="flex items-center space-x-2 px-3 py-2 text-sm text-foreground hover:bg-muted rounded-md transition-civic"
                    >
                      <Icon name="Settings" size={16} />
                      <span className="font-body">Settings</span>
                    </Link>
                    <button className="flex items-center space-x-2 px-3 py-2 text-sm text-foreground hover:bg-muted rounded-md transition-civic w-full text-left">
                      <Icon name="LogOut" size={16} />
                      <span className="font-body">Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleMobileMenuToggle}
            >
              <Icon name={isMobileMenuOpen ? "X" : "Menu"} size={24} />
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-card border-t border-border z-mobile-menu">
            <div className="p-4 space-y-4">
              {/* Mobile Search */}
              <div className="relative">
                <Icon 
                  name="Search" 
                  size={20} 
                  className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
                />
                <input
                  type="text"
                  placeholder="Search..."
                  className="pl-10 pr-4 py-2 w-full bg-muted border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent font-body"
                />
              </div>

              {/* Mobile Notifications */}
              <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                <div className="flex items-center space-x-3">
                  <Icon name="Bell" size={20} />
                  <span className="font-body text-foreground">Notifications</span>
                </div>
                {unreadCount > 0 && (
                  <span className="bg-destructive text-destructive-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center font-caption">
                    {unreadCount}
                  </span>
                )}
              </div>

              {/* Mobile Profile */}
              <Link
                to="/user-profile-settings"
                className="flex items-center space-x-3 p-3 bg-muted rounded-lg"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <Icon name="User" size={16} color="white" />
                </div>
                <span className="font-body text-foreground">Profile Settings</span>
              </Link>
            </div>
          </div>
        )}
      </header>

      {/* Overlay for mobile menu */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-modal lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </>
  );
};

export default Header;