import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const Navigation = () => {
  const location = useLocation();

  const navigationItems = [
    {
      label: 'Dashboard',
      path: '/civic-dashboard',
      icon: 'LayoutDashboard',
      badge: null
    },
    {
      label: 'Representatives',
      path: '/political-representatives-directory',
      icon: 'Users',
      badge: null
    },
    {
      label: 'Report Issue',
      path: '/civic-issue-reporting',
      icon: 'AlertTriangle',
      badge: 3
    },
    {
      label: 'Profile',
      path: '/user-profile-settings',
      icon: 'User',
      badge: null
    }
  ];

  const isAuthPage = location.pathname === '/user-registration-login';

  if (isAuthPage) {
    return null;
  }

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden lg:block fixed top-16 left-0 right-0 bg-card border-b border-border z-50">
        <div className="flex items-center justify-center h-14">
          <div className="flex items-center space-x-8">
            {navigationItems.map((item) => {
              const isActive = location.pathname === item.path || 
                (item.path === '/political-representatives-directory' && 
                 location.pathname === '/representative-profile-details');
              
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-civic relative ${
                    isActive
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }`}
                >
                  <Icon 
                    name={item.icon} 
                    size={20} 
                    color={isActive ? 'currentColor' : 'currentColor'}
                  />
                  <span className="font-body font-medium">{item.label}</span>
                  {item.badge && (
                    <span className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center font-caption">
                      {item.badge}
                    </span>
                  )}
                </Link>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50">
        <div className="flex items-center justify-around h-16 px-2">
          {navigationItems.map((item) => {
            const isActive = location.pathname === item.path || 
              (item.path === '/political-representatives-directory' && 
               location.pathname === '/representative-profile-details');
            
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center justify-center min-h-touch px-3 py-2 rounded-lg transition-civic relative ${
                  isActive
                    ? 'text-primary' :'text-muted-foreground'
                }`}
              >
                <Icon 
                  name={item.icon} 
                  size={20} 
                  color="currentColor"
                />
                <span className="font-caption text-xs mt-1 font-medium">
                  {item.label}
                </span>
                {item.badge && (
                  <span className="absolute top-1 right-2 bg-destructive text-destructive-foreground text-xs rounded-full w-4 h-4 flex items-center justify-center font-caption">
                    {item.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </div>
      </nav>
    </>
  );
};

export default Navigation;