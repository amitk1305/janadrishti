import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
// Add your imports here
import UserRegistrationLogin from "pages/user-registration-login";
import PoliticalRepresentativesDirectory from "pages/political-representatives-directory";
import CivicDashboard from "pages/civic-dashboard";
import CivicIssueReporting from "pages/civic-issue-reporting";
import UserProfileSettings from "pages/user-profile-settings";
import RepresentativeProfileDetails from "pages/representative-profile-details";
import NotFound from "pages/NotFound";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your routes here */}
        <Route path="/" element={<CivicDashboard />} />
        <Route path="/user-registration-login" element={<UserRegistrationLogin />} />
        <Route path="/political-representatives-directory" element={<PoliticalRepresentativesDirectory />} />
        <Route path="/civic-dashboard" element={<CivicDashboard />} />
        <Route path="/civic-issue-reporting" element={<CivicIssueReporting />} />
        <Route path="/user-profile-settings" element={<UserProfileSettings />} />
        <Route path="/representative-profile-details" element={<RepresentativeProfileDetails />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;