import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ProfileHeader = ({ user, onPhotoUpdate }) => {
  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);

  const handlePhotoUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        onPhotoUpdate(e.target.result);
        setIsPhotoModalOpen(false);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground p-6 rounded-lg mb-6">
      <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6">
        {/* Profile Photo */}
        <div className="relative">
          <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-primary-foreground/20">
            <Image
              src={user.avatar}
              alt={user.name}
              className="w-full h-full object-cover"
            />
          </div>
          <Button
            variant="secondary"
            size="icon"
            className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full"
            onClick={() => setIsPhotoModalOpen(true)}
          >
            <Icon name="Camera" size={16} />
          </Button>
        </div>

        {/* User Info */}
        <div className="flex-1 text-center sm:text-left">
          <h1 className="text-2xl font-heading font-bold">{user.name}</h1>
          <p className="text-primary-foreground/80 font-body">{user.email}</p>
          <p className="text-primary-foreground/80 font-body">{user.constituency}</p>
          
          {/* Civic Stats */}
          <div className="flex justify-center sm:justify-start space-x-6 mt-4">
            <div className="text-center">
              <div className="text-xl font-heading font-bold">{user.stats.issuesReported}</div>
              <div className="text-xs text-primary-foreground/80 font-caption">Issues Reported</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-heading font-bold">{user.stats.forumPosts}</div>
              <div className="text-xs text-primary-foreground/80 font-caption">Forum Posts</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-heading font-bold">{user.stats.representativesFollowed}</div>
              <div className="text-xs text-primary-foreground/80 font-caption">Following</div>
            </div>
          </div>
        </div>

        {/* Civic Badge */}
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 bg-primary-foreground/20 rounded-full flex items-center justify-center mb-2">
            <Icon name="Award" size={24} className="text-primary-foreground" />
          </div>
          <span className="text-xs text-primary-foreground/80 font-caption">Civic Champion</span>
        </div>
      </div>

      {/* Photo Upload Modal */}
      {isPhotoModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-modal">
          <div className="bg-card p-6 rounded-lg max-w-sm w-full mx-4">
            <h3 className="text-lg font-heading font-semibold text-foreground mb-4">Update Profile Photo</h3>
            <div className="space-y-4">
              <input
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
                id="photo-upload"
              />
              <label htmlFor="photo-upload">
                <Button variant="outline" className="w-full" asChild>
                  <span className="flex items-center justify-center space-x-2">
                    <Icon name="Upload" size={16} />
                    <span>Choose Photo</span>
                  </span>
                </Button>
              </label>
              <Button
                variant="ghost"
                onClick={() => setIsPhotoModalOpen(false)}
                className="w-full"
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfileHeader;