import React, { useState } from 'react';
import { Checkbox } from '../../../components/ui/Checkbox';
import Select from '../../../components/ui/Select';
import Icon from '../../../components/AppIcon';

const NotificationsTab = ({ notificationSettings, onUpdate }) => {
  const [settings, setSettings] = useState(notificationSettings);

  const handleToggle = (category, type, value) => {
    const updatedSettings = {
      ...settings,
      [category]: {
        ...settings[category],
        [type]: value
      }
    };
    setSettings(updatedSettings);
    onUpdate(updatedSettings);
  };

  const handleFrequencyChange = (category, frequency) => {
    const updatedSettings = {
      ...settings,
      [category]: {
        ...settings[category],
        frequency: frequency
      }
    };
    setSettings(updatedSettings);
    onUpdate(updatedSettings);
  };

  const frequencyOptions = [
    { value: 'instant', label: 'Instant' },
    { value: 'daily', label: 'Daily Digest' },
    { value: 'weekly', label: 'Weekly Summary' },
    { value: 'never', label: 'Never' }
  ];

  const notificationCategories = [
    {
      id: 'representatives',
      title: 'Representative Updates',
      description: 'Updates from political representatives you follow',
      icon: 'Users',
      settings: settings.representatives
    },
    {
      id: 'issues',
      title: 'Issue Updates',
      description: 'Status updates on issues you reported or follow',
      icon: 'AlertTriangle',
      settings: settings.issues
    },
    {
      id: 'forums',
      title: 'Forum Activity',
      description: 'Replies and mentions in community discussions',
      icon: 'MessageSquare',
      settings: settings.forums
    },
    {
      id: 'civic',
      title: 'Civic Updates',
      description: 'General civic news and platform announcements',
      icon: 'Bell',
      settings: settings.civic
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <Icon name="Bell" size={24} className="text-primary" />
        <div>
          <h3 className="text-lg font-heading font-semibold text-foreground">Notification Preferences</h3>
          <p className="text-sm text-muted-foreground">Choose how and when you want to be notified</p>
        </div>
      </div>

      {/* Notification Categories */}
      <div className="space-y-6">
        {notificationCategories.map((category) => (
          <div key={category.id} className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Icon name={category.icon} size={24} className="text-primary" />
              </div>
              <div className="flex-1">
                <h4 className="font-body font-semibold text-foreground">{category.title}</h4>
                <p className="text-sm text-muted-foreground mt-1">{category.description}</p>
                
                {/* Notification Types */}
                <div className="mt-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-body text-foreground">Push Notifications</span>
                    <Checkbox
                      checked={category.settings.push}
                      onChange={(e) => handleToggle(category.id, 'push', e.target.checked)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-body text-foreground">Email Notifications</span>
                    <Checkbox
                      checked={category.settings.email}
                      onChange={(e) => handleToggle(category.id, 'email', e.target.checked)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-body text-foreground">SMS Notifications</span>
                    <Checkbox
                      checked={category.settings.sms}
                      onChange={(e) => handleToggle(category.id, 'sms', e.target.checked)}
                    />
                  </div>
                </div>

                {/* Frequency Setting */}
                <div className="mt-4">
                  <Select
                    label="Frequency"
                    options={frequencyOptions}
                    value={category.settings.frequency}
                    onChange={(value) => handleFrequencyChange(category.id, value)}
                    className="max-w-xs"
                  />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quiet Hours */}
      <div className="bg-muted p-4 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Moon" size={20} className="text-muted-foreground mt-1" />
          <div className="flex-1">
            <h4 className="font-body font-semibold text-foreground">Quiet Hours</h4>
            <p className="text-sm text-muted-foreground mt-1">
              Disable push notifications during specific hours
            </p>
            <div className="flex items-center space-x-4 mt-3">
              <Checkbox
                label="Enable quiet hours"
                checked={settings.quietHours.enabled}
                onChange={(e) => handleToggle('quietHours', 'enabled', e.target.checked)}
              />
            </div>
            {settings.quietHours.enabled && (
              <div className="flex items-center space-x-4 mt-3">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-foreground">From:</span>
                  <input
                    type="time"
                    value={settings.quietHours.start}
                    onChange={(e) => handleToggle('quietHours', 'start', e.target.value)}
                    className="px-2 py-1 border border-border rounded text-sm"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-foreground">To:</span>
                  <input
                    type="time"
                    value={settings.quietHours.end}
                    onChange={(e) => handleToggle('quietHours', 'end', e.target.value)}
                    className="px-2 py-1 border border-border rounded text-sm"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Emergency Notifications */}
      <div className="bg-warning/5 border border-warning/20 p-4 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="AlertTriangle" size={20} className="text-warning mt-1" />
          <div>
            <h4 className="font-body font-semibold text-warning">Emergency Notifications</h4>
            <p className="text-sm text-muted-foreground mt-1">
              Critical civic alerts and emergency announcements will always be delivered regardless of your settings.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationsTab;