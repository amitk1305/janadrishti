import React, { useState, useEffect } from 'react';
import Select from '../../../components/ui/Select';

import Icon from '../../../components/AppIcon';

const LanguageSettings = ({ currentLanguage, onLanguageChange }) => {
  const [selectedLanguage, setSelectedLanguage] = useState(currentLanguage);
  const [isChanging, setIsChanging] = useState(false);

  const languageOptions = [
    { value: 'en', label: 'English', nativeName: 'English' },
    { value: 'hi', label: 'Hindi', nativeName: 'हिंदी' }
  ];

  const handleLanguageChange = async (newLanguage) => {
    setIsChanging(true);
    
    // Simulate language change delay
    setTimeout(() => {
      setSelectedLanguage(newLanguage);
      onLanguageChange(newLanguage);
      
      // Save to localStorage
      localStorage.setItem('preferredLanguage', newLanguage);
      
      setIsChanging(false);
    }, 500);
  };

  const getLanguageContent = () => {
    if (selectedLanguage === 'hi') {
      return {
        title: 'भाषा सेटिंग्स',
        description: 'अपनी पसंदीदा भाषा चुनें',
        currentLabel: 'वर्तमान भाषा',
        changeLabel: 'भाषा बदलें',
        applyButton: 'लागू करें',
        note: 'भाषा परिवर्तन तुरंत सभी पृष्ठों पर लागू हो जाएगा।'
      };
    }
    
    return {
      title: 'Language Settings',
      description: 'Choose your preferred language',
      currentLabel: 'Current Language',
      changeLabel: 'Change Language',
      applyButton: 'Apply Changes',
      note: 'Language changes will be applied immediately across all pages.'
    };
  };

  const content = getLanguageContent();

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center space-x-3 mb-4">
        <Icon name="Globe" size={24} className="text-primary" />
        <div>
          <h4 className="font-body font-semibold text-foreground">{content.title}</h4>
          <p className="text-sm text-muted-foreground">{content.description}</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Current Language Display */}
        <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
          <div>
            <span className="text-sm font-body text-foreground">{content.currentLabel}:</span>
            <div className="font-body font-semibold text-foreground">
              {languageOptions.find(lang => lang.value === selectedLanguage)?.nativeName}
            </div>
          </div>
          <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
            <Icon name="Check" size={16} className="text-primary" />
          </div>
        </div>

        {/* Language Selection */}
        <Select
          label={content.changeLabel}
          options={languageOptions.map(lang => ({
            ...lang,
            label: `${lang.label} (${lang.nativeName})`
          }))}
          value={selectedLanguage}
          onChange={handleLanguageChange}
          disabled={isChanging}
        />

        {/* Language Change Status */}
        {isChanging && (
          <div className="flex items-center space-x-2 p-3 bg-accent/5 rounded-lg">
            <Icon name="Loader2" size={16} className="text-accent animate-spin" />
            <span className="text-sm text-accent">
              {selectedLanguage === 'hi' ? 'भाषा बदली जा रही है...' : 'Changing language...'}
            </span>
          </div>
        )}

        {/* Information Note */}
        <div className="bg-primary/5 border border-primary/20 p-3 rounded-lg">
          <div className="flex items-start space-x-2">
            <Icon name="Info" size={16} className="text-primary mt-0.5" />
            <p className="text-sm text-muted-foreground">{content.note}</p>
          </div>
        </div>

        {/* Language Preview */}
        <div className="border border-border rounded-lg p-4">
          <h5 className="font-body font-semibold text-foreground mb-2">
            {selectedLanguage === 'hi' ? 'पूर्वावलोकन' : 'Preview'}
          </h5>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">
                {selectedLanguage === 'hi' ? 'डैशबोर्ड:' : 'Dashboard:'}
              </span>
              <span className="text-foreground">
                {selectedLanguage === 'hi' ? 'डैशबोर्ड' : 'Dashboard'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">
                {selectedLanguage === 'hi' ? 'प्रतिनिधि:' : 'Representatives:'}
              </span>
              <span className="text-foreground">
                {selectedLanguage === 'hi' ? 'प्रतिनिधि' : 'Representatives'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">
                {selectedLanguage === 'hi' ? 'समस्या रिपोर्ट:' : 'Report Issue:'}
              </span>
              <span className="text-foreground">
                {selectedLanguage === 'hi' ? 'समस्या रिपोर्ट करें' : 'Report Issue'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LanguageSettings;