import React, { useState } from 'react';
import { Checkbox } from '../../../components/ui/Checkbox';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const PrivacyTab = ({ privacySettings, onUpdate }) => {
  const [settings, setSettings] = useState(privacySettings);

  const handleToggle = (setting, value) => {
    const updatedSettings = {
      ...settings,
      [setting]: value
    };
    setSettings(updatedSettings);
    onUpdate(updatedSettings);
  };

  const privacyOptions = [
    {
      id: 'profileVisibility',
      title: 'Public Profile',
      description: 'Allow other users to view your profile information',
      icon: 'Eye',
      checked: settings.profileVisibility
    },
    {
      id: 'showActivity',
      title: 'Show Activity',
      description: 'Display your civic activities like issues reported and forum posts',
      icon: 'Activity',
      checked: settings.showActivity
    },
    {
      id: 'showLocation',
      title: 'Show Location',
      description: 'Display your constituency and state information',
      icon: 'MapPin',
      checked: settings.showLocation
    },
    {
      id: 'allowMessages',
      title: 'Allow Messages',
      description: 'Let other users send you direct messages',
      icon: 'MessageSquare',
      checked: settings.allowMessages
    },
    {
      id: 'anonymousReporting',
      title: 'Anonymous Reporting',
      description: 'Report issues anonymously without revealing your identity',
      icon: 'UserX',
      checked: settings.anonymousReporting
    },
    {
      id: 'dataSharing',
      title: 'Data Sharing',
      description: 'Share anonymized data for civic research and analytics',
      icon: 'Share2',
      checked: settings.dataSharing
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <Icon name="Shield" size={24} className="text-primary" />
        <div>
          <h3 className="text-lg font-heading font-semibold text-foreground">Privacy Settings</h3>
          <p className="text-sm text-muted-foreground">Control how your information is shared and displayed</p>
        </div>
      </div>

      {/* Privacy Options */}
      <div className="space-y-4">
        {privacyOptions.map((option) => (
          <div key={option.id} className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center flex-shrink-0">
                <Icon name={option.icon} size={20} className="text-muted-foreground" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-body font-semibold text-foreground">{option.title}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{option.description}</p>
                  </div>
                  <Checkbox
                    checked={option.checked}
                    onChange={(e) => handleToggle(option.id, e.target.checked)}
                  />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Data Export Section */}
      <div className="bg-muted p-4 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Download" size={20} className="text-primary mt-1" />
          <div className="flex-1">
            <h4 className="font-body font-semibold text-foreground">Data Export</h4>
            <p className="text-sm text-muted-foreground mt-1">
              Download a copy of all your data including profile information, reported issues, and forum activities.
            </p>
            <Button
              variant="outline"
              size="sm"
              className="mt-3"
              iconName="Download"
              iconPosition="left"
            >
              Request Data Export
            </Button>
          </div>
        </div>
      </div>

      {/* Account Deletion Section */}
      <div className="bg-destructive/5 border border-destructive/20 p-4 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="AlertTriangle" size={20} className="text-destructive mt-1" />
          <div className="flex-1">
            <h4 className="font-body font-semibold text-destructive">Delete Account</h4>
            <p className="text-sm text-muted-foreground mt-1">
              Permanently delete your account and all associated data. This action cannot be undone.
            </p>
            <Button
              variant="destructive"
              size="sm"
              className="mt-3"
              iconName="Trash2"
              iconPosition="left"
            >
              Delete Account
            </Button>
          </div>
        </div>
      </div>

      {/* Privacy Tips */}
      <div className="bg-accent/5 border border-accent/20 p-4 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={20} className="text-accent mt-1" />
          <div>
            <h4 className="font-body font-semibold text-accent">Privacy Tips</h4>
            <ul className="text-sm text-muted-foreground mt-2 space-y-1">
              <li>• Use anonymous reporting for sensitive civic issues</li>
              <li>• Regularly review your privacy settings</li>
              <li>• Be mindful of personal information in forum posts</li>
              <li>• Report any privacy concerns to our support team</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyTab;