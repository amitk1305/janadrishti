import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';


const ActivityTab = ({ activityData }) => {
  const [filter, setFilter] = useState('all');
  const [timeRange, setTimeRange] = useState('month');

  const filterOptions = [
    { value: 'all', label: 'All Activity' },
    { value: 'issues', label: 'Issues Reported' },
    { value: 'forums', label: 'Forum Posts' },
    { value: 'ratings', label: 'Representative Ratings' },
    { value: 'follows', label: 'Following Activity' }
  ];

  const timeRangeOptions = [
    { value: 'week', label: 'Last Week' },
    { value: 'month', label: 'Last Month' },
    { value: 'quarter', label: 'Last 3 Months' },
    { value: 'year', label: 'Last Year' },
    { value: 'all', label: 'All Time' }
  ];

  const activities = [
    {
      id: 1,
      type: 'issue',
      title: 'Reported pothole issue on MG Road',
      description: 'Issue has been acknowledged by local authorities',
      timestamp: '2 hours ago',
      status: 'acknowledged',
      icon: 'AlertTriangle',
      color: 'text-warning'
    },
    {
      id: 2,
      type: 'forum',
      title: 'Commented on water supply discussion',
      description: 'Your comment received 12 upvotes',
      timestamp: '1 day ago',
      status: 'active',
      icon: 'MessageSquare',
      color: 'text-accent'
    },
    {
      id: 3,
      type: 'rating',
      title: 'Rated MP Sharma\'s performance',
      description: 'Gave 4 stars for infrastructure development',
      timestamp: '3 days ago',
      status: 'completed',
      icon: 'Star',
      color: 'text-primary'
    },
    {
      id: 4,
      type: 'follow',
      title: 'Started following MLA Patel',
      description: 'You will receive updates about their activities',
      timestamp: '1 week ago',
      status: 'active',
      icon: 'UserPlus',
      color: 'text-accent'
    },
    {
      id: 5,
      type: 'issue',
      title: 'Reported street light issue',
      description: 'Issue has been resolved by municipal corporation',
      timestamp: '2 weeks ago',
      status: 'resolved',
      icon: 'CheckCircle',
      color: 'text-success'
    },
    {
      id: 6,
      type: 'forum',
      title: 'Created discussion about park maintenance',
      description: 'Discussion has 25 replies and 45 views',
      timestamp: '3 weeks ago',
      status: 'active',
      icon: 'MessageSquare',
      color: 'text-accent'
    }
  ];

  const filteredActivities = filter === 'all' 
    ? activities 
    : activities.filter(activity => activity.type === filter.replace('s', ''));

  const getStatusBadge = (status) => {
    const statusConfig = {
      'acknowledged': { color: 'bg-warning/10 text-warning', label: 'Acknowledged' },
      'resolved': { color: 'bg-success/10 text-success', label: 'Resolved' },
      'active': { color: 'bg-accent/10 text-accent', label: 'Active' },
      'completed': { color: 'bg-primary/10 text-primary', label: 'Completed' }
    };

    const config = statusConfig[status] || statusConfig.active;
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-caption ${config.color}`}>
        {config.label}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <Icon name="Activity" size={24} className="text-primary" />
        <div>
          <h3 className="text-lg font-heading font-semibold text-foreground">Civic Activity</h3>
          <p className="text-sm text-muted-foreground">Your engagement history and contributions</p>
        </div>
      </div>

      {/* Activity Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <div className="text-2xl font-heading font-bold text-primary">{activityData.totalIssues}</div>
          <div className="text-sm text-muted-foreground font-caption">Issues Reported</div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <div className="text-2xl font-heading font-bold text-accent">{activityData.forumPosts}</div>
          <div className="text-sm text-muted-foreground font-caption">Forum Posts</div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <div className="text-2xl font-heading font-bold text-warning">{activityData.ratingsGiven}</div>
          <div className="text-sm text-muted-foreground font-caption">Ratings Given</div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <div className="text-2xl font-heading font-bold text-success">{activityData.following}</div>
          <div className="text-sm text-muted-foreground font-caption">Following</div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
        <Select
          label="Filter by type"
          options={filterOptions}
          value={filter}
          onChange={setFilter}
          className="sm:max-w-xs"
        />
        <Select
          label="Time range"
          options={timeRangeOptions}
          value={timeRange}
          onChange={setTimeRange}
          className="sm:max-w-xs"
        />
      </div>

      {/* Activity Timeline */}
      <div className="space-y-4">
        {filteredActivities.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="Activity" size={48} className="text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground font-body">No activity found for the selected filters</p>
          </div>
        ) : (
          filteredActivities.map((activity, index) => (
            <div key={activity.id} className="bg-card border border-border rounded-lg p-4">
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                  <Icon name={activity.icon} size={20} className={activity.color} />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-body font-semibold text-foreground">{activity.title}</h4>
                      <p className="text-sm text-muted-foreground mt-1">{activity.description}</p>
                      <div className="flex items-center space-x-3 mt-2">
                        <span className="text-xs text-muted-foreground">{activity.timestamp}</span>
                        {getStatusBadge(activity.status)}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Load More */}
      {filteredActivities.length > 0 && (
        <div className="text-center">
          <Button variant="outline" iconName="ChevronDown" iconPosition="right">
            Load More Activity
          </Button>
        </div>
      )}

      {/* Activity Insights */}
      <div className="bg-accent/5 border border-accent/20 p-4 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="TrendingUp" size={20} className="text-accent mt-1" />
          <div>
            <h4 className="font-body font-semibold text-accent">Your Impact</h4>
            <p className="text-sm text-muted-foreground mt-1">
              You've been actively contributing to civic discussions. Your reported issues have helped improve 3 local problems, 
              and your forum posts have received 127 total upvotes from the community.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ActivityTab;