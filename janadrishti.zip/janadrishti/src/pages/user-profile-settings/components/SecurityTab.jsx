import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';
import Icon from '../../../components/AppIcon';

const SecurityTab = ({ securitySettings, onUpdate }) => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(securitySettings.twoFactorEnabled);
  const [errors, setErrors] = useState({});
  const [showPasswords, setShowPasswords] = useState(false);

  const loginHistory = [
    {
      id: 1,
      device: 'Chrome on Windows',
      location: 'Mumbai, Maharashtra',
      timestamp: '2 hours ago',
      current: true,
      ip: '192.168.1.1'
    },
    {
      id: 2,
      device: 'Mobile App on Android',
      location: 'Mumbai, Maharashtra',
      timestamp: '1 day ago',
      current: false,
      ip: '192.168.1.2'
    },
    {
      id: 3,
      device: 'Safari on iPhone',
      location: 'Mumbai, Maharashtra',
      timestamp: '3 days ago',
      current: false,
      ip: '192.168.1.3'
    },
    {
      id: 4,
      device: 'Chrome on Windows',
      location: 'Pune, Maharashtra',
      timestamp: '1 week ago',
      current: false,
      ip: '192.168.2.1'
    }
  ];

  const validatePasswordChange = () => {
    const newErrors = {};

    if (!currentPassword) {
      newErrors.currentPassword = 'Current password is required';
    }

    if (!newPassword) {
      newErrors.newPassword = 'New password is required';
    } else if (newPassword.length < 8) {
      newErrors.newPassword = 'Password must be at least 8 characters';
    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(newPassword)) {
      newErrors.newPassword = 'Password must contain uppercase, lowercase, and number';
    }

    if (!confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (newPassword !== confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handlePasswordChange = () => {
    if (validatePasswordChange()) {
      onUpdate({
        ...securitySettings,
        passwordLastChanged: new Date().toISOString()
      });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setErrors({});
    }
  };

  const handleTwoFactorToggle = (enabled) => {
    setTwoFactorEnabled(enabled);
    onUpdate({
      ...securitySettings,
      twoFactorEnabled: enabled
    });
  };

  const getDeviceIcon = (device) => {
    if (device.includes('Mobile') || device.includes('iPhone') || device.includes('Android')) {
      return 'Smartphone';
    } else if (device.includes('Chrome') || device.includes('Safari') || device.includes('Firefox')) {
      return 'Monitor';
    }
    return 'Laptop';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <Icon name="Shield" size={24} className="text-primary" />
        <div>
          <h3 className="text-lg font-heading font-semibold text-foreground">Security Settings</h3>
          <p className="text-sm text-muted-foreground">Manage your account security and access</p>
        </div>
      </div>

      {/* Password Change */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h4 className="font-body font-semibold text-foreground mb-4">Change Password</h4>
        <div className="space-y-4">
          <Input
            label="Current Password"
            type={showPasswords ? "text" : "password"}
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            error={errors.currentPassword}
            required
          />
          
          <Input
            label="New Password"
            type={showPasswords ? "text" : "password"}
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            error={errors.newPassword}
            description="Must be at least 8 characters with uppercase, lowercase, and number"
            required
          />
          
          <Input
            label="Confirm New Password"
            type={showPasswords ? "text" : "password"}
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            error={errors.confirmPassword}
            required
          />

          <Checkbox
            label="Show passwords"
            checked={showPasswords}
            onChange={(e) => setShowPasswords(e.target.checked)}
          />

          <Button
            variant="default"
            onClick={handlePasswordChange}
            iconName="Key"
            iconPosition="left"
          >
            Update Password
          </Button>
        </div>
      </div>

      {/* Two-Factor Authentication */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-start space-x-4">
          <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
            <Icon name="Smartphone" size={24} className="text-accent" />
          </div>
          <div className="flex-1">
            <h4 className="font-body font-semibold text-foreground">Two-Factor Authentication</h4>
            <p className="text-sm text-muted-foreground mt-1">
              Add an extra layer of security to your account with SMS or authenticator app
            </p>
            <div className="flex items-center justify-between mt-4">
              <span className="text-sm font-body text-foreground">
                Status: {twoFactorEnabled ? 'Enabled' : 'Disabled'}
              </span>
              <Checkbox
                checked={twoFactorEnabled}
                onChange={(e) => handleTwoFactorToggle(e.target.checked)}
              />
            </div>
            {twoFactorEnabled && (
              <div className="mt-4 p-3 bg-accent/5 rounded-lg">
                <p className="text-sm text-accent">
                  Two-factor authentication is active. You'll receive SMS codes at +91-9876543210
                </p>
                <Button variant="outline" size="sm" className="mt-2">
                  Change Phone Number
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Login History */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-body font-semibold text-foreground">Recent Login Activity</h4>
          <Button variant="outline" size="sm" iconName="RefreshCw" iconPosition="left">
            Refresh
          </Button>
        </div>
        
        <div className="space-y-4">
          {loginHistory.map((login) => (
            <div key={login.id} className="flex items-center space-x-4 p-3 bg-muted rounded-lg">
              <div className="w-10 h-10 bg-background rounded-lg flex items-center justify-center">
                <Icon name={getDeviceIcon(login.device)} size={20} className="text-muted-foreground" />
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <span className="font-body font-medium text-foreground">{login.device}</span>
                  {login.current && (
                    <span className="bg-accent text-accent-foreground text-xs px-2 py-1 rounded-full font-caption">
                      Current
                    </span>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">{login.location} • {login.timestamp}</p>
                <p className="text-xs text-muted-foreground">IP: {login.ip}</p>
              </div>
              {!login.current && (
                <Button variant="ghost" size="sm" className="text-destructive">
                  Revoke
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Security Recommendations */}
      <div className="bg-warning/5 border border-warning/20 p-4 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="AlertTriangle" size={20} className="text-warning mt-1" />
          <div>
            <h4 className="font-body font-semibold text-warning">Security Recommendations</h4>
            <ul className="text-sm text-muted-foreground mt-2 space-y-1">
              <li>• Enable two-factor authentication for better security</li>
              <li>• Use a strong, unique password for your account</li>
              <li>• Regularly review your login activity</li>
              <li>• Log out from devices you no longer use</li>
              <li>• Keep your contact information updated</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityTab;