import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Navigation from '../../components/ui/Navigation';
import Breadcrumb from '../../components/ui/Breadcrumb';
import ProfileHeader from './components/ProfileHeader';
import PersonalInfoTab from './components/PersonalInfoTab';
import PrivacyTab from './components/PrivacyTab';
import NotificationsTab from './components/NotificationsTab';
import ActivityTab from './components/ActivityTab';
import SecurityTab from './components/SecurityTab';
import LanguageSettings from './components/LanguageSettings';
import Icon from '../../components/AppIcon';

const UserProfileSettings = () => {
  const [activeTab, setActiveTab] = useState('personal');
  const [currentLanguage, setCurrentLanguage] = useState('en');

  // Mock user data
  const [userData, setUserData] = useState({
    name: "Rajesh Kumar",
    email: "rajesh.kumar@email.com",
    phone: "+91-9876543210",
    dateOfBirth: "1985-06-15",
    gender: "male",
    constituency: "Bandra East",
    state: "maharashtra",
    pincode: "400051",
    bio: "Active citizen passionate about civic issues and community development. Working in IT sector and volunteering for local environmental initiatives.",
    occupation: "Software Engineer",
    education: "B.Tech Computer Science",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    stats: {
      issuesReported: 12,
      forumPosts: 28,
      representativesFollowed: 5
    }
  });

  // Mock privacy settings
  const [privacySettings, setPrivacySettings] = useState({
    profileVisibility: true,
    showActivity: true,
    showLocation: true,
    allowMessages: true,
    anonymousReporting: false,
    dataSharing: true
  });

  // Mock notification settings
  const [notificationSettings, setNotificationSettings] = useState({
    representatives: {
      push: true,
      email: true,
      sms: false,
      frequency: 'daily'
    },
    issues: {
      push: true,
      email: true,
      sms: true,
      frequency: 'instant'
    },
    forums: {
      push: true,
      email: false,
      sms: false,
      frequency: 'daily'
    },
    civic: {
      push: true,
      email: true,
      sms: false,
      frequency: 'weekly'
    },
    quietHours: {
      enabled: true,
      start: '22:00',
      end: '08:00'
    }
  });

  // Mock security settings
  const [securitySettings, setSecuritySettings] = useState({
    twoFactorEnabled: false,
    passwordLastChanged: '2024-06-01T10:30:00Z',
    loginNotifications: true
  });

  // Mock activity data
  const activityData = {
    totalIssues: 12,
    forumPosts: 28,
    ratingsGiven: 8,
    following: 5
  };

  const tabs = [
    {
      id: 'personal',
      label: currentLanguage === 'hi' ? 'व्यक्तिगत जानकारी' : 'Personal Info',
      icon: 'User'
    },
    {
      id: 'privacy',
      label: currentLanguage === 'hi' ? 'गोपनीयता' : 'Privacy',
      icon: 'Shield'
    },
    {
      id: 'notifications',
      label: currentLanguage === 'hi' ? 'सूचनाएं' : 'Notifications',
      icon: 'Bell'
    },
    {
      id: 'security',
      label: currentLanguage === 'hi' ? 'सुरक्षा' : 'Security',
      icon: 'Lock'
    },
    {
      id: 'activity',
      label: currentLanguage === 'hi' ? 'गतिविधि' : 'Activity',
      icon: 'Activity'
    },
    {
      id: 'language',
      label: currentLanguage === 'hi' ? 'भाषा' : 'Language',
      icon: 'Globe'
    }
  ];

  // Load saved language preference
  useEffect(() => {
    const savedLanguage = localStorage.getItem('preferredLanguage');
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  const handleUserUpdate = (updatedData) => {
    setUserData(prev => ({ ...prev, ...updatedData }));
  };

  const handlePhotoUpdate = (newPhotoUrl) => {
    setUserData(prev => ({ ...prev, avatar: newPhotoUrl }));
  };

  const handlePrivacyUpdate = (updatedSettings) => {
    setPrivacySettings(updatedSettings);
  };

  const handleNotificationUpdate = (updatedSettings) => {
    setNotificationSettings(updatedSettings);
  };

  const handleSecurityUpdate = (updatedSettings) => {
    setSecuritySettings(updatedSettings);
  };

  const handleLanguageChange = (newLanguage) => {
    setCurrentLanguage(newLanguage);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'personal':
        return (
          <PersonalInfoTab
            user={userData}
            onUpdate={handleUserUpdate}
          />
        );
      case 'privacy':
        return (
          <PrivacyTab
            privacySettings={privacySettings}
            onUpdate={handlePrivacyUpdate}
          />
        );
      case 'notifications':
        return (
          <NotificationsTab
            notificationSettings={notificationSettings}
            onUpdate={handleNotificationUpdate}
          />
        );
      case 'security':
        return (
          <SecurityTab
            securitySettings={securitySettings}
            onUpdate={handleSecurityUpdate}
          />
        );
      case 'activity':
        return (
          <ActivityTab
            activityData={activityData}
          />
        );
      case 'language':
        return (
          <LanguageSettings
            currentLanguage={currentLanguage}
            onLanguageChange={handleLanguageChange}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Navigation />
      
      <main className="pt-32 lg:pt-30 pb-20 lg:pb-8">
        <div className="max-w-7xl mx-auto px-4 lg:px-6">
          <Breadcrumb />
          
          {/* Profile Header */}
          <ProfileHeader
            user={userData}
            onPhotoUpdate={handlePhotoUpdate}
          />

          {/* Settings Content */}
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Desktop Sidebar */}
            <div className="hidden lg:block w-64 flex-shrink-0">
              <div className="bg-card border border-border rounded-lg p-4 sticky top-32">
                <nav className="space-y-2">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-civic ${
                        activeTab === tab.id
                          ? 'bg-primary text-primary-foreground'
                          : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                      }`}
                    >
                      <Icon name={tab.icon} size={20} />
                      <span className="font-body">{tab.label}</span>
                    </button>
                  ))}
                </nav>
              </div>
            </div>

            {/* Mobile Tab Navigation */}
            <div className="lg:hidden">
              <div className="bg-card border border-border rounded-lg p-2 mb-6">
                <div className="flex overflow-x-auto space-x-1">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex-shrink-0 flex items-center space-x-2 px-3 py-2 rounded-lg transition-civic ${
                        activeTab === tab.id
                          ? 'bg-primary text-primary-foreground'
                          : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                      }`}
                    >
                      <Icon name={tab.icon} size={16} />
                      <span className="font-body text-sm whitespace-nowrap">{tab.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Main Content */}
            <div className="flex-1">
              <div className="bg-card border border-border rounded-lg p-6">
                {renderTabContent()}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default UserProfileSettings;