import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import AuthToggle from './components/AuthToggle';
import LoginForm from './components/LoginForm';
import RegisterForm from './components/RegisterForm';
import SocialLogin from './components/SocialLogin';
import LanguageToggle from './components/LanguageToggle';

const UserRegistrationLogin = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('login');
  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    // Check if user is already authenticated
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    if (isAuthenticated === 'true') {
      navigate('/civic-dashboard');
    }

    // Load saved language preference
    const savedLanguage = localStorage.getItem('preferredLanguage');
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }
  }, [navigate]);

  const handleLanguageChange = (language) => {
    setCurrentLanguage(language);
    localStorage.setItem('preferredLanguage', language);
  };

  const content = {
    en: {
      tagline: "Empowering Citizens, Strengthening Democracy",
      description: "Join thousands of citizens actively participating in India\'s democratic process through transparent governance and civic engagement.",
      welcomeBack: "Welcome back to Janadrishti",
      joinCommunity: "Join the Janadrishti community",
      loginSubtitle: "Sign in to access your civic dashboard and stay connected with your representatives",
      registerSubtitle: "Create your account to start participating in democratic governance and civic activities"
    },
    hi: {
      tagline: "नागरिकों को सशक्त बनाना, लोकतंत्र को मजबूत करना",
      description: "पारदर्शी शासन और नागरिक भागीदारी के माध्यम से भारत की लोकतांत्रिक प्रक्रिया में सक्रिय रूप से भाग लेने वाले हजारों नागरिकों से जुड़ें।",
      welcomeBack: "जनदृष्टि में आपका स्वागत है",
      joinCommunity: "जनदृष्टि समुदाय में शामिल हों",
      loginSubtitle: "अपने नागरिक डैशबोर्ड तक पहुंचने और अपने प्रतिनिधियों से जुड़े रहने के लिए साइन इन करें",
      registerSubtitle: "लोकतांत्रिक शासन और नागरिक गतिविधियों में भाग लेना शुरू करने के लिए अपना खाता बनाएं"
    }
  };

  const t = content[currentLanguage];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50 flex items-center justify-center p-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 w-20 h-20 border-2 border-orange-500 rounded-full" />
        <div className="absolute top-32 right-20 w-16 h-16 border-2 border-green-600 rounded-full" />
        <div className="absolute bottom-20 left-20 w-24 h-24 border-2 border-blue-600 rounded-full" />
        <div className="absolute bottom-32 right-10 w-12 h-12 border-2 border-orange-500 rounded-full" />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Language Toggle */}
        <div className="flex justify-end mb-4">
          <LanguageToggle 
            currentLanguage={currentLanguage}
            onLanguageChange={handleLanguageChange}
          />
        </div>

        {/* Main Card */}
        <div className="bg-card border border-border rounded-2xl shadow-civic-lg p-8">
          {/* Logo and Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-green-600 rounded-xl flex items-center justify-center shadow-civic">
                <Icon name="Vote" size={24} color="white" />
              </div>
            </div>
            
            <h1 className="text-2xl font-bold text-foreground mb-2">
              Janadrishti
            </h1>
            
            <p className="text-sm text-primary font-medium mb-3">
              {t.tagline}
            </p>
            
            <p className="text-xs text-muted-foreground leading-relaxed">
              {t.description}
            </p>
          </div>

          {/* Auth Toggle */}
          <AuthToggle activeTab={activeTab} onTabChange={setActiveTab} />

          {/* Form Header */}
          <div className="text-center mb-6">
            <h2 className="text-xl font-semibold text-foreground mb-2">
              {activeTab === 'login' ? t.welcomeBack : t.joinCommunity}
            </h2>
            <p className="text-sm text-muted-foreground">
              {activeTab === 'login' ? t.loginSubtitle : t.registerSubtitle}
            </p>
          </div>

          {/* Forms */}
          {activeTab === 'login' ? (
            <LoginForm currentLanguage={currentLanguage} />
          ) : (
            <RegisterForm currentLanguage={currentLanguage} />
          )}

          {/* Social Login */}
          <div className="mt-6">
            <SocialLogin currentLanguage={currentLanguage} />
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-6">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} Janadrishti. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
};

export default UserRegistrationLogin;