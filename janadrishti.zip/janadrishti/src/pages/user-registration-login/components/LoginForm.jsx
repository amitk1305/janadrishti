import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const LoginForm = ({ currentLanguage }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    identifier: '',
    password: '',
    rememberMe: false
  });
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  const mockCredentials = {
    email: "citizen@janadrishti.in",
    mobile: "9876543210",
    password: "JanaDrishti@2024"
  };

  const content = {
    en: {
      identifier: "Mobile Number / Email",
      identifierPlaceholder: "Enter mobile number or email",
      password: "Password",
      passwordPlaceholder: "Enter your password",
      rememberMe: "Remember me",
      signIn: "Sign In",
      forgotPassword: "Forgot Password?",
      invalidCredentials: "Invalid credentials. Use citizen@janadrishti.in / 9876543210 with password JanaDrishti@2024",
      required: "This field is required"
    },
    hi: {
      identifier: "मोबाइल नंबर / ईमेल",
      identifierPlaceholder: "मोबाइल नंबर या ईमेल दर्ज करें",
      password: "पासवर्ड",
      passwordPlaceholder: "अपना पासवर्ड दर्ज करें",
      rememberMe: "मुझे याद रखें",
      signIn: "साइन इन करें",
      forgotPassword: "पासवर्ड भूल गए?",
      invalidCredentials: "गलत क्रेडेंशियल्स। citizen@janadrishti.in / 9876543210 और पासवर्ड JanaDrishti@2024 का उपयोग करें",
      required: "यह फील्ड आवश्यक है"
    }
  };

  const t = content[currentLanguage];

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.identifier.trim()) {
      newErrors.identifier = t.required;
    }
    
    if (!formData.password.trim()) {
      newErrors.password = t.required;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const isValidCredentials = 
        (formData.identifier === mockCredentials.email || 
         formData.identifier === mockCredentials.mobile) &&
        formData.password === mockCredentials.password;
      
      if (isValidCredentials) {
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('userEmail', mockCredentials.email);
        navigate('/civic-dashboard');
      } else {
        setErrors({ 
          general: t.invalidCredentials 
        });
      }
      
      setIsLoading(false);
    }, 1500);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {errors.general && (
        <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
          <p className="text-sm text-destructive">{errors.general}</p>
        </div>
      )}
      
      <Input
        label={t.identifier}
        type="text"
        name="identifier"
        placeholder={t.identifierPlaceholder}
        value={formData.identifier}
        onChange={handleInputChange}
        error={errors.identifier}
        required
      />
      
      <div className="relative">
        <Input
          label={t.password}
          type={showPassword ? "text" : "password"}
          name="password"
          placeholder={t.passwordPlaceholder}
          value={formData.password}
          onChange={handleInputChange}
          error={errors.password}
          required
        />
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className="absolute right-3 top-9 text-muted-foreground hover:text-foreground transition-civic"
        >
          <Icon name={showPassword ? "EyeOff" : "Eye"} size={20} />
        </button>
      </div>
      
      <div className="flex items-center justify-between">
        <Checkbox
          label={t.rememberMe}
          name="rememberMe"
          checked={formData.rememberMe}
          onChange={handleInputChange}
        />
        
        <button
          type="button"
          className="text-sm text-primary hover:text-primary/80 transition-civic"
        >
          {t.forgotPassword}
        </button>
      </div>
      
      <Button
        type="submit"
        variant="default"
        fullWidth
        loading={isLoading}
        className="mt-6"
      >
        {t.signIn}
      </Button>
    </form>
  );
};

export default LoginForm;