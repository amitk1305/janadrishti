import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const RegisterForm = ({ currentLanguage }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: '',
    mobile: '',
    email: '',
    password: '',
    confirmPassword: '',
    constituency: '',
    acceptTerms: false
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState('');

  const constituencies = [
    { value: 'delhi-south', label: 'Delhi South' },
    { value: 'mumbai-north', label: 'Mumbai North' },
    { value: 'bangalore-central', label: 'Bangalore Central' },
    { value: 'kolkata-east', label: 'Kolkata East' },
    { value: 'chennai-west', label: 'Chennai West' },
    { value: 'hyderabad-central', label: 'Hyderabad Central' },
    { value: 'pune-north', label: 'Pune North' },
    { value: 'ahmedabad-east', label: 'Ahmedabad East' },
    { value: 'jaipur-central', label: 'Jaipur Central' },
    { value: 'lucknow-west', label: 'Lucknow West' }
  ];

  const content = {
    en: {
      fullName: "Full Name",
      fullNamePlaceholder: "Enter your full name",
      mobile: "Mobile Number",
      mobilePlaceholder: "Enter 10-digit mobile number",
      email: "Email Address",
      emailPlaceholder: "Enter your email address",
      password: "Password",
      passwordPlaceholder: "Create a strong password",
      confirmPassword: "Confirm Password",
      confirmPasswordPlaceholder: "Re-enter your password",
      constituency: "Select Constituency",
      constituencyPlaceholder: "Choose your constituency",
      acceptTerms: "I agree to the Terms of Service and Privacy Policy",
      sendOtp: "Send OTP",
      verifyOtp: "Verify OTP",
      otpPlaceholder: "Enter 6-digit OTP",
      createAccount: "Create Account",
      otpSentMessage: "OTP sent to your mobile number",
      mockOtp: "Use OTP: 123456",
      required: "This field is required",
      invalidEmail: "Please enter a valid email address",
      invalidMobile: "Please enter a valid 10-digit mobile number",
      passwordMismatch: "Passwords do not match",
      weakPassword: "Password must be at least 8 characters long",
      invalidOtp: "Invalid OTP. Use 123456"
    },
    hi: {
      fullName: "पूरा नाम",
      fullNamePlaceholder: "अपना पूरा नाम दर्ज करें",
      mobile: "मोबाइल नंबर",
      mobilePlaceholder: "10 अंकों का मोबाइल नंबर दर्ज करें",
      email: "ईमेल पता",
      emailPlaceholder: "अपना ईमेल पता दर्ज करें",
      password: "पासवर्ड",
      passwordPlaceholder: "एक मजबूत पासवर्ड बनाएं",
      confirmPassword: "पासवर्ड की पुष्टि करें",
      confirmPasswordPlaceholder: "अपना पासवर्ड फिर से दर्ज करें",
      constituency: "निर्वाचन क्षेत्र चुनें",
      constituencyPlaceholder: "अपना निर्वाचन क्षेत्र चुनें",
      acceptTerms: "मैं सेवा की शर्तों और गोपनीयता नीति से सहमत हूं",
      sendOtp: "OTP भेजें",
      verifyOtp: "OTP सत्यापित करें",
      otpPlaceholder: "6 अंकों का OTP दर्ज करें",
      createAccount: "खाता बनाएं",
      otpSentMessage: "आपके मोबाइल नंबर पर OTP भेजा गया",
      mockOtp: "OTP का उपयोग करें: 123456",
      required: "यह फील्ड आवश्यक है",
      invalidEmail: "कृपया एक वैध ईमेल पता दर्ज करें",
      invalidMobile: "कृपया एक वैध 10 अंकों का मोबाइल नंबर दर्ज करें",
      passwordMismatch: "पासवर्ड मेल नहीं खाते",
      weakPassword: "पासवर्ड कम से कम 8 अक्षर लंबा होना चाहिए",
      invalidOtp: "गलत OTP। 123456 का उपयोग करें"
    }
  };

  const t = content[currentLanguage];

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSelectChange = (value) => {
    setFormData(prev => ({ ...prev, constituency: value }));
    if (errors.constituency) {
      setErrors(prev => ({ ...prev, constituency: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.fullName.trim()) {
      newErrors.fullName = t.required;
    }
    
    if (!formData.mobile.trim()) {
      newErrors.mobile = t.required;
    } else if (!/^\d{10}$/.test(formData.mobile)) {
      newErrors.mobile = t.invalidMobile;
    }
    
    if (!formData.email.trim()) {
      newErrors.email = t.required;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = t.invalidEmail;
    }
    
    if (!formData.password.trim()) {
      newErrors.password = t.required;
    } else if (formData.password.length < 8) {
      newErrors.password = t.weakPassword;
    }
    
    if (!formData.confirmPassword.trim()) {
      newErrors.confirmPassword = t.required;
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = t.passwordMismatch;
    }
    
    if (!formData.constituency) {
      newErrors.constituency = t.required;
    }
    
    if (!formData.acceptTerms) {
      newErrors.acceptTerms = t.required;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSendOtp = async () => {
    if (!formData.mobile.trim() || !/^\d{10}$/.test(formData.mobile)) {
      setErrors({ mobile: t.invalidMobile });
      return;
    }
    
    setIsLoading(true);
    
    // Simulate OTP sending
    setTimeout(() => {
      setOtpSent(true);
      setIsLoading(false);
    }, 1000);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!otpSent) {
      if (!validateForm()) return;
      handleSendOtp();
      return;
    }
    
    if (!otp.trim()) {
      setErrors({ otp: t.required });
      return;
    }
    
    if (otp !== '123456') {
      setErrors({ otp: t.invalidOtp });
      return;
    }
    
    setIsLoading(true);
    
    // Simulate account creation
    setTimeout(() => {
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('userEmail', formData.email);
      navigate('/civic-dashboard');
      setIsLoading(false);
    }, 1500);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {otpSent && (
        <div className="p-3 bg-accent/10 border border-accent/20 rounded-lg">
          <p className="text-sm text-accent">{t.otpSentMessage}</p>
          <p className="text-xs text-muted-foreground mt-1">{t.mockOtp}</p>
        </div>
      )}
      
      {!otpSent ? (
        <>
          <Input
            label={t.fullName}
            type="text"
            name="fullName"
            placeholder={t.fullNamePlaceholder}
            value={formData.fullName}
            onChange={handleInputChange}
            error={errors.fullName}
            required
          />
          
          <div className="flex space-x-3">
            <div className="flex-1">
              <Input
                label={t.mobile}
                type="tel"
                name="mobile"
                placeholder={t.mobilePlaceholder}
                value={formData.mobile}
                onChange={handleInputChange}
                error={errors.mobile}
                required
              />
            </div>
            <div className="flex items-end">
              <Button
                type="button"
                variant="outline"
                onClick={handleSendOtp}
                loading={isLoading}
                className="h-10"
              >
                {t.sendOtp}
              </Button>
            </div>
          </div>
          
          <Input
            label={t.email}
            type="email"
            name="email"
            placeholder={t.emailPlaceholder}
            value={formData.email}
            onChange={handleInputChange}
            error={errors.email}
            required
          />
          
          <div className="relative">
            <Input
              label={t.password}
              type={showPassword ? "text" : "password"}
              name="password"
              placeholder={t.passwordPlaceholder}
              value={formData.password}
              onChange={handleInputChange}
              error={errors.password}
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-9 text-muted-foreground hover:text-foreground transition-civic"
            >
              <Icon name={showPassword ? "EyeOff" : "Eye"} size={20} />
            </button>
          </div>
          
          <div className="relative">
            <Input
              label={t.confirmPassword}
              type={showConfirmPassword ? "text" : "password"}
              name="confirmPassword"
              placeholder={t.confirmPasswordPlaceholder}
              value={formData.confirmPassword}
              onChange={handleInputChange}
              error={errors.confirmPassword}
              required
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-3 top-9 text-muted-foreground hover:text-foreground transition-civic"
            >
              <Icon name={showConfirmPassword ? "EyeOff" : "Eye"} size={20} />
            </button>
          </div>
          
          <Select
            label={t.constituency}
            placeholder={t.constituencyPlaceholder}
            options={constituencies}
            value={formData.constituency}
            onChange={handleSelectChange}
            error={errors.constituency}
            required
            searchable
          />
          
          <Checkbox
            label={t.acceptTerms}
            name="acceptTerms"
            checked={formData.acceptTerms}
            onChange={handleInputChange}
            error={errors.acceptTerms}
            required
          />
        </>
      ) : (
        <Input
          label={t.verifyOtp}
          type="text"
          name="otp"
          placeholder={t.otpPlaceholder}
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          error={errors.otp}
          required
          maxLength={6}
        />
      )}
      
      <Button
        type="submit"
        variant="default"
        fullWidth
        loading={isLoading}
        className="mt-6"
      >
        {otpSent ? t.verifyOtp : t.createAccount}
      </Button>
    </form>
  );
};

export default RegisterForm;