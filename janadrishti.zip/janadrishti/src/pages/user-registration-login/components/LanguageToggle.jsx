import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const LanguageToggle = ({ currentLanguage, onLanguageChange }) => {
  const languages = [
    { code: 'en', name: 'English', nativeName: 'English' },
    { code: 'hi', name: 'Hindi', nativeName: 'हिंदी' }
  ];

  const currentLang = languages.find(lang => lang.code === currentLanguage);

  return (
    <div className="relative group">
      <Button
        variant="ghost"
        size="sm"
        className="flex items-center space-x-2"
      >
        <Icon name="Globe" size={16} />
        <span className="text-sm">{currentLang?.nativeName}</span>
        <Icon name="ChevronDown" size={14} />
      </Button>
      
      <div className="absolute right-0 top-full mt-1 w-32 bg-popover border border-border rounded-lg shadow-civic-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-civic z-50">
        {languages.map((language) => (
          <button
            key={language.code}
            onClick={() => onLanguageChange(language.code)}
            className={`w-full px-3 py-2 text-left text-sm hover:bg-muted transition-civic first:rounded-t-lg last:rounded-b-lg ${
              currentLanguage === language.code
                ? 'bg-primary text-primary-foreground'
                : 'text-foreground'
            }`}
          >
            {language.nativeName}
          </button>
        ))}
      </div>
    </div>
  );
};

export default LanguageToggle;