import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const ReviewSubmit = ({ formData, onSubmit, isSubmitting }) => {
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const getCategoryIcon = (category) => {
    const iconMap = {
      infrastructure: 'Construction',
      healthcare: 'Heart',
      education: 'GraduationCap',
      sanitation: 'Trash2',
      water: 'Droplets',
      electricity: 'Zap',
      transport: 'Bus',
      environment: 'Leaf'
    };
    return iconMap[category] || 'AlertTriangle';
  };

  const getSeverityColor = (severity) => {
    const colorMap = {
      low: 'text-muted-foreground bg-muted',
      medium: 'text-warning bg-warning/10',
      high: 'text-destructive bg-destructive/10',
      urgent: 'text-destructive bg-destructive'
    };
    return colorMap[severity] || 'text-muted-foreground bg-muted';
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleSubmit = () => {
    setShowConfirmModal(true);
  };

  const confirmSubmit = () => {
    setShowConfirmModal(false);
    onSubmit();
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-heading font-semibold text-lg text-foreground mb-4">
          Review & Submit
        </h3>
        <p className="text-muted-foreground font-body mb-6">
          Please review all the information before submitting your civic issue report.
        </p>
      </div>

      {/* Issue Summary Card */}
      <div className="bg-card border border-border rounded-lg p-6 space-y-6">
        {/* Header */}
        <div className="flex items-start space-x-4">
          <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
            <Icon name={getCategoryIcon(formData.category)} size={24} color="white" />
          </div>
          <div className="flex-1">
            <h4 className="font-heading font-semibold text-lg text-foreground">
              {formData.title}
            </h4>
            <div className="flex items-center space-x-3 mt-2">
              <span className="text-sm text-muted-foreground capitalize">
                {formData.category?.replace(/([A-Z])/g, ' $1').trim()}
              </span>
              <span className={`text-xs px-2 py-1 rounded-full font-medium capitalize ${getSeverityColor(formData.severity)}`}>
                {formData.severity} Priority
              </span>
            </div>
          </div>
        </div>

        {/* Description */}
        <div>
          <h5 className="font-body font-medium text-foreground mb-2">Description</h5>
          <p className="text-muted-foreground font-body leading-relaxed">
            {formData.description}
          </p>
        </div>

        {/* Location */}
        <div>
          <h5 className="font-body font-medium text-foreground mb-2">Location</h5>
          <div className="flex items-start space-x-3">
            <Icon name="MapPin" size={16} className="text-muted-foreground mt-1" />
            <div>
              <p className="text-muted-foreground font-body">
                {formData.location?.address}
              </p>
              {formData.location?.landmark && (
                <p className="text-sm text-muted-foreground mt-1">
                  Near: {formData.location.landmark}
                </p>
              )}
              {formData.location?.locality && (
                <p className="text-sm text-muted-foreground">
                  Area: {formData.location.locality}
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Evidence */}
        {formData.evidence && formData.evidence.length > 0 && (
          <div>
            <h5 className="font-body font-medium text-foreground mb-3">
              Evidence ({formData.evidence.length} files)
            </h5>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {formData.evidence.map((file) => (
                <div key={file.id} className="relative">
                  <div className="aspect-square bg-muted rounded-lg overflow-hidden">
                    {file.isVideo ? (
                      <div className="w-full h-full flex items-center justify-center">
                        <Icon name="Video" size={24} className="text-muted-foreground" />
                      </div>
                    ) : (
                      <Image
                        src={file.url}
                        alt={file.name}
                        className="w-full h-full object-cover"
                      />
                    )}
                  </div>
                  <div className="absolute bottom-1 left-1 right-1 bg-black/70 text-white text-xs p-1 rounded truncate">
                    {formatFileSize(file.size)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Contact Preferences */}
        <div>
          <h5 className="font-body font-medium text-foreground mb-2">Contact Preferences</h5>
          <div className="space-y-2">
            {formData.contactPreferences?.anonymous ? (
              <div className="flex items-center space-x-2">
                <Icon name="Shield" size={16} className="text-muted-foreground" />
                <span className="text-muted-foreground font-body">Anonymous Report</span>
              </div>
            ) : (
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <Icon name="User" size={16} className="text-muted-foreground" />
                  <span className="text-muted-foreground font-body">
                    {formData.contactPreferences?.name}
                  </span>
                </div>
                {formData.contactPreferences?.email && (
                  <div className="flex items-center space-x-2">
                    <Icon name="Mail" size={16} className="text-muted-foreground" />
                    <span className="text-muted-foreground font-body">
                      {formData.contactPreferences.email}
                    </span>
                  </div>
                )}
                {formData.contactPreferences?.phone && (
                  <div className="flex items-center space-x-2">
                    <Icon name="Phone" size={16} className="text-muted-foreground" />
                    <span className="text-muted-foreground font-body">
                      {formData.contactPreferences.phone}
                    </span>
                  </div>
                )}
              </div>
            )}
            
            {formData.contactPreferences?.methods && formData.contactPreferences.methods.length > 0 && (
              <div className="flex items-center space-x-2 mt-2">
                <Icon name="Bell" size={16} className="text-muted-foreground" />
                <span className="text-muted-foreground font-body">
                  Updates via: {formData.contactPreferences.methods.join(', ')}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Important Notice */}
      <div className="bg-warning/10 border border-warning/20 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <Icon name="AlertTriangle" size={20} className="text-warning mt-0.5" />
          <div>
            <h4 className="font-body font-medium text-foreground mb-2">
              Important Notice
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Ensure all information provided is accurate and truthful</li>
              <li>• False reporting may result in account suspension</li>
              <li>• Your report will be forwarded to relevant authorities</li>
              <li>• You will receive a tracking number for follow-up</li>
              <li>• Response time may vary based on issue severity and location</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Submit Button */}
      <div className="flex flex-col sm:flex-row gap-4 pt-4">
        <Button
          variant="outline"
          onClick={() => window.history.back()}
          className="sm:w-auto"
        >
          Back to Edit
        </Button>
        
        <Button
          onClick={handleSubmit}
          loading={isSubmitting}
          iconName="Send"
          iconPosition="right"
          className="flex-1 sm:flex-none"
        >
          Submit Issue Report
        </Button>
      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-modal p-4">
          <div className="bg-card border border-border rounded-lg max-w-md w-full p-6">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                <Icon name="Send" size={24} className="text-primary" />
              </div>
              
              <div>
                <h3 className="font-heading font-semibold text-lg text-foreground mb-2">
                  Submit Issue Report?
                </h3>
                <p className="text-muted-foreground font-body">
                  Once submitted, your report will be sent to the relevant authorities. 
                  You'll receive a tracking number to monitor progress.
                </p>
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowConfirmModal(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={confirmSubmit}
                  loading={isSubmitting}
                  className="flex-1"
                >
                  Confirm Submit
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReviewSubmit;