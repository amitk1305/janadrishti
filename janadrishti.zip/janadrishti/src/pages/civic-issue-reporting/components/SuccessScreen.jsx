import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SuccessScreen = ({ trackingNumber, estimatedResponse }) => {
  const mockTrackingNumber = trackingNumber || `CIR-${Date.now().toString().slice(-8)}`;
  const mockEstimatedResponse = estimatedResponse || '3-5 business days';

  const shareText = `I've reported a civic issue through Janadrishti. Tracking ID: ${mockTrackingNumber}. Together we can make our community better! #JanadrishtiApp #CivicEngagement`;

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Civic Issue Reported',
          text: shareText,
          url: window.location.origin
        });
      } catch (error) {
        // Fallback to copying to clipboard
        navigator.clipboard.writeText(shareText);
        alert('Report details copied to clipboard!');
      }
    } else {
      // Fallback for browsers without Web Share API
      navigator.clipboard.writeText(shareText);
      alert('Report details copied to clipboard!');
    }
  };

  const nextSteps = [
    {
      icon: 'Clock',
      title: 'Processing',
      description: 'Your report is being reviewed by relevant authorities',
      status: 'current'
    },
    {
      icon: 'Users',
      title: 'Assignment',
      description: 'Issue will be assigned to appropriate department',
      status: 'upcoming'
    },
    {
      icon: 'Wrench',
      title: 'Action',
      description: 'Authorities will take necessary action to resolve the issue',
      status: 'upcoming'
    },
    {
      icon: 'CheckCircle',
      title: 'Resolution',
      description: 'You will be notified once the issue is resolved',
      status: 'upcoming'
    }
  ];

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        {/* Success Animation */}
        <div className="text-center mb-8">
          <div className="w-24 h-24 bg-accent rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
            <Icon name="CheckCircle" size={48} color="white" />
          </div>
          
          <h1 className="font-heading font-bold text-2xl lg:text-3xl text-foreground mb-4">
            Issue Report Submitted Successfully!
          </h1>
          
          <p className="text-muted-foreground font-body text-lg">
            Thank you for being an active citizen. Your report helps make our community better.
          </p>
        </div>

        {/* Tracking Information */}
        <div className="bg-card border border-border rounded-lg p-6 mb-6">
          <div className="text-center space-y-4">
            <div>
              <h3 className="font-heading font-semibold text-lg text-foreground mb-2">
                Your Tracking Number
              </h3>
              <div className="bg-muted p-4 rounded-lg">
                <span className="font-mono text-xl font-bold text-primary">
                  {mockTrackingNumber}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Save this number to track your issue status
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Icon name="Clock" size={20} className="text-muted-foreground" />
                </div>
                <h4 className="font-body font-medium text-foreground">Estimated Response</h4>
                <p className="text-muted-foreground">{mockEstimatedResponse}</p>
              </div>
              
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Icon name="Calendar" size={20} className="text-muted-foreground" />
                </div>
                <h4 className="font-body font-medium text-foreground">Submitted On</h4>
                <p className="text-muted-foreground">
                  {new Date().toLocaleDateString('en-IN', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Next Steps */}
        <div className="bg-card border border-border rounded-lg p-6 mb-6">
          <h3 className="font-heading font-semibold text-lg text-foreground mb-4">
            What Happens Next?
          </h3>
          
          <div className="space-y-4">
            {nextSteps.map((step, index) => (
              <div key={index} className="flex items-start space-x-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  step.status === 'current' ?'bg-primary text-primary-foreground' :'bg-muted text-muted-foreground'
                }`}>
                  <Icon name={step.icon} size={20} />
                </div>
                
                <div className="flex-1">
                  <h4 className="font-body font-medium text-foreground">
                    {step.title}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {step.description}
                  </p>
                </div>
                
                {step.status === 'current' && (
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Button
              variant="outline"
              onClick={handleShare}
              iconName="Share2"
              iconPosition="left"
              className="w-full"
            >
              Share Report
            </Button>
            
            <Link to="/civic-dashboard" className="w-full">
              <Button variant="outline" className="w-full">
                View Dashboard
              </Button>
            </Link>
          </div>

          <Link to="/civic-issue-reporting" className="block">
            <Button className="w-full" iconName="Plus" iconPosition="left">
              Report Another Issue
            </Button>
          </Link>
        </div>

        {/* Additional Information */}
        <div className="bg-muted p-4 rounded-lg mt-6">
          <div className="flex items-start space-x-3">
            <Icon name="Info" size={20} className="text-primary mt-0.5" />
            <div>
              <h4 className="font-body font-medium text-foreground mb-2">
                Stay Updated
              </h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• You'll receive notifications about status updates</li>
                <li>• Check your dashboard regularly for progress</li>
                <li>• Authorities may contact you for additional information</li>
                <li>• Feel free to report other issues you encounter</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Footer Message */}
        <div className="text-center mt-8 p-4">
          <p className="text-muted-foreground font-body">
            Your civic participation makes a difference. Thank you for using{' '}
            <span className="font-semibold text-primary">Janadrishti</span> to improve our community.
          </p>
        </div>
      </div>
    </div>
  );
};

export default SuccessScreen;