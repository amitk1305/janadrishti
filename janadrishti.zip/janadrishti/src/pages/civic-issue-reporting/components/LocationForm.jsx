import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

const LocationForm = ({ formData, updateFormData, errors }) => {
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [locationError, setLocationError] = useState('');

  // Mock location data for demonstration
  const mockLocations = [
    "Connaught Place, New Delhi, Delhi 110001",
    "MG Road, Bangalore, Karnataka 560001",
    "Marine Drive, Mumbai, Maharashtra 400020",
    "Park Street, Kolkata, West Bengal 700016",
    "Anna Salai, Chennai, Tamil Nadu 600002"
  ];

  const getCurrentLocation = () => {
    setIsLoadingLocation(true);
    setLocationError('');

    // Simulate GPS location fetch
    setTimeout(() => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            // Mock reverse geocoding
            const mockAddress = mockLocations[Math.floor(Math.random() * mockLocations.length)];
            
            updateFormData({
              location: {
                ...formData.location,
                latitude,
                longitude,
                address: mockAddress,
                isGPSEnabled: true
              }
            });
            setIsLoadingLocation(false);
          },
          (error) => {
            setLocationError('Unable to get your location. Please enter address manually.');
            setIsLoadingLocation(false);
          },
          { timeout: 10000, enableHighAccuracy: true }
        );
      } else {
        setLocationError('Geolocation is not supported by this browser.');
        setIsLoadingLocation(false);
      }
    }, 1500);
  };

  const handleAddressChange = (address) => {
    updateFormData({
      location: {
        ...formData.location,
        address,
        isGPSEnabled: false
      }
    });
  };

  // Mock coordinates for map display
  const mapLat = formData.location?.latitude || 28.6139;
  const mapLng = formData.location?.longitude || 77.2090;

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-heading font-semibold text-lg text-foreground mb-4">
          Issue Location
        </h3>
        <p className="text-muted-foreground font-body mb-6">
          Specify the exact location where the issue exists for faster resolution.
        </p>
      </div>

      {/* GPS Location Button */}
      <div className="space-y-4">
        <Button
          variant="outline"
          onClick={getCurrentLocation}
          loading={isLoadingLocation}
          iconName="MapPin"
          iconPosition="left"
          className="w-full sm:w-auto"
        >
          {isLoadingLocation ? 'Getting Location...' : 'Use Current Location'}
        </Button>

        {locationError && (
          <div className="flex items-center space-x-2 p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
            <Icon name="AlertCircle" size={16} className="text-destructive" />
            <span className="text-sm text-destructive font-body">{locationError}</span>
          </div>
        )}

        {formData.location?.isGPSEnabled && (
          <div className="flex items-center space-x-2 p-3 bg-accent/10 border border-accent/20 rounded-lg">
            <Icon name="CheckCircle" size={16} className="text-accent" />
            <span className="text-sm text-accent font-body">
              Location detected successfully
            </span>
          </div>
        )}
      </div>

      {/* Address Input */}
      <Input
        label="Address"
        type="text"
        placeholder="Enter the complete address of the issue location"
        description="Provide detailed address including landmarks for easy identification"
        value={formData.location?.address || ''}
        onChange={(e) => handleAddressChange(e.target.value)}
        error={errors.location}
        required
      />

      {/* Address Suggestions */}
      {formData.location?.address && formData.location.address.length > 3 && (
        <div className="space-y-2">
          <label className="block text-sm font-medium text-foreground">
            Suggested Addresses
          </label>
          <div className="space-y-1">
            {mockLocations
              .filter(loc => 
                loc.toLowerCase().includes(formData.location.address.toLowerCase())
              )
              .slice(0, 3)
              .map((suggestion, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => handleAddressChange(suggestion)}
                  className="w-full text-left p-3 bg-muted hover:bg-muted/80 rounded-lg transition-civic"
                >
                  <div className="flex items-center space-x-2">
                    <Icon name="MapPin" size={16} className="text-muted-foreground" />
                    <span className="font-body text-sm text-foreground">{suggestion}</span>
                  </div>
                </button>
              ))}
          </div>
        </div>
      )}

      {/* Map Display */}
      {formData.location?.address && (
        <div className="space-y-3">
          <label className="block text-sm font-medium text-foreground">
            Location Preview
          </label>
          <div className="w-full h-64 bg-muted rounded-lg overflow-hidden border border-border">
            <iframe
              width="100%"
              height="100%"
              loading="lazy"
              title="Issue Location"
              referrerPolicy="no-referrer-when-downgrade"
              src={`https://www.google.com/maps?q=${mapLat},${mapLng}&z=16&output=embed`}
              className="border-0"
            />
          </div>
          <p className="text-sm text-muted-foreground font-body">
            Verify that the pin location matches your issue location. You can adjust it if needed.
          </p>
        </div>
      )}

      {/* Additional Location Details */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input
          label="Landmark (Optional)"
          type="text"
          placeholder="Nearby landmark or reference point"
          value={formData.location?.landmark || ''}
          onChange={(e) => updateFormData({
            location: {
              ...formData.location,
              landmark: e.target.value
            }
          })}
        />

        <Input
          label="Area/Locality"
          type="text"
          placeholder="Neighborhood or area name"
          value={formData.location?.locality || ''}
          onChange={(e) => updateFormData({
            location: {
              ...formData.location,
              locality: e.target.value
            }
          })}
        />
      </div>

      {/* Location Accuracy Note */}
      <div className="bg-muted p-4 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={20} className="text-primary mt-0.5" />
          <div>
            <h4 className="font-body font-medium text-foreground mb-1">
              Location Accuracy Tips
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Use GPS for most accurate location</li>
              <li>• Include nearby landmarks for easy identification</li>
              <li>• Verify the map pin matches your issue location</li>
              <li>• Provide complete address with pin code</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LocationForm;