import React from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const ContactPreferences = ({ formData, updateFormData, errors }) => {
  const contactMethods = [
    {
      id: 'email',
      label: 'Email Updates',
      description: 'Receive status updates via email',
      icon: 'Mail'
    },
    {
      id: 'sms',
      label: 'SMS Notifications',
      description: 'Get quick updates via text message',
      icon: 'MessageSquare'
    },
    {
      id: 'phone',
      label: 'Phone Calls',
      description: 'Allow officials to contact you by phone',
      icon: 'Phone'
    },
    {
      id: 'app',
      label: 'In-App Notifications',
      description: 'Receive updates within the app',
      icon: 'Bell'
    }
  ];

  const handleContactMethodChange = (methodId, checked) => {
    const currentMethods = formData.contactPreferences?.methods || [];
    const updatedMethods = checked
      ? [...currentMethods, methodId]
      : currentMethods.filter(method => method !== methodId);

    updateFormData({
      contactPreferences: {
        ...formData.contactPreferences,
        methods: updatedMethods
      }
    });
  };

  const handleAnonymousChange = (checked) => {
    updateFormData({
      contactPreferences: {
        ...formData.contactPreferences,
        anonymous: checked
      }
    });
  };

  const handleFollowUpChange = (checked) => {
    updateFormData({
      contactPreferences: {
        ...formData.contactPreferences,
        allowFollowUp: checked
      }
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-heading font-semibold text-lg text-foreground mb-4">
          Contact & Privacy Preferences
        </h3>
        <p className="text-muted-foreground font-body mb-6">
          Choose how you'd like to be contacted about this issue and set your privacy preferences.
        </p>
      </div>

      {/* Anonymous Reporting Option */}
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center mt-1">
            <Icon name="Shield" size={20} className="text-muted-foreground" />
          </div>
          <div className="flex-1">
            <Checkbox
              label="Report Anonymously"
              description="Your personal information will not be shared with authorities. You can still track the issue status."
              checked={formData.contactPreferences?.anonymous || false}
              onChange={(e) => handleAnonymousChange(e.target.checked)}
            />
          </div>
        </div>
      </div>

      {/* Contact Information */}
      {!formData.contactPreferences?.anonymous && (
        <div className="space-y-4">
          <h4 className="font-body font-medium text-foreground">
            Contact Information
          </h4>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Full Name"
              type="text"
              placeholder="Your full name"
              value={formData.contactPreferences?.name || ''}
              onChange={(e) => updateFormData({
                contactPreferences: {
                  ...formData.contactPreferences,
                  name: e.target.value
                }
              })}
              error={errors.contactName}
              required
            />

            <Input
              label="Phone Number"
              type="tel"
              placeholder="+91 98765 43210"
              value={formData.contactPreferences?.phone || ''}
              onChange={(e) => updateFormData({
                contactPreferences: {
                  ...formData.contactPreferences,
                  phone: e.target.value
                }
              })}
              error={errors.contactPhone}
            />
          </div>

          <Input
            label="Email Address"
            type="email"
            placeholder="your.email@example.com"
            value={formData.contactPreferences?.email || ''}
            onChange={(e) => updateFormData({
              contactPreferences: {
                ...formData.contactPreferences,
                email: e.target.value
              }
            })}
            error={errors.contactEmail}
            required
          />
        </div>
      )}

      {/* Communication Preferences */}
      <div className="space-y-4">
        <h4 className="font-body font-medium text-foreground">
          How would you like to receive updates?
        </h4>
        
        <div className="space-y-3">
          {contactMethods.map((method) => (
            <div
              key={method.id}
              className="flex items-center space-x-3 p-3 bg-muted rounded-lg"
            >
              <div className="w-8 h-8 bg-background rounded-lg flex items-center justify-center">
                <Icon name={method.icon} size={16} className="text-muted-foreground" />
              </div>
              
              <div className="flex-1">
                <Checkbox
                  label={method.label}
                  description={method.description}
                  checked={(formData.contactPreferences?.methods || []).includes(method.id)}
                  onChange={(e) => handleContactMethodChange(method.id, e.target.checked)}
                  disabled={formData.contactPreferences?.anonymous && method.id !== 'app'}
                />
              </div>
            </div>
          ))}
        </div>

        {formData.contactPreferences?.anonymous && (
          <div className="bg-warning/10 border border-warning/20 rounded-lg p-3">
            <div className="flex items-center space-x-2">
              <Icon name="Info" size={16} className="text-warning" />
              <span className="text-sm text-warning font-body">
                Anonymous reports can only receive in-app notifications
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Follow-up Preferences */}
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center mt-1">
            <Icon name="MessageCircle" size={20} className="text-muted-foreground" />
          </div>
          <div className="flex-1">
            <Checkbox
              label="Allow Follow-up Questions"
              description="Authorities may contact you for additional information to better resolve the issue"
              checked={formData.contactPreferences?.allowFollowUp || false}
              onChange={(e) => handleFollowUpChange(e.target.checked)}
              disabled={formData.contactPreferences?.anonymous}
            />
          </div>
        </div>
      </div>

      {/* Privacy Notice */}
      <div className="bg-muted p-4 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Lock" size={20} className="text-primary mt-0.5" />
          <div>
            <h4 className="font-body font-medium text-foreground mb-2">
              Privacy & Data Protection
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Your personal information is encrypted and secure</li>
              <li>• Data is only shared with relevant authorities for issue resolution</li>
              <li>• You can update your preferences anytime in your profile</li>
              <li>• Anonymous reports maintain complete privacy</li>
              <li>• We comply with all data protection regulations</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPreferences;