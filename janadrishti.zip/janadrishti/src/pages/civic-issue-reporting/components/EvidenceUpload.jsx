import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const EvidenceUpload = ({ formData, updateFormData, errors }) => {
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef(null);
  const cameraInputRef = useRef(null);

  const maxFileSize = 10 * 1024 * 1024; // 10MB
  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm'];

  const handleFiles = (files) => {
    const validFiles = [];
    const errors = [];

    Array.from(files).forEach((file) => {
      if (!allowedTypes.includes(file.type)) {
        errors.push(`${file.name}: Unsupported file type`);
        return;
      }

      if (file.size > maxFileSize) {
        errors.push(`${file.name}: File too large (max 10MB)`);
        return;
      }

      // Create mock URL for preview
      const mockUrl = URL.createObjectURL(file);
      validFiles.push({
        id: Date.now() + Math.random(),
        file,
        name: file.name,
        size: file.size,
        type: file.type,
        url: mockUrl,
        isVideo: file.type.startsWith('video/')
      });
    });

    if (errors.length > 0) {
      alert(errors.join('\n'));
    }

    if (validFiles.length > 0) {
      updateFormData({
        evidence: [...(formData.evidence || []), ...validFiles]
      });
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleFileInput = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files);
    }
  };

  const removeFile = (fileId) => {
    const updatedEvidence = (formData.evidence || []).filter(file => file.id !== fileId);
    updateFormData({ evidence: updatedEvidence });
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const openCamera = () => {
    if (cameraInputRef.current) {
      cameraInputRef.current.click();
    }
  };

  const openFileSelector = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-heading font-semibold text-lg text-foreground mb-4">
          Evidence & Documentation
        </h3>
        <p className="text-muted-foreground font-body mb-6">
          Upload photos or videos to help authorities understand and resolve the issue faster.
        </p>
      </div>

      {/* Upload Area */}
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-civic ${
          dragActive
            ? 'border-primary bg-primary/5' :'border-border hover:border-muted-foreground'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <div className="space-y-4">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
            <Icon name="Upload" size={24} className="text-muted-foreground" />
          </div>
          
          <div>
            <h4 className="font-body font-medium text-foreground mb-2">
              Upload Evidence
            </h4>
            <p className="text-sm text-muted-foreground mb-4">
              Drag and drop files here, or click to select
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              variant="outline"
              onClick={openCamera}
              iconName="Camera"
              iconPosition="left"
            >
              Take Photo
            </Button>
            
            <Button
              variant="outline"
              onClick={openFileSelector}
              iconName="FolderOpen"
              iconPosition="left"
            >
              Choose Files
            </Button>
          </div>

          <p className="text-xs text-muted-foreground">
            Supported: JPEG, PNG, WebP, MP4, WebM • Max size: 10MB per file
          </p>
        </div>
      </div>

      {/* Hidden File Inputs */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/*,video/*"
        onChange={handleFileInput}
        className="hidden"
      />
      
      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileInput}
        className="hidden"
      />

      {/* Uploaded Files Preview */}
      {formData.evidence && formData.evidence.length > 0 && (
        <div className="space-y-4">
          <h4 className="font-body font-medium text-foreground">
            Uploaded Evidence ({formData.evidence.length})
          </h4>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {formData.evidence.map((file) => (
              <div
                key={file.id}
                className="bg-card border border-border rounded-lg p-3 space-y-3"
              >
                {/* File Preview */}
                <div className="aspect-video bg-muted rounded-lg overflow-hidden relative">
                  {file.isVideo ? (
                    <video
                      src={file.url}
                      className="w-full h-full object-cover"
                      controls
                    />
                  ) : (
                    <Image
                      src={file.url}
                      alt={file.name}
                      className="w-full h-full object-cover"
                    />
                  )}
                  
                  <button
                    onClick={() => removeFile(file.id)}
                    className="absolute top-2 right-2 w-6 h-6 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center hover:bg-destructive/80 transition-civic"
                  >
                    <Icon name="X" size={12} />
                  </button>
                </div>

                {/* File Info */}
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={file.isVideo ? "Video" : "Image"} 
                      size={16} 
                      className="text-muted-foreground" 
                    />
                    <span className="text-sm font-body text-foreground truncate">
                      {file.name}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {formatFileSize(file.size)}
                    </span>
                    <span className={`text-xs px-2 py-1 rounded ${
                      file.isVideo 
                        ? 'bg-primary/10 text-primary' :'bg-accent/10 text-accent'
                    }`}>
                      {file.isVideo ? 'Video' : 'Image'}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Upload Guidelines */}
      <div className="bg-muted p-4 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="Lightbulb" size={20} className="text-primary mt-0.5" />
          <div>
            <h4 className="font-body font-medium text-foreground mb-2">
              Evidence Guidelines
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Take clear, well-lit photos showing the issue</li>
              <li>• Include multiple angles if possible</li>
              <li>• Capture any relevant signage or reference points</li>
              <li>• Videos should be under 2 minutes for faster processing</li>
              <li>• Avoid including personal information of others</li>
            </ul>
          </div>
        </div>
      </div>

      {errors.evidence && (
        <p className="text-sm text-destructive">{errors.evidence}</p>
      )}
    </div>
  );
};

export default EvidenceUpload;