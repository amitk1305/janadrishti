import React from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const IssueBasicsForm = ({ formData, updateFormData, errors }) => {
  const categories = [
    {
      value: 'infrastructure',
      label: 'Infrastructure',
      description: 'Roads, bridges, public buildings',
      icon: 'Construction'
    },
    {
      value: 'healthcare',
      label: 'Healthcare',
      description: 'Hospitals, clinics, medical facilities',
      icon: 'Heart'
    },
    {
      value: 'education',
      label: 'Education',
      description: 'Schools, colleges, educational resources',
      icon: 'GraduationCap'
    },
    {
      value: 'sanitation',
      label: 'Sanitation',
      description: 'Waste management, cleanliness',
      icon: 'Trash2'
    },
    {
      value: 'water',
      label: 'Water Supply',
      description: 'Water shortage, quality issues',
      icon: 'Droplets'
    },
    {
      value: 'electricity',
      label: 'Electricity',
      description: 'Power outages, electrical issues',
      icon: 'Zap'
    },
    {
      value: 'transport',
      label: 'Transportation',
      description: 'Public transport, traffic issues',
      icon: 'Bus'
    },
    {
      value: 'environment',
      label: 'Environment',
      description: 'Pollution, environmental concerns',
      icon: 'Leaf'
    }
  ];

  const categoryOptions = categories.map(cat => ({
    value: cat.value,
    label: cat.label,
    description: cat.description
  }));

  const selectedCategory = categories.find(cat => cat.value === formData.category);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="font-heading font-semibold text-lg text-foreground mb-4">
          Issue Details
        </h3>
        <p className="text-muted-foreground font-body mb-6">
          Provide basic information about the civic issue you want to report.
        </p>
      </div>

      {/* Category Selection */}
      <div className="space-y-4">
        <Select
          label="Issue Category"
          description="Select the category that best describes your issue"
          placeholder="Choose a category"
          options={categoryOptions}
          value={formData.category}
          onChange={(value) => updateFormData({ category: value })}
          error={errors.category}
          required
          searchable
        />

        {/* Category Visual Indicator */}
        {selectedCategory && (
          <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Icon name={selectedCategory.icon} size={20} color="white" />
            </div>
            <div>
              <h4 className="font-body font-medium text-foreground">
                {selectedCategory.label}
              </h4>
              <p className="text-sm text-muted-foreground">
                {selectedCategory.description}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Issue Title */}
      <Input
        label="Issue Title"
        type="text"
        placeholder="Brief title describing the issue"
        description="Provide a clear, concise title for your issue"
        value={formData.title}
        onChange={(e) => updateFormData({ title: e.target.value })}
        error={errors.title}
        required
        maxLength={100}
      />

      {/* Issue Description */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-foreground">
          Detailed Description *
        </label>
        <textarea
          placeholder="Describe the issue in detail. Include when it started, how it affects you and others, and any relevant context..."
          value={formData.description}
          onChange={(e) => updateFormData({ description: e.target.value })}
          rows={6}
          maxLength={1000}
          className={`w-full px-3 py-2 border rounded-lg font-body text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none ${
            errors.description ? 'border-destructive' : 'border-border'
          }`}
        />
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">
            Provide as much detail as possible for better resolution
          </span>
          <span className={`text-sm font-mono ${
            formData.description.length > 900 ? 'text-warning' : 'text-muted-foreground'
          }`}>
            {formData.description.length}/1000
          </span>
        </div>
        {errors.description && (
          <p className="text-sm text-destructive">{errors.description}</p>
        )}
      </div>

      {/* Issue Severity */}
      <div className="space-y-3">
        <label className="block text-sm font-medium text-foreground">
          Issue Severity *
        </label>
        <p className="text-sm text-muted-foreground">
          How urgent is this issue?
        </p>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { value: 'low', label: 'Low', color: 'bg-muted text-muted-foreground', description: 'Minor inconvenience' },
            { value: 'medium', label: 'Medium', color: 'bg-warning/10 text-warning border-warning/20', description: 'Affects daily life' },
            { value: 'high', label: 'High', color: 'bg-destructive/10 text-destructive border-destructive/20', description: 'Significant impact' },
            { value: 'urgent', label: 'Urgent', color: 'bg-destructive text-destructive-foreground', description: 'Immediate attention needed' }
          ].map((severity) => (
            <button
              key={severity.value}
              type="button"
              onClick={() => updateFormData({ severity: severity.value })}
              className={`p-3 rounded-lg border-2 transition-civic text-left ${
                formData.severity === severity.value
                  ? severity.color + 'border-current' :'border-border hover:border-muted-foreground'
              }`}
            >
              <div className="font-body font-medium">{severity.label}</div>
              <div className="text-xs opacity-80 mt-1">{severity.description}</div>
            </button>
          ))}
        </div>
        {errors.severity && (
          <p className="text-sm text-destructive">{errors.severity}</p>
        )}
      </div>
    </div>
  );
};

export default IssueBasicsForm;