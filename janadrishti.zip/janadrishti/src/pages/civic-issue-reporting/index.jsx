import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Navigation from '../../components/ui/Navigation';
import Breadcrumb from '../../components/ui/Breadcrumb';
import ProgressIndicator from './components/ProgressIndicator';
import IssueBasicsForm from './components/IssueBasicsForm';
import LocationForm from './components/LocationForm';
import EvidenceUpload from './components/EvidenceUpload';
import ContactPreferences from './components/ContactPreferences';
import ReviewSubmit from './components/ReviewSubmit';
import SuccessScreen from './components/SuccessScreen';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const CivicIssueReporting = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    category: '',
    title: '',
    description: '',
    severity: '',
    location: {
      address: '',
      latitude: null,
      longitude: null,
      landmark: '',
      locality: '',
      isGPSEnabled: false
    },
    evidence: [],
    contactPreferences: {
      anonymous: false,
      name: '',
      email: '',
      phone: '',
      methods: ['app'],
      allowFollowUp: true
    }
  });
  const [errors, setErrors] = useState({});
  const [autoSaveStatus, setAutoSaveStatus] = useState('');

  const steps = [
    { id: 1, title: 'Issue Details', component: 'basics' },
    { id: 2, title: 'Location', component: 'location' },
    { id: 3, title: 'Evidence', component: 'evidence' },
    { id: 4, title: 'Contact', component: 'contact' },
    { id: 5, title: 'Review', component: 'review' }
  ];

  // Auto-save functionality
  useEffect(() => {
    const autoSaveTimer = setTimeout(() => {
      if (Object.keys(formData).length > 0 && !isSubmitted) {
        localStorage.setItem('civicIssueReport', JSON.stringify(formData));
        setAutoSaveStatus('Draft saved');
        setTimeout(() => setAutoSaveStatus(''), 2000);
      }
    }, 3000);

    return () => clearTimeout(autoSaveTimer);
  }, [formData, isSubmitted]);

  // Load saved draft on component mount
  useEffect(() => {
    const savedDraft = localStorage.getItem('civicIssueReport');
    if (savedDraft) {
      try {
        const parsedData = JSON.parse(savedDraft);
        setFormData(parsedData);
        setAutoSaveStatus('Draft loaded');
        setTimeout(() => setAutoSaveStatus(''), 2000);
      } catch (error) {
        console.error('Error loading saved draft:', error);
      }
    }
  }, []);

  const updateFormData = (updates) => {
    setFormData(prev => ({
      ...prev,
      ...updates
    }));
    // Clear related errors when data is updated
    setErrors(prev => {
      const newErrors = { ...prev };
      Object.keys(updates).forEach(key => {
        delete newErrors[key];
      });
      return newErrors;
    });
  };

  const validateStep = (step) => {
    const newErrors = {};

    switch (step) {
      case 1:
        if (!formData.category) newErrors.category = 'Please select an issue category';
        if (!formData.title.trim()) newErrors.title = 'Please provide an issue title';
        if (!formData.description.trim()) newErrors.description = 'Please describe the issue';
        if (formData.description.length < 20) newErrors.description = 'Description must be at least 20 characters';
        if (!formData.severity) newErrors.severity = 'Please select issue severity';
        break;

      case 2:
        if (!formData.location?.address?.trim()) {
          newErrors.location = 'Please provide the issue location';
        }
        break;

      case 3:
        // Evidence is optional, no validation needed
        break;

      case 4:
        if (!formData.contactPreferences?.anonymous) {
          if (!formData.contactPreferences?.name?.trim()) {
            newErrors.contactName = 'Please provide your name';
          }
          if (!formData.contactPreferences?.email?.trim()) {
            newErrors.contactEmail = 'Please provide your email';
          } else if (!/\S+@\S+\.\S+/.test(formData.contactPreferences.email)) {
            newErrors.contactEmail = 'Please provide a valid email address';
          }
          if (formData.contactPreferences?.phone && 
              !/^[\+]?[1-9][\d]{0,15}$/.test(formData.contactPreferences.phone.replace(/\s/g, ''))) {
            newErrors.contactPhone = 'Please provide a valid phone number';
          }
        }
        break;

      default:
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, steps.length));
    }
  };

  const handlePrevious = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const handleSubmit = async () => {
    if (!validateStep(4)) return;

    setIsSubmitting(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Clear saved draft
      localStorage.removeItem('civicIssueReport');
      
      setIsSubmitted(true);
    } catch (error) {
      console.error('Error submitting report:', error);
      alert('Failed to submit report. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <IssueBasicsForm
            formData={formData}
            updateFormData={updateFormData}
            errors={errors}
          />
        );
      case 2:
        return (
          <LocationForm
            formData={formData}
            updateFormData={updateFormData}
            errors={errors}
          />
        );
      case 3:
        return (
          <EvidenceUpload
            formData={formData}
            updateFormData={updateFormData}
            errors={errors}
          />
        );
      case 4:
        return (
          <ContactPreferences
            formData={formData}
            updateFormData={updateFormData}
            errors={errors}
          />
        );
      case 5:
        return (
          <ReviewSubmit
            formData={formData}
            onSubmit={handleSubmit}
            isSubmitting={isSubmitting}
          />
        );
      default:
        return null;
    }
  };

  // Show success screen after submission
  if (isSubmitted) {
    return <SuccessScreen />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Navigation />
      
      <main className="pt-30 pb-20 lg:pb-8">
        <div className="max-w-4xl mx-auto px-4 lg:px-6">
          <Breadcrumb />
          
          <ProgressIndicator
            currentStep={currentStep}
            totalSteps={steps.length}
            steps={steps}
          />

          {/* Auto-save Status */}
          {autoSaveStatus && (
            <div className="fixed top-32 right-4 bg-accent text-accent-foreground px-3 py-2 rounded-lg text-sm font-body z-notification">
              <div className="flex items-center space-x-2">
                <Icon name="Save" size={16} />
                <span>{autoSaveStatus}</span>
              </div>
            </div>
          )}

          {/* Form Content */}
          <div className="bg-card border border-border rounded-lg p-6 lg:p-8 mt-6">
            {renderStepContent()}

            {/* Navigation Buttons */}
            {currentStep < 5 && (
              <div className="flex flex-col sm:flex-row justify-between gap-4 pt-8 mt-8 border-t border-border">
                <div className="flex items-center space-x-4">
                  {currentStep > 1 && (
                    <Button
                      variant="outline"
                      onClick={handlePrevious}
                      iconName="ChevronLeft"
                      iconPosition="left"
                    >
                      Previous
                    </Button>
                  )}
                  
                  <Button
                    variant="ghost"
                    onClick={() => navigate('/civic-dashboard')}
                    className="text-muted-foreground"
                  >
                    Save as Draft & Exit
                  </Button>
                </div>

                <Button
                  onClick={handleNext}
                  iconName="ChevronRight"
                  iconPosition="right"
                  className="sm:w-auto"
                >
                  {currentStep === steps.length - 1 ? 'Review Report' : 'Continue'}
                </Button>
              </div>
            )}
          </div>

          {/* Help Section */}
          <div className="bg-muted p-4 rounded-lg mt-6">
            <div className="flex items-start space-x-3">
              <Icon name="HelpCircle" size={20} className="text-primary mt-0.5" />
              <div>
                <h4 className="font-body font-medium text-foreground mb-2">
                  Need Help?
                </h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Having trouble reporting your issue? Here are some tips:
                </p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Be specific and detailed in your description</li>
                  <li>• Include photos or videos as evidence when possible</li>
                  <li>• Provide accurate location information</li>
                  <li>• Your report is automatically saved as you type</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default CivicIssueReporting;