import React from 'react';
import Icon from '../../../components/AppIcon';

const StatsHeader = ({ stats }) => {
  const defaultStats = {
    totalRepresentatives: 1247,
    averageRating: 3.8,
    totalFollowers: 45623,
    activeDiscussions: 234,
    recentUpdates: 89
  };

  const displayStats = { ...defaultStats, ...stats };

  const statItems = [
    {
      label: 'Total Representatives',
      value: displayStats.totalRepresentatives.toLocaleString(),
      icon: 'Users',
      color: 'text-primary'
    },
    {
      label: 'Average Rating',
      value: `${displayStats.averageRating}/5`,
      icon: 'Star',
      color: 'text-yellow-500'
    },
    {
      label: 'Platform Followers',
      value: displayStats.totalFollowers.toLocaleString(),
      icon: 'UserCheck',
      color: 'text-accent'
    },
    {
      label: 'Active Discussions',
      value: displayStats.activeDiscussions.toLocaleString(),
      icon: 'MessageSquare',
      color: 'text-blue-500'
    },
    {
      label: 'Recent Updates',
      value: displayStats.recentUpdates.toLocaleString(),
      icon: 'Activity',
      color: 'text-green-500'
    }
  ];

  return (
    <div className="bg-gradient-to-r from-primary/5 to-accent/5 border-b border-border">
      <div className="p-4 lg:p-6">
        <div className="text-center mb-6">
          <h1 className="font-heading font-bold text-2xl lg:text-3xl text-foreground mb-2">
            Political Representatives Directory
          </h1>
          <p className="text-muted-foreground font-body max-w-2xl mx-auto">
            Discover and evaluate your elected officials through comprehensive profiles, 
            performance data, and citizen engagement metrics.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          {statItems.map((stat, index) => (
            <div
              key={index}
              className="bg-card border border-border rounded-lg p-4 text-center hover:shadow-civic transition-civic"
            >
              <div className={`inline-flex items-center justify-center w-10 h-10 rounded-full bg-muted mb-3`}>
                <Icon name={stat.icon} size={20} className={stat.color} />
              </div>
              <div className="text-xl lg:text-2xl font-bold text-foreground mb-1">
                {stat.value}
              </div>
              <div className="text-xs lg:text-sm text-muted-foreground font-body">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Quick Info */}
        <div className="mt-6 bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-center space-x-6 text-sm text-muted-foreground">
            <div className="flex items-center space-x-2">
              <Icon name="Clock" size={16} />
              <span>Updated daily</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Shield" size={16} />
              <span>Verified data</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Globe" size={16} />
              <span>Pan-India coverage</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsHeader;