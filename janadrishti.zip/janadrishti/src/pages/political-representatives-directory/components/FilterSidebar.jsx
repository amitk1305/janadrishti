import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const FilterSidebar = ({ isOpen, onClose, filters, onFilterChange, onClearAll }) => {
  const [localFilters, setLocalFilters] = useState(filters);

  const partyOptions = [
    { value: 'BJP', label: 'Bharatiya Janata Party (BJP)' },
    { value: 'INC', label: 'Indian National Congress (INC)' },
    { value: 'AAP', label: 'Aam Aadmi Party (AAP)' },
    { value: 'TMC', label: 'Trinamool Congress (TMC)' },
    { value: 'DMK', label: 'Dravida Munnetra Kazhagam (DMK)' },
    { value: 'Independent', label: 'Independent' }
  ];

  const experienceOptions = [
    { value: '0-5', label: '0-5 years' },
    { value: '6-10', label: '6-10 years' },
    { value: '11-15', label: '11-15 years' },
    { value: '16-20', label: '16-20 years' },
    { value: '20+', label: '20+ years' }
  ];

  const positionOptions = [
    { value: 'MP', label: 'Member of Parliament (MP)' },
    { value: 'MLA', label: 'Member of Legislative Assembly (MLA)' },
    { value: 'MLC', label: 'Member of Legislative Council (MLC)' },
    { value: 'Mayor', label: 'Mayor' },
    { value: 'Councillor', label: 'Councillor' }
  ];

  const committeeOptions = [
    { value: 'finance', label: 'Finance Committee' },
    { value: 'education', label: 'Education Committee' },
    { value: 'health', label: 'Health Committee' },
    { value: 'infrastructure', label: 'Infrastructure Committee' },
    { value: 'environment', label: 'Environment Committee' },
    { value: 'agriculture', label: 'Agriculture Committee' }
  ];

  const handleFilterChange = (key, value) => {
    const newFilters = { ...localFilters, [key]: value };
    setLocalFilters(newFilters);
    onFilterChange(newFilters);
  };

  const handleClearAll = () => {
    const clearedFilters = {
      party: [],
      experience: '',
      position: [],
      committees: [],
      minRating: 0,
      minAttendance: 0,
      hasRecentActivity: false
    };
    setLocalFilters(clearedFilters);
    onFilterChange(clearedFilters);
    onClearAll();
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-modal lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed lg:static top-0 left-0 h-full w-80 bg-card border-r border-border z-sidebar
        transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        overflow-y-auto
      `}>
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-heading font-semibold text-lg text-foreground">
              Advanced Filters
            </h2>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleClearAll}
                className="text-xs"
              >
                Clear All
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="lg:hidden"
              >
                <Icon name="X" size={20} />
              </Button>
            </div>
          </div>

          {/* Filter Sections */}
          <div className="space-y-6">
            {/* Party Filter */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                Political Party
              </label>
              <Select
                options={partyOptions}
                value={localFilters.party}
                onChange={(value) => handleFilterChange('party', value)}
                placeholder="Select parties"
                multiple
                searchable
                clearable
              />
            </div>

            {/* Position Filter */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                Position
              </label>
              <Select
                options={positionOptions}
                value={localFilters.position}
                onChange={(value) => handleFilterChange('position', value)}
                placeholder="Select positions"
                multiple
                clearable
              />
            </div>

            {/* Experience Filter */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                Experience Level
              </label>
              <Select
                options={experienceOptions}
                value={localFilters.experience}
                onChange={(value) => handleFilterChange('experience', value)}
                placeholder="Select experience range"
                clearable
              />
            </div>

            {/* Committee Memberships */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                Committee Memberships
              </label>
              <Select
                options={committeeOptions}
                value={localFilters.committees}
                onChange={(value) => handleFilterChange('committees', value)}
                placeholder="Select committees"
                multiple
                searchable
                clearable
              />
            </div>

            {/* Performance Metrics */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                Minimum Rating
              </label>
              <div className="space-y-2">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <label key={rating} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="minRating"
                      value={rating}
                      checked={localFilters.minRating === rating}
                      onChange={(e) => handleFilterChange('minRating', parseInt(e.target.value))}
                      className="w-4 h-4 text-primary border-border focus:ring-ring"
                    />
                    <div className="flex items-center space-x-1">
                      {[...Array(rating)].map((_, i) => (
                        <Icon key={i} name="Star" size={14} className="text-yellow-500 fill-current" />
                      ))}
                      <span className="text-sm text-muted-foreground">& above</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Attendance Filter */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-3">
                Minimum Attendance Rate
              </label>
              <div className="space-y-2">
                {[50, 60, 70, 80, 90].map((attendance) => (
                  <label key={attendance} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="minAttendance"
                      value={attendance}
                      checked={localFilters.minAttendance === attendance}
                      onChange={(e) => handleFilterChange('minAttendance', parseInt(e.target.value))}
                      className="w-4 h-4 text-primary border-border focus:ring-ring"
                    />
                    <span className="text-sm text-foreground">{attendance}% & above</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Activity Filter */}
            <div>
              <Checkbox
                label="Has Recent Activity (Last 30 days)"
                checked={localFilters.hasRecentActivity}
                onChange={(e) => handleFilterChange('hasRecentActivity', e.target.checked)}
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default FilterSidebar;