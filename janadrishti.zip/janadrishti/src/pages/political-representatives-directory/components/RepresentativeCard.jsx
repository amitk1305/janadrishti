import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const RepresentativeCard = ({ representative, onFollow, onRate }) => {
  const [isFollowing, setIsFollowing] = useState(representative.isFollowing || false);
  const [userRating, setUserRating] = useState(representative.userRating || 0);

  const handleFollow = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsFollowing(!isFollowing);
    onFollow?.(representative.id, !isFollowing);
  };

  const handleRating = (rating, e) => {
    e.preventDefault();
    e.stopPropagation();
    setUserRating(rating);
    onRate?.(representative.id, rating);
  };

  const getPartyColor = (party) => {
    const colors = {
      'BJP': 'bg-orange-100 text-orange-800',
      'INC': 'bg-blue-100 text-blue-800',
      'AAP': 'bg-green-100 text-green-800',
      'TMC': 'bg-cyan-100 text-cyan-800',
      'DMK': 'bg-red-100 text-red-800',
      'Independent': 'bg-gray-100 text-gray-800'
    };
    return colors[party] || 'bg-gray-100 text-gray-800';
  };

  const getPerformanceColor = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Link 
      to="/representative-profile-details" 
      state={{ representative }}
      className="block bg-card border border-border rounded-lg p-4 hover:shadow-civic-lg transition-civic group"
    >
      <div className="flex items-start space-x-3">
        {/* Representative Photo */}
        <div className="flex-shrink-0">
          <div className="w-16 h-16 rounded-full overflow-hidden bg-muted">
            <Image
              src={representative.photo}
              alt={representative.name}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Representative Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className="font-heading font-semibold text-foreground text-lg group-hover:text-primary transition-civic">
                {representative.name}
              </h3>
              <p className="text-sm text-muted-foreground mt-1">
                {representative.position} • {representative.constituency}
              </p>
            </div>
            
            {/* Follow Button */}
            <Button
              variant={isFollowing ? "default" : "outline"}
              size="sm"
              onClick={handleFollow}
              iconName={isFollowing ? "UserCheck" : "UserPlus"}
              iconSize={16}
              className="ml-2"
            >
              {isFollowing ? "Following" : "Follow"}
            </Button>
          </div>

          {/* Party Badge */}
          <div className="mt-2">
            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getPartyColor(representative.party)}`}>
              {representative.party}
            </span>
          </div>

          {/* Performance Metrics */}
          <div className="mt-3 grid grid-cols-2 gap-3">
            <div className="text-center">
              <div className={`text-lg font-bold ${getPerformanceColor(representative.attendanceRate)}`}>
                {representative.attendanceRate}%
              </div>
              <div className="text-xs text-muted-foreground">Attendance</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-foreground">
                {representative.billsIntroduced}
              </div>
              <div className="text-xs text-muted-foreground">Bills</div>
            </div>
          </div>

          {/* Rating System */}
          <div className="mt-3 flex items-center justify-between">
            <div className="flex items-center space-x-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={(e) => handleRating(star, e)}
                  className="p-1 hover:scale-110 transition-transform"
                >
                  <Icon
                    name="Star"
                    size={16}
                    className={`${
                      star <= (userRating || representative.publicRating)
                        ? 'text-yellow-500 fill-current' :'text-gray-300'
                    } transition-colors`}
                  />
                </button>
              ))}
              <span className="text-sm text-muted-foreground ml-2">
                ({representative.totalRatings})
              </span>
            </div>
            
            <div className="text-sm text-muted-foreground">
              {representative.experience} years
            </div>
          </div>

          {/* Quick Stats */}
          <div className="mt-3 pt-3 border-t border-border">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span className="flex items-center">
                <Icon name="Users" size={12} className="mr-1" />
                {representative.followers} followers
              </span>
              <span className="flex items-center">
                <Icon name="MessageSquare" size={12} className="mr-1" />
                {representative.recentUpdates} updates
              </span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default RepresentativeCard;