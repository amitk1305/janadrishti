import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const SearchAndFilters = ({ 
  searchQuery, 
  onSearchChange, 
  locationFilters, 
  onLocationChange, 
  activeFilters, 
  onClearFilter,
  onToggleAdvancedFilters 
}) => {
  const [localSearch, setLocalSearch] = useState(searchQuery);

  const stateOptions = [
    { value: 'delhi', label: 'Delhi' },
    { value: 'maharashtra', label: 'Maharashtra' },
    { value: 'karnataka', label: 'Karnataka' },
    { value: 'tamil-nadu', label: 'Tamil Nadu' },
    { value: 'west-bengal', label: 'West Bengal' },
    { value: 'gujarat', label: 'Gujarat' },
    { value: 'rajasthan', label: 'Rajasthan' },
    { value: 'uttar-pradesh', label: 'Uttar Pradesh' }
  ];

  const constituencyOptions = {
    'delhi': [
      { value: 'new-delhi', label: 'New Delhi' },
      { value: 'chandni-chowk', label: 'Chandni Chowk' },
      { value: 'east-delhi', label: 'East Delhi' },
      { value: 'north-east-delhi', label: 'North East Delhi' },
      { value: 'north-west-delhi', label: 'North West Delhi' },
      { value: 'south-delhi', label: 'South Delhi' },
      { value: 'west-delhi', label: 'West Delhi' }
    ],
    'maharashtra': [
      { value: 'mumbai-north', label: 'Mumbai North' },
      { value: 'mumbai-south', label: 'Mumbai South' },
      { value: 'pune', label: 'Pune' },
      { value: 'nagpur', label: 'Nagpur' },
      { value: 'nashik', label: 'Nashik' }
    ],
    'karnataka': [
      { value: 'bangalore-north', label: 'Bangalore North' },
      { value: 'bangalore-south', label: 'Bangalore South' },
      { value: 'mysore', label: 'Mysore' },
      { value: 'mangalore', label: 'Mangalore' }
    ]
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    onSearchChange(localSearch);
  };

  const getActiveFilterCount = () => {
    return Object.values(activeFilters).filter(filter => {
      if (Array.isArray(filter)) return filter.length > 0;
      if (typeof filter === 'boolean') return filter;
      return filter !== '' && filter !== 0;
    }).length;
  };

  return (
    <div className="bg-card border-b border-border p-4 lg:p-6">
      {/* Search Bar */}
      <form onSubmit={handleSearchSubmit} className="mb-4">
        <div className="relative">
          <Icon 
            name="Search" 
            size={20} 
            className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
          />
          <input
            type="text"
            placeholder="Search representatives by name, constituency, or party..."
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent font-body text-foreground placeholder-muted-foreground"
          />
          <Button
            type="submit"
            variant="ghost"
            size="icon"
            className="absolute right-2 top-1/2 transform -translate-y-1/2"
          >
            <Icon name="Search" size={20} />
          </Button>
        </div>
      </form>

      {/* Location Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
        <Select
          label="State"
          options={stateOptions}
          value={locationFilters.state}
          onChange={(value) => onLocationChange('state', value)}
          placeholder="Select state"
          clearable
        />
        
        <Select
          label="Constituency"
          options={constituencyOptions[locationFilters.state] || []}
          value={locationFilters.constituency}
          onChange={(value) => onLocationChange('constituency', value)}
          placeholder="Select constituency"
          disabled={!locationFilters.state}
          clearable
        />
        
        <div className="flex items-end">
          <Button
            variant="outline"
            onClick={onToggleAdvancedFilters}
            iconName="Filter"
            iconPosition="left"
            className="w-full"
          >
            Advanced Filters
            {getActiveFilterCount() > 0 && (
              <span className="ml-2 bg-primary text-primary-foreground text-xs rounded-full px-2 py-1">
                {getActiveFilterCount()}
              </span>
            )}
          </Button>
        </div>
      </div>

      {/* Active Filter Chips */}
      {getActiveFilterCount() > 0 && (
        <div className="flex flex-wrap gap-2">
          {activeFilters.party?.map((party) => (
            <div
              key={party}
              className="inline-flex items-center bg-primary/10 text-primary px-3 py-1 rounded-full text-sm"
            >
              <span>{party}</span>
              <button
                onClick={() => onClearFilter('party', party)}
                className="ml-2 hover:bg-primary/20 rounded-full p-1"
              >
                <Icon name="X" size={12} />
              </button>
            </div>
          ))}
          
          {activeFilters.position?.map((position) => (
            <div
              key={position}
              className="inline-flex items-center bg-accent/10 text-accent px-3 py-1 rounded-full text-sm"
            >
              <span>{position}</span>
              <button
                onClick={() => onClearFilter('position', position)}
                className="ml-2 hover:bg-accent/20 rounded-full p-1"
              >
                <Icon name="X" size={12} />
              </button>
            </div>
          ))}
          
          {activeFilters.minRating > 0 && (
            <div className="inline-flex items-center bg-warning/10 text-warning px-3 py-1 rounded-full text-sm">
              <span>{activeFilters.minRating}+ stars</span>
              <button
                onClick={() => onClearFilter('minRating')}
                className="ml-2 hover:bg-warning/20 rounded-full p-1"
              >
                <Icon name="X" size={12} />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchAndFilters;