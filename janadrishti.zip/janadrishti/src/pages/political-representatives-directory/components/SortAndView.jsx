import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const SortAndView = ({ 
  sortBy, 
  onSortChange, 
  viewMode, 
  onViewModeChange, 
  resultsCount,
  isLoading 
}) => {
  const sortOptions = [
    { value: 'name-asc', label: 'Name (A-Z)' },
    { value: 'name-desc', label: 'Name (Z-A)' },
    { value: 'rating-desc', label: 'Highest Rated' },
    { value: 'rating-asc', label: 'Lowest Rated' },
    { value: 'constituency-asc', label: 'Constituency (A-Z)' },
    { value: 'experience-desc', label: 'Most Experienced' },
    { value: 'attendance-desc', label: 'Best Attendance' },
    { value: 'recent-activity', label: 'Recent Activity' }
  ];

  return (
    <div className="bg-card border-b border-border p-4 lg:px-6 lg:py-4">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        {/* Results Count */}
        <div className="flex items-center space-x-4">
          <div className="text-sm text-muted-foreground font-body">
            {isLoading ? (
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                <span>Loading representatives...</span>
              </div>
            ) : (
              <span>
                Showing <span className="font-semibold text-foreground">{resultsCount}</span> representatives
              </span>
            )}
          </div>
        </div>

        {/* Sort and View Controls */}
        <div className="flex items-center space-x-4">
          {/* Sort Dropdown */}
          <div className="flex items-center space-x-2">
            <Icon name="ArrowUpDown" size={16} className="text-muted-foreground" />
            <Select
              options={sortOptions}
              value={sortBy}
              onChange={onSortChange}
              placeholder="Sort by"
              className="w-48"
            />
          </div>

          {/* View Mode Toggle */}
          <div className="hidden lg:flex items-center space-x-1 bg-muted rounded-lg p-1">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => onViewModeChange('grid')}
              iconName="Grid3X3"
              iconSize={16}
              className="px-3"
            >
              Grid
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => onViewModeChange('list')}
              iconName="List"
              iconSize={16}
              className="px-3"
            >
              List
            </Button>
          </div>

          {/* Refresh Button */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.location.reload()}
            iconName="RefreshCw"
            iconSize={16}
            className="px-3"
          >
            <span className="hidden lg:inline ml-2">Refresh</span>
          </Button>
        </div>
      </div>

      {/* Mobile View Mode Toggle */}
      <div className="lg:hidden mt-4 flex items-center justify-center">
        <div className="flex items-center space-x-1 bg-muted rounded-lg p-1">
          <Button
            variant={viewMode === 'grid' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => onViewModeChange('grid')}
            iconName="Grid3X3"
            iconSize={16}
            className="px-4"
          >
            Grid
          </Button>
          <Button
            variant={viewMode === 'list' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => onViewModeChange('list')}
            iconName="List"
            iconSize={16}
            className="px-4"
          >
            List
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SortAndView;