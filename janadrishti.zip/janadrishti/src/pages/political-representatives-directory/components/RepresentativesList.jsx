import React, { useState, useEffect } from 'react';
import RepresentativeCard from './RepresentativeCard';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RepresentativesList = ({ 
  representatives, 
  viewMode, 
  isLoading, 
  hasMore, 
  onLoadMore,
  onFollow,
  onRate 
}) => {
  const [displayedRepresentatives, setDisplayedRepresentatives] = useState([]);
  const [loadingMore, setLoadingMore] = useState(false);

  useEffect(() => {
    setDisplayedRepresentatives(representatives);
  }, [representatives]);

  const handleLoadMore = async () => {
    setLoadingMore(true);
    await onLoadMore();
    setLoadingMore(false);
  };

  const SkeletonCard = () => (
    <div className="bg-card border border-border rounded-lg p-4 animate-pulse">
      <div className="flex items-start space-x-3">
        <div className="w-16 h-16 bg-muted rounded-full"></div>
        <div className="flex-1 space-y-2">
          <div className="h-4 bg-muted rounded w-3/4"></div>
          <div className="h-3 bg-muted rounded w-1/2"></div>
          <div className="h-3 bg-muted rounded w-1/4"></div>
          <div className="grid grid-cols-2 gap-3 mt-3">
            <div className="text-center">
              <div className="h-6 bg-muted rounded w-12 mx-auto"></div>
              <div className="h-3 bg-muted rounded w-16 mx-auto mt-1"></div>
            </div>
            <div className="text-center">
              <div className="h-6 bg-muted rounded w-8 mx-auto"></div>
              <div className="h-3 bg-muted rounded w-12 mx-auto mt-1"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  if (isLoading && displayedRepresentatives.length === 0) {
    return (
      <div className="p-6">
        <div className={`grid gap-6 ${
          viewMode === 'grid' ?'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' :'grid-cols-1'
        }`}>
          {[...Array(8)].map((_, index) => (
            <SkeletonCard key={index} />
          ))}
        </div>
      </div>
    );
  }

  if (!isLoading && displayedRepresentatives.length === 0) {
    return (
      <div className="p-12 text-center">
        <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="Users" size={32} className="text-muted-foreground" />
        </div>
        <h3 className="font-heading font-semibold text-lg text-foreground mb-2">
          No Representatives Found
        </h3>
        <p className="text-muted-foreground font-body mb-6 max-w-md mx-auto">
          We couldn't find any representatives matching your current filters. 
          Try adjusting your search criteria or clearing some filters.
        </p>
        <Button variant="outline" onClick={() => window.location.reload()}>
          Reset Filters
        </Button>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* Representatives Grid/List */}
      <div className={`grid gap-6 ${
        viewMode === 'grid' ?'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' :'grid-cols-1 max-w-4xl mx-auto'
      }`}>
        {displayedRepresentatives.map((representative) => (
          <RepresentativeCard
            key={representative.id}
            representative={representative}
            onFollow={onFollow}
            onRate={onRate}
          />
        ))}
      </div>

      {/* Load More Section */}
      {hasMore && (
        <div className="mt-8 text-center">
          <Button
            variant="outline"
            onClick={handleLoadMore}
            disabled={loadingMore}
            loading={loadingMore}
            iconName="ChevronDown"
            iconPosition="right"
          >
            {loadingMore ? 'Loading more...' : 'Load More Representatives'}
          </Button>
        </div>
      )}

      {/* Loading More Skeletons */}
      {loadingMore && (
        <div className={`grid gap-6 mt-6 ${
          viewMode === 'grid' ?'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' :'grid-cols-1'
        }`}>
          {[...Array(4)].map((_, index) => (
            <SkeletonCard key={`loading-${index}`} />
          ))}
        </div>
      )}

      {/* End of Results */}
      {!hasMore && displayedRepresentatives.length > 0 && (
        <div className="mt-8 text-center py-6 border-t border-border">
          <Icon name="CheckCircle" size={24} className="text-accent mx-auto mb-2" />
          <p className="text-muted-foreground font-body">
            You've reached the end of the results
          </p>
        </div>
      )}
    </div>
  );
};

export default RepresentativesList;