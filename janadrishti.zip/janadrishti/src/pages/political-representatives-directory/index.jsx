import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Navigation from '../../components/ui/Navigation';
import Breadcrumb from '../../components/ui/Breadcrumb';
import StatsHeader from './components/StatsHeader';
import SearchAndFilters from './components/SearchAndFilters';
import FilterSidebar from './components/FilterSidebar';
import SortAndView from './components/SortAndView';
import RepresentativesList from './components/RepresentativesList';

const PoliticalRepresentativesDirectory = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [locationFilters, setLocationFilters] = useState({
    state: '',
    constituency: ''
  });
  const [advancedFilters, setAdvancedFilters] = useState({
    party: [],
    experience: '',
    position: [],
    committees: [],
    minRating: 0,
    minAttendance: 0,
    hasRecentActivity: false
  });
  const [sortBy, setSortBy] = useState('name-asc');
  const [viewMode, setViewMode] = useState('grid');
  const [isFilterSidebarOpen, setIsFilterSidebarOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [hasMore, setHasMore] = useState(true);

  // Mock representatives data
  const mockRepresentatives = [
    {
      id: 1,
      name: "Rajesh Kumar Sharma",
      party: "BJP",
      constituency: "New Delhi",
      position: "Member of Parliament (MP)",
      photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      attendanceRate: 87,
      billsIntroduced: 12,
      publicRating: 4.2,
      totalRatings: 1247,
      experience: 8,
      followers: 15420,
      recentUpdates: 23,
      isFollowing: false,
      userRating: 0
    },
    {
      id: 2,
      name: "Priya Patel",
      party: "INC",
      constituency: "Mumbai North",
      position: "Member of Legislative Assembly (MLA)",
      photo: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      attendanceRate: 92,
      billsIntroduced: 8,
      publicRating: 4.5,
      totalRatings: 892,
      experience: 5,
      followers: 12350,
      recentUpdates: 18,
      isFollowing: true,
      userRating: 5
    },
    {
      id: 3,
      name: "Arvind Singh",
      party: "AAP",
      constituency: "East Delhi",
      position: "Member of Legislative Assembly (MLA)",
      photo: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      attendanceRate: 95,
      billsIntroduced: 15,
      publicRating: 4.7,
      totalRatings: 2156,
      experience: 6,
      followers: 18750,
      recentUpdates: 31,
      isFollowing: false,
      userRating: 0
    },
    {
      id: 4,
      name: "Meera Devi",
      party: "TMC",
      constituency: "Kolkata South",
      position: "Member of Parliament (MP)",
      photo: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      attendanceRate: 78,
      billsIntroduced: 6,
      publicRating: 3.8,
      totalRatings: 654,
      experience: 12,
      followers: 9840,
      recentUpdates: 14,
      isFollowing: false,
      userRating: 0
    },
    {
      id: 5,
      name: "Suresh Reddy",
      party: "DMK",
      constituency: "Chennai Central",
      position: "Member of Parliament (MP)",
      photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face",
      attendanceRate: 84,
      billsIntroduced: 10,
      publicRating: 4.1,
      totalRatings: 1089,
      experience: 15,
      followers: 13670,
      recentUpdates: 27,
      isFollowing: true,
      userRating: 4
    },
    {
      id: 6,
      name: "Kavita Joshi",
      party: "Independent",
      constituency: "Pune",
      position: "Mayor",
      photo: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face",
      attendanceRate: 89,
      billsIntroduced: 4,
      publicRating: 4.3,
      totalRatings: 567,
      experience: 3,
      followers: 7890,
      recentUpdates: 12,
      isFollowing: false,
      userRating: 0
    },
    {
      id: 7,
      name: "Ramesh Gupta",
      party: "BJP",
      constituency: "Bangalore North",
      position: "Member of Legislative Assembly (MLA)",
      photo: "https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=150&h=150&fit=crop&crop=face",
      attendanceRate: 91,
      billsIntroduced: 9,
      publicRating: 4.0,
      totalRatings: 934,
      experience: 7,
      followers: 11230,
      recentUpdates: 19,
      isFollowing: false,
      userRating: 0
    },
    {
      id: 8,
      name: "Anita Verma",
      party: "INC",
      constituency: "Jaipur",
      position: "Member of Legislative Assembly (MLA)",
      photo: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=150&h=150&fit=crop&crop=face",
      attendanceRate: 86,
      billsIntroduced: 7,
      publicRating: 3.9,
      totalRatings: 723,
      experience: 4,
      followers: 8950,
      recentUpdates: 16,
      isFollowing: false,
      userRating: 0
    }
  ];

  const [representatives, setRepresentatives] = useState([]);
  const [filteredRepresentatives, setFilteredRepresentatives] = useState([]);

  // Initialize data
  useEffect(() => {
    const loadInitialData = async () => {
      setIsLoading(true);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      setRepresentatives(mockRepresentatives);
      setFilteredRepresentatives(mockRepresentatives);
      setIsLoading(false);
    };

    loadInitialData();
  }, []);

  // Filter and search logic
  useEffect(() => {
    let filtered = [...representatives];

    // Apply search filter
    if (searchQuery.trim()) {
      filtered = filtered.filter(rep => 
        rep.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rep.constituency.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rep.party.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Apply location filters
    if (locationFilters.state) {
      // Mock filtering by state - in real app, this would be more sophisticated
      filtered = filtered.filter(rep => 
        rep.constituency.toLowerCase().includes(locationFilters.state.toLowerCase())
      );
    }

    if (locationFilters.constituency) {
      filtered = filtered.filter(rep => 
        rep.constituency.toLowerCase().includes(locationFilters.constituency.toLowerCase())
      );
    }

    // Apply advanced filters
    if (advancedFilters.party.length > 0) {
      filtered = filtered.filter(rep => 
        advancedFilters.party.includes(rep.party)
      );
    }

    if (advancedFilters.position.length > 0) {
      filtered = filtered.filter(rep => 
        advancedFilters.position.includes(rep.position)
      );
    }

    if (advancedFilters.minRating > 0) {
      filtered = filtered.filter(rep => 
        rep.publicRating >= advancedFilters.minRating
      );
    }

    if (advancedFilters.minAttendance > 0) {
      filtered = filtered.filter(rep => 
        rep.attendanceRate >= advancedFilters.minAttendance
      );
    }

    // Apply sorting
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'name-asc':
          return a.name.localeCompare(b.name);
        case 'name-desc':
          return b.name.localeCompare(a.name);
        case 'rating-desc':
          return b.publicRating - a.publicRating;
        case 'rating-asc':
          return a.publicRating - b.publicRating;
        case 'constituency-asc':
          return a.constituency.localeCompare(b.constituency);
        case 'experience-desc':
          return b.experience - a.experience;
        case 'attendance-desc':
          return b.attendanceRate - a.attendanceRate;
        case 'recent-activity':
          return b.recentUpdates - a.recentUpdates;
        default:
          return 0;
      }
    });

    setFilteredRepresentatives(filtered);
  }, [representatives, searchQuery, locationFilters, advancedFilters, sortBy]);

  const handleSearchChange = (query) => {
    setSearchQuery(query);
  };

  const handleLocationChange = (key, value) => {
    setLocationFilters(prev => ({
      ...prev,
      [key]: value,
      // Clear constituency when state changes
      ...(key === 'state' && { constituency: '' })
    }));
  };

  const handleAdvancedFilterChange = (filters) => {
    setAdvancedFilters(filters);
  };

  const handleClearFilter = (filterType, value) => {
    if (filterType === 'party') {
      setAdvancedFilters(prev => ({
        ...prev,
        party: prev.party.filter(p => p !== value)
      }));
    } else if (filterType === 'position') {
      setAdvancedFilters(prev => ({
        ...prev,
        position: prev.position.filter(p => p !== value)
      }));
    } else if (filterType === 'minRating') {
      setAdvancedFilters(prev => ({
        ...prev,
        minRating: 0
      }));
    }
  };

  const handleClearAllFilters = () => {
    setAdvancedFilters({
      party: [],
      experience: '',
      position: [],
      committees: [],
      minRating: 0,
      minAttendance: 0,
      hasRecentActivity: false
    });
    setLocationFilters({
      state: '',
      constituency: ''
    });
    setSearchQuery('');
  };

  const handleFollow = (representativeId, isFollowing) => {
    setRepresentatives(prev => 
      prev.map(rep => 
        rep.id === representativeId 
          ? { ...rep, isFollowing, followers: rep.followers + (isFollowing ? 1 : -1) }
          : rep
      )
    );
  };

  const handleRate = (representativeId, rating) => {
    setRepresentatives(prev => 
      prev.map(rep => 
        rep.id === representativeId 
          ? { ...rep, userRating: rating }
          : rep
      )
    );
  };

  const handleLoadMore = async () => {
    // Simulate loading more data
    await new Promise(resolve => setTimeout(resolve, 1000));
    // In real app, this would fetch more data
    setHasMore(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Navigation />
      
      <main className="pt-16 lg:pt-30 pb-16 lg:pb-0">
        <div className="max-w-7xl mx-auto">
          <div className="px-4 lg:px-6 py-4">
            <Breadcrumb />
          </div>
          
          <StatsHeader />
          
          <SearchAndFilters
            searchQuery={searchQuery}
            onSearchChange={handleSearchChange}
            locationFilters={locationFilters}
            onLocationChange={handleLocationChange}
            activeFilters={advancedFilters}
            onClearFilter={handleClearFilter}
            onToggleAdvancedFilters={() => setIsFilterSidebarOpen(true)}
          />
          
          <div className="flex">
            <FilterSidebar
              isOpen={isFilterSidebarOpen}
              onClose={() => setIsFilterSidebarOpen(false)}
              filters={advancedFilters}
              onFilterChange={handleAdvancedFilterChange}
              onClearAll={handleClearAllFilters}
            />
            
            <div className="flex-1">
              <SortAndView
                sortBy={sortBy}
                onSortChange={setSortBy}
                viewMode={viewMode}
                onViewModeChange={setViewMode}
                resultsCount={filteredRepresentatives.length}
                isLoading={isLoading}
              />
              
              <RepresentativesList
                representatives={filteredRepresentatives}
                viewMode={viewMode}
                isLoading={isLoading}
                hasMore={hasMore}
                onLoadMore={handleLoadMore}
                onFollow={handleFollow}
                onRate={handleRate}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default PoliticalRepresentativesDirectory;