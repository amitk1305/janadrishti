import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ShareModal = ({ isOpen, onClose, representative }) => {
  const [copied, setCopied] = useState(false);

  const shareUrl = `${window.location.origin}/representative-profile-details?id=${representative.id}`;
  const shareText = `Check out ${representative.name}'s profile - ${representative.designation} representing ${representative.constituency}`;

  const socialPlatforms = [
    {
      name: "WhatsApp",
      icon: "MessageCircle",
      color: "text-green-600",
      url: `https://wa.me/?text=${encodeURIComponent(shareText + " " + shareUrl)}`
    },
    {
      name: "Twitter",
      icon: "Twitter",
      color: "text-blue-400",
      url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`
    },
    {
      name: "Facebook",
      icon: "Facebook",
      color: "text-blue-600",
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`
    },
    {
      name: "LinkedIn",
      icon: "Linkedin",
      color: "text-blue-700",
      url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`
    },
    {
      name: "Telegram",
      icon: "Send",
      color: "text-blue-500",
      url: `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`
    },
    {
      name: "Email",
      icon: "Mail",
      color: "text-gray-600",
      url: `mailto:?subject=${encodeURIComponent(`Representative Profile: ${representative.name}`)}&body=${encodeURIComponent(shareText + "\n\n" + shareUrl)}`
    }
  ];

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy link:', err);
    }
  };

  const handleSocialShare = (platform) => {
    window.open(platform.url, '_blank', 'width=600,height=400');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-modal flex items-center justify-center p-4">
      <div className="bg-card rounded-lg max-w-md w-full">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-heading font-semibold text-foreground">
              Share Profile
            </h2>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <Icon name="X" size={20} />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Representative Info */}
          <div className="text-center">
            <h3 className="font-body font-semibold text-foreground">
              {representative.name}
            </h3>
            <p className="text-sm text-muted-foreground">
              {representative.designation} • {representative.constituency}
            </p>
          </div>

          {/* Social Platforms */}
          <div>
            <h4 className="font-body font-medium text-foreground mb-3">
              Share on Social Media
            </h4>
            <div className="grid grid-cols-3 gap-3">
              {socialPlatforms.map((platform) => (
                <button
                  key={platform.name}
                  onClick={() => handleSocialShare(platform)}
                  className="flex flex-col items-center space-y-2 p-4 rounded-lg border border-border hover:border-muted-foreground hover:bg-muted transition-civic"
                >
                  <Icon name={platform.icon} size={24} className={platform.color} />
                  <span className="text-xs font-body text-muted-foreground">
                    {platform.name}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Copy Link */}
          <div>
            <h4 className="font-body font-medium text-foreground mb-3">
              Copy Link
            </h4>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={shareUrl}
                readOnly
                className="flex-1 p-3 bg-muted border border-border rounded-lg text-sm font-mono text-muted-foreground"
              />
              <Button
                variant={copied ? "success" : "outline"}
                onClick={handleCopyLink}
                iconName={copied ? "Check" : "Copy"}
                size="sm"
              >
                {copied ? "Copied!" : "Copy"}
              </Button>
            </div>
          </div>

          {/* QR Code Option */}
          <div className="text-center">
            <Button variant="ghost" size="sm" iconName="QrCode">
              Generate QR Code
            </Button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border">
          <p className="text-xs text-muted-foreground text-center">
            Help others stay informed about their representatives
          </p>
        </div>
      </div>
    </div>
  );
};

export default ShareModal;