import React from 'react';
import Icon from '../../../components/AppIcon';


const OverviewTab = ({ representative }) => {
  return (
    <div className="space-y-8">
      {/* Biography */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
          Biography
        </h3>
        <p className="text-muted-foreground font-body leading-relaxed">
          {representative.biography}
        </p>
      </div>

      {/* Committee Memberships */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
          Committee Memberships
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {representative.committees.map((committee, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 bg-muted rounded-lg">
              <Icon name="Users" size={16} className="text-primary mt-1" />
              <div>
                <h4 className="font-body font-medium text-foreground">
                  {committee.name}
                </h4>
                <p className="text-sm text-muted-foreground">{committee.role}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Since {committee.since}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Activities */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
          Recent Activities
        </h3>
        <div className="space-y-4">
          {representative.recentActivities.map((activity, index) => (
            <div key={index} className="flex items-start space-x-4 pb-4 border-b border-border last:border-b-0">
              <div className="flex-shrink-0 w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                <Icon name={activity.icon} size={16} className="text-primary" />
              </div>
              <div className="flex-1">
                <h4 className="font-body font-medium text-foreground">
                  {activity.title}
                </h4>
                <p className="text-sm text-muted-foreground mt-1">
                  {activity.description}
                </p>
                <div className="flex items-center space-x-4 mt-2">
                  <span className="text-xs text-muted-foreground">
                    {activity.date}
                  </span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    activity.type === 'bill' ? 'bg-primary/10 text-primary' :
                    activity.type === 'question'? 'bg-warning/10 text-warning' : 'bg-accent/10 text-accent'
                  }`}>
                    {activity.type}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Education & Background */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-lg p-6 border border-border">
          <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
            Education
          </h3>
          <div className="space-y-3">
            {representative.education.map((edu, index) => (
              <div key={index} className="flex items-start space-x-3">
                <Icon name="GraduationCap" size={16} className="text-primary mt-1" />
                <div>
                  <h4 className="font-body font-medium text-foreground">
                    {edu.degree}
                  </h4>
                  <p className="text-sm text-muted-foreground">{edu.institution}</p>
                  <p className="text-xs text-muted-foreground">{edu.year}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border">
          <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
            Professional Background
          </h3>
          <div className="space-y-3">
            {representative.professionalBackground.map((job, index) => (
              <div key={index} className="flex items-start space-x-3">
                <Icon name="Briefcase" size={16} className="text-primary mt-1" />
                <div>
                  <h4 className="font-body font-medium text-foreground">
                    {job.position}
                  </h4>
                  <p className="text-sm text-muted-foreground">{job.organization}</p>
                  <p className="text-xs text-muted-foreground">{job.duration}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OverviewTab;