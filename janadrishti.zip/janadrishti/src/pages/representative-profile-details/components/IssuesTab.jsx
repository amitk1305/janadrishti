import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const IssuesTab = ({ issues }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");

  const statusOptions = [
    { value: "all", label: "All Status" },
    { value: "pending", label: "Pending" },
    { value: "in-progress", label: "In Progress" },
    { value: "resolved", label: "Resolved" },
    { value: "rejected", label: "Rejected" }
  ];

  const categoryOptions = [
    { value: "all", label: "All Categories" },
    { value: "infrastructure", label: "Infrastructure" },
    { value: "healthcare", label: "Healthcare" },
    { value: "education", label: "Education" },
    { value: "water", label: "Water Supply" },
    { value: "electricity", label: "Electricity" },
    { value: "transport", label: "Transportation" },
    { value: "environment", label: "Environment" },
    { value: "other", label: "Other" }
  ];

  const filteredIssues = issues.filter(issue => {
    const matchesSearch = issue.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         issue.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || issue.status === filterStatus;
    const matchesCategory = filterCategory === "all" || issue.category === filterCategory;
    
    return matchesSearch && matchesStatus && matchesCategory;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending':
        return 'bg-warning/10 text-warning';
      case 'in-progress':
        return 'bg-primary/10 text-primary';
      case 'resolved':
        return 'bg-success/10 text-success';
      case 'rejected':
        return 'bg-destructive/10 text-destructive';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return 'Clock';
      case 'in-progress':
        return 'RefreshCw';
      case 'resolved':
        return 'CheckCircle';
      case 'rejected':
        return 'XCircle';
      default:
        return 'HelpCircle';
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'infrastructure':
        return 'Building';
      case 'healthcare':
        return 'Heart';
      case 'education':
        return 'GraduationCap';
      case 'water':
        return 'Droplets';
      case 'electricity':
        return 'Zap';
      case 'transport':
        return 'Car';
      case 'environment':
        return 'Leaf';
      default:
        return 'AlertTriangle';
    }
  };

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Input
            type="search"
            placeholder="Search issues..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full"
          />
          <Select
            options={statusOptions}
            value={filterStatus}
            onChange={setFilterStatus}
            placeholder="Filter by status"
          />
          <Select
            options={categoryOptions}
            value={filterCategory}
            onChange={setFilterCategory}
            placeholder="Filter by category"
          />
        </div>
      </div>

      {/* Issue Statistics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-card rounded-lg p-4 text-center border border-border">
          <div className="text-2xl font-heading font-bold text-warning">
            {issues.filter(i => i.status === 'pending').length}
          </div>
          <div className="text-sm text-muted-foreground mt-1">Pending</div>
        </div>
        <div className="bg-card rounded-lg p-4 text-center border border-border">
          <div className="text-2xl font-heading font-bold text-primary">
            {issues.filter(i => i.status === 'in-progress').length}
          </div>
          <div className="text-sm text-muted-foreground mt-1">In Progress</div>
        </div>
        <div className="bg-card rounded-lg p-4 text-center border border-border">
          <div className="text-2xl font-heading font-bold text-success">
            {issues.filter(i => i.status === 'resolved').length}
          </div>
          <div className="text-sm text-muted-foreground mt-1">Resolved</div>
        </div>
        <div className="bg-card rounded-lg p-4 text-center border border-border">
          <div className="text-2xl font-heading font-bold text-muted-foreground">
            {issues.length}
          </div>
          <div className="text-sm text-muted-foreground mt-1">Total Issues</div>
        </div>
      </div>

      {/* Issues List */}
      <div className="space-y-4">
        {filteredIssues.map((issue, index) => (
          <div key={index} className="bg-card rounded-lg p-6 border border-border hover:shadow-civic transition-civic">
            <div className="flex items-start space-x-4">
              {/* Issue Image */}
              {issue.image && (
                <div className="flex-shrink-0">
                  <Image
                    src={issue.image}
                    alt={issue.title}
                    className="w-20 h-20 rounded-lg object-cover"
                  />
                </div>
              )}

              {/* Issue Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between space-x-4">
                  <div className="flex-1">
                    <h3 className="font-body font-semibold text-foreground">
                      {issue.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                      {issue.description}
                    </p>
                    
                    <div className="flex flex-wrap items-center gap-3 mt-3">
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(issue.status)}`}>
                        <Icon name={getStatusIcon(issue.status)} size={12} className="inline mr-1" />
                        {issue.status.charAt(0).toUpperCase() + issue.status.slice(1)}
                      </span>
                      <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                        <Icon name={getCategoryIcon(issue.category)} size={12} className="inline mr-1" />
                        {issue.category}
                      </span>
                      <span className="text-xs text-muted-foreground flex items-center">
                        <Icon name="MapPin" size={12} className="mr-1" />
                        {issue.location}
                      </span>
                      <span className="text-xs text-muted-foreground flex items-center">
                        <Icon name="Calendar" size={12} className="mr-1" />
                        {issue.reportedDate}
                      </span>
                    </div>

                    {/* Reporter Info */}
                    <div className="flex items-center space-x-2 mt-3">
                      <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                        <Icon name="User" size={12} color="white" />
                      </div>
                      <span className="text-xs text-muted-foreground">
                        Reported by {issue.reportedBy}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        • {issue.upvotes} upvotes
                      </span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm" iconName="ThumbsUp">
                      {issue.upvotes}
                    </Button>
                    <Button variant="ghost" size="sm" iconName="MessageSquare">
                      {issue.comments}
                    </Button>
                    <Button variant="ghost" size="sm" iconName="Share2">
                      Share
                    </Button>
                  </div>
                </div>

                {/* Progress Updates */}
                {issue.updates && issue.updates.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <h4 className="text-sm font-body font-medium text-foreground mb-2">
                      Recent Updates
                    </h4>
                    <div className="space-y-2">
                      {issue.updates.slice(0, 2).map((update, updateIndex) => (
                        <div key={updateIndex} className="flex items-start space-x-2">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                          <div>
                            <p className="text-sm text-muted-foreground">
                              {update.message}
                            </p>
                            <span className="text-xs text-muted-foreground">
                              {update.date}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredIssues.length === 0 && (
        <div className="bg-card rounded-lg p-12 text-center border border-border">
          <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground font-body">
            No issues found matching your criteria
          </p>
        </div>
      )}
    </div>
  );
};

export default IssuesTab;