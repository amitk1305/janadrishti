import React from 'react';
import Icon from '../../../components/AppIcon';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

const PerformanceTab = ({ performanceData }) => {
  const attendanceData = [
    { month: 'Jan', attendance: 85 },
    { month: 'Feb', attendance: 92 },
    { month: 'Mar', attendance: 78 },
    { month: 'Apr', attendance: 95 },
    { month: 'May', attendance: 88 },
    { month: 'Jun', attendance: 91 }
  ];

  const activityData = [
    { category: 'Bills Introduced', count: 12 },
    { category: 'Questions Raised', count: 45 },
    { category: 'Debates Participated', count: 28 },
    { category: 'Committee Meetings', count: 35 }
  ];

  const fundUtilizationData = [
    { name: 'Utilized', value: 75, color: '#10B981' },
    { name: 'Remaining', value: 25, color: '#E5E7EB' }
  ];

  const performanceMetrics = [
    {
      title: 'Parliamentary Attendance',
      value: '89%',
      change: '+5%',
      trend: 'up',
      icon: 'Calendar',
      color: 'text-success'
    },
    {
      title: 'Bills Introduced',
      value: '12',
      change: '+3',
      trend: 'up',
      icon: 'FileText',
      color: 'text-primary'
    },
    {
      title: 'Questions Raised',
      value: '45',
      change: '+8',
      trend: 'up',
      icon: 'HelpCircle',
      color: 'text-warning'
    },
    {
      title: 'Constituency Visits',
      value: '24',
      change: '+2',
      trend: 'up',
      icon: 'MapPin',
      color: 'text-accent'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {performanceMetrics.map((metric, index) => (
          <div key={index} className="bg-card rounded-lg p-6 border border-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 rounded-lg bg-muted flex items-center justify-center`}>
                  <Icon name={metric.icon} size={20} className={metric.color} />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{metric.title}</p>
                  <p className="text-2xl font-heading font-bold text-foreground">
                    {metric.value}
                  </p>
                </div>
              </div>
              <div className={`flex items-center space-x-1 ${
                metric.trend === 'up' ? 'text-success' : 'text-destructive'
              }`}>
                <Icon name={metric.trend === 'up' ? 'TrendingUp' : 'TrendingDown'} size={16} />
                <span className="text-sm font-medium">{metric.change}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Attendance Chart */}
        <div className="bg-card rounded-lg p-6 border border-border">
          <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
            Monthly Attendance Trend
          </h3>
          <div className="w-full h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={attendanceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="month" stroke="#6B7280" />
                <YAxis stroke="#6B7280" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#FFFFFF', 
                    border: '1px solid #E5E7EB',
                    borderRadius: '8px'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="attendance" 
                  stroke="#1E3A8A" 
                  strokeWidth={3}
                  dot={{ fill: '#1E3A8A', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Activity Chart */}
        <div className="bg-card rounded-lg p-6 border border-border">
          <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
            Parliamentary Activities
          </h3>
          <div className="w-full h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="category" stroke="#6B7280" />
                <YAxis stroke="#6B7280" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#FFFFFF', 
                    border: '1px solid #E5E7EB',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="count" fill="#1E3A8A" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Fund Utilization */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <div className="bg-card rounded-lg p-6 border border-border">
            <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
              MPLADS Fund Utilization
            </h3>
            <div className="w-full h-48">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={fundUtilizationData}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={80}
                    dataKey="value"
                  >
                    {fundUtilizationData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center justify-center space-x-4 mt-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-success rounded-full"></div>
                <span className="text-sm text-muted-foreground">Utilized (75%)</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-muted rounded-full"></div>
                <span className="text-sm text-muted-foreground">Remaining (25%)</span>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-2">
          <div className="bg-card rounded-lg p-6 border border-border">
            <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
              Fund Allocation Breakdown
            </h3>
            <div className="space-y-4">
              {performanceData.fundBreakdown.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-muted rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Icon name={item.icon} size={20} className="text-primary" />
                    <div>
                      <h4 className="font-body font-medium text-foreground">
                        {item.category}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {item.projects} projects
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-body font-semibold text-foreground">
                      ₹{item.amount}Cr
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {item.percentage}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Key Achievements */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
          Key Achievements
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {performanceData.achievements.map((achievement, index) => (
            <div key={index} className="flex items-start space-x-4 p-4 bg-muted rounded-lg">
              <div className="flex-shrink-0 w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                <Icon name="Award" size={20} className="text-primary" />
              </div>
              <div>
                <h4 className="font-body font-semibold text-foreground">
                  {achievement.title}
                </h4>
                <p className="text-sm text-muted-foreground mt-1">
                  {achievement.description}
                </p>
                <span className="text-xs text-muted-foreground mt-2 block">
                  {achievement.date}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PerformanceTab;