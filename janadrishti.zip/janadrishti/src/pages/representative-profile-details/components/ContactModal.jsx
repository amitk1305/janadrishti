import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const ContactModal = ({ isOpen, onClose, representative }) => {
  const [contactMethod, setContactMethod] = useState("email");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [priority, setPriority] = useState("medium");

  const contactMethods = [
    { value: "email", label: "Email", icon: "Mail" },
    { value: "phone", label: "Phone Call", icon: "Phone" },
    { value: "office", label: "Office Visit", icon: "MapPin" },
    { value: "social", label: "Social Media", icon: "MessageCircle" }
  ];

  const priorityOptions = [
    { value: "low", label: "Low Priority" },
    { value: "medium", label: "Medium Priority" },
    { value: "high", label: "High Priority" },
    { value: "urgent", label: "Urgent" }
  ];

  const handleSubmit = () => {
    // Handle contact submission
    console.log("Contact submitted:", { contactMethod, subject, message, priority });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-modal flex items-center justify-center p-4">
      <div className="bg-card rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-heading font-semibold text-foreground">
              Contact {representative.name}
            </h2>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <Icon name="X" size={20} />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Contact Methods */}
          <div>
            <label className="block text-sm font-body font-medium text-foreground mb-3">
              Choose Contact Method
            </label>
            <div className="grid grid-cols-2 gap-3">
              {contactMethods.map((method) => (
                <button
                  key={method.value}
                  onClick={() => setContactMethod(method.value)}
                  className={`flex items-center space-x-3 p-4 rounded-lg border transition-civic ${
                    contactMethod === method.value
                      ? 'border-primary bg-primary/5 text-primary' :'border-border hover:border-muted-foreground'
                  }`}
                >
                  <Icon name={method.icon} size={20} />
                  <span className="font-body font-medium">{method.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Contact Information */}
          <div className="bg-muted rounded-lg p-4">
            <h3 className="font-body font-medium text-foreground mb-3">
              Contact Information
            </h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-sm">
                <Icon name="Mail" size={16} className="text-muted-foreground" />
                <span className="text-muted-foreground">{representative.email}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <Icon name="Phone" size={16} className="text-muted-foreground" />
                <span className="text-muted-foreground">{representative.phone}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <Icon name="MapPin" size={16} className="text-muted-foreground" />
                <span className="text-muted-foreground">{representative.officeAddress}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <Icon name="Clock" size={16} className="text-muted-foreground" />
                <span className="text-muted-foreground">Office Hours: Mon-Fri 10:00 AM - 5:00 PM</span>
              </div>
            </div>
          </div>

          {/* Message Form */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Subject"
                type="text"
                placeholder="Enter subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
              />
              <Select
                label="Priority"
                options={priorityOptions}
                value={priority}
                onChange={setPriority}
              />
            </div>

            <div>
              <label className="block text-sm font-body font-medium text-foreground mb-2">
                Message *
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Write your message here..."
                className="w-full p-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent font-body"
                rows={6}
                required
              />
            </div>
          </div>

          {/* Guidelines */}
          <div className="bg-accent/5 rounded-lg p-4">
            <h4 className="font-body font-medium text-foreground mb-2 flex items-center">
              <Icon name="Info" size={16} className="mr-2 text-accent" />
              Communication Guidelines
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Be respectful and professional in your communication</li>
              <li>• Provide specific details about your concern or request</li>
              <li>• Include your constituency information if relevant</li>
              <li>• Allow 3-5 business days for a response</li>
              <li>• For urgent matters, please call the office directly</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border">
          <div className="flex items-center justify-end space-x-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              variant="default"
              onClick={handleSubmit}
              disabled={!subject.trim() || !message.trim()}
              iconName="Send"
              iconPosition="left"
            >
              Send Message
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactModal;