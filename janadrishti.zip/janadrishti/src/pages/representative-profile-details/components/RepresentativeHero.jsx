import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const RepresentativeHero = ({ representative, onContact, onShare }) => {
  return (
    <div className="bg-gradient-to-r from-primary/5 to-accent/5 border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row items-start lg:items-center space-y-6 lg:space-y-0 lg:space-x-8">
          {/* Representative Photo */}
          <div className="flex-shrink-0">
            <div className="relative">
              <Image
                src={representative.photo}
                alt={`${representative.name} - ${representative.designation}`}
                className="w-32 h-32 lg:w-40 lg:h-40 rounded-full object-cover border-4 border-white shadow-civic-lg"
              />
              <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-accent rounded-full flex items-center justify-center border-2 border-white">
                <Icon name="CheckCircle" size={16} color="white" />
              </div>
            </div>
          </div>

          {/* Representative Info */}
          <div className="flex-1 min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between space-y-4 sm:space-y-0">
              <div className="flex-1">
                <h1 className="text-2xl lg:text-3xl font-heading font-bold text-foreground">
                  {representative.name}
                </h1>
                <p className="text-lg text-muted-foreground mt-1">
                  {representative.designation}
                </p>
                
                <div className="flex flex-wrap items-center gap-4 mt-4">
                  {/* Party Info */}
                  <div className="flex items-center space-x-2">
                    <Image
                      src={representative.party.logo}
                      alt={representative.party.name}
                      className="w-8 h-8 rounded object-contain"
                    />
                    <span className="font-body font-medium text-foreground">
                      {representative.party.name}
                    </span>
                  </div>

                  {/* Constituency */}
                  <div className="flex items-center space-x-2 text-muted-foreground">
                    <Icon name="MapPin" size={16} />
                    <span className="font-body">{representative.constituency}</span>
                  </div>

                  {/* Term */}
                  <div className="flex items-center space-x-2 text-muted-foreground">
                    <Icon name="Calendar" size={16} />
                    <span className="font-body">{representative.termPeriod}</span>
                  </div>
                </div>

                {/* Contact Info */}
                <div className="flex flex-wrap items-center gap-4 mt-4">
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Icon name="Phone" size={14} />
                    <span className="font-body">{representative.phone}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Icon name="Mail" size={14} />
                    <span className="font-body">{representative.email}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  variant="default"
                  onClick={onContact}
                  iconName="MessageSquare"
                  iconPosition="left"
                  className="min-w-[120px]"
                >
                  Contact
                </Button>
                <Button
                  variant="outline"
                  onClick={onShare}
                  iconName="Share2"
                  iconPosition="left"
                >
                  Share
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
          <div className="bg-card rounded-lg p-4 text-center border border-border">
            <div className="text-2xl font-heading font-bold text-primary">
              {representative.stats.attendance}%
            </div>
            <div className="text-sm text-muted-foreground mt-1">Attendance</div>
          </div>
          <div className="bg-card rounded-lg p-4 text-center border border-border">
            <div className="text-2xl font-heading font-bold text-accent">
              {representative.stats.billsIntroduced}
            </div>
            <div className="text-sm text-muted-foreground mt-1">Bills Introduced</div>
          </div>
          <div className="bg-card rounded-lg p-4 text-center border border-border">
            <div className="text-2xl font-heading font-bold text-warning">
              {representative.stats.questionsRaised}
            </div>
            <div className="text-sm text-muted-foreground mt-1">Questions Raised</div>
          </div>
          <div className="bg-card rounded-lg p-4 text-center border border-border">
            <div className="text-2xl font-heading font-bold text-success">
              ₹{representative.stats.fundsUtilized}Cr
            </div>
            <div className="text-sm text-muted-foreground mt-1">Funds Utilized</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RepresentativeHero;