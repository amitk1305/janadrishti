import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const VotingRecordTab = ({ votingRecord }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterVote, setFilterVote] = useState("all");

  const categoryOptions = [
    { value: "all", label: "All Categories" },
    { value: "economic", label: "Economic Policy" },
    { value: "social", label: "Social Issues" },
    { value: "infrastructure", label: "Infrastructure" },
    { value: "healthcare", label: "Healthcare" },
    { value: "education", label: "Education" },
    { value: "environment", label: "Environment" }
  ];

  const voteOptions = [
    { value: "all", label: "All Votes" },
    { value: "for", label: "Voted For" },
    { value: "against", label: "Voted Against" },
    { value: "abstain", label: "Abstained" },
    { value: "absent", label: "Absent" }
  ];

  const filteredRecords = votingRecord.filter(record => {
    const matchesSearch = record.billTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === "all" || record.category === filterCategory;
    const matchesVote = filterVote === "all" || record.vote === filterVote;
    
    return matchesSearch && matchesCategory && matchesVote;
  });

  const getVoteIcon = (vote) => {
    switch (vote) {
      case 'for':
        return 'ThumbsUp';
      case 'against':
        return 'ThumbsDown';
      case 'abstain':
        return 'Minus';
      case 'absent':
        return 'X';
      default:
        return 'HelpCircle';
    }
  };

  const getVoteColor = (vote) => {
    switch (vote) {
      case 'for':
        return 'text-success';
      case 'against':
        return 'text-destructive';
      case 'abstain':
        return 'text-warning';
      case 'absent':
        return 'text-muted-foreground';
      default:
        return 'text-muted-foreground';
    }
  };

  const getVoteBadge = (vote) => {
    switch (vote) {
      case 'for':
        return 'bg-success/10 text-success';
      case 'against':
        return 'bg-destructive/10 text-destructive';
      case 'abstain':
        return 'bg-warning/10 text-warning';
      case 'absent':
        return 'bg-muted text-muted-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Input
            type="search"
            placeholder="Search bills..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full"
          />
          <Select
            options={categoryOptions}
            value={filterCategory}
            onChange={setFilterCategory}
            placeholder="Filter by category"
          />
          <Select
            options={voteOptions}
            value={filterVote}
            onChange={setFilterVote}
            placeholder="Filter by vote"
          />
        </div>
      </div>

      {/* Voting Statistics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-card rounded-lg p-4 text-center border border-border">
          <div className="text-2xl font-heading font-bold text-success">
            {votingRecord.filter(r => r.vote === 'for').length}
          </div>
          <div className="text-sm text-muted-foreground mt-1">Voted For</div>
        </div>
        <div className="bg-card rounded-lg p-4 text-center border border-border">
          <div className="text-2xl font-heading font-bold text-destructive">
            {votingRecord.filter(r => r.vote === 'against').length}
          </div>
          <div className="text-sm text-muted-foreground mt-1">Voted Against</div>
        </div>
        <div className="bg-card rounded-lg p-4 text-center border border-border">
          <div className="text-2xl font-heading font-bold text-warning">
            {votingRecord.filter(r => r.vote === 'abstain').length}
          </div>
          <div className="text-sm text-muted-foreground mt-1">Abstained</div>
        </div>
        <div className="bg-card rounded-lg p-4 text-center border border-border">
          <div className="text-2xl font-heading font-bold text-muted-foreground">
            {votingRecord.filter(r => r.vote === 'absent').length}
          </div>
          <div className="text-sm text-muted-foreground mt-1">Absent</div>
        </div>
      </div>

      {/* Voting Records */}
      <div className="bg-card rounded-lg border border-border">
        <div className="p-6 border-b border-border">
          <h3 className="text-lg font-heading font-semibold text-foreground">
            Voting Records ({filteredRecords.length} bills)
          </h3>
        </div>
        
        <div className="divide-y divide-border">
          {filteredRecords.map((record, index) => (
            <div key={index} className="p-6 hover:bg-muted/50 transition-civic">
              <div className="flex items-start justify-between space-x-4">
                <div className="flex-1">
                  <div className="flex items-start space-x-3">
                    <Icon 
                      name={getVoteIcon(record.vote)} 
                      size={20} 
                      className={getVoteColor(record.vote)}
                    />
                    <div className="flex-1">
                      <h4 className="font-body font-semibold text-foreground">
                        {record.billTitle}
                      </h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        {record.description}
                      </p>
                      
                      <div className="flex flex-wrap items-center gap-3 mt-3">
                        <span className={`text-xs px-2 py-1 rounded-full ${getVoteBadge(record.vote)}`}>
                          {record.vote.charAt(0).toUpperCase() + record.vote.slice(1)}
                        </span>
                        <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                          {record.category}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {record.date}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          Bill No: {record.billNumber}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-muted-foreground">
                    {record.result}
                  </span>
                  <Icon name="ExternalLink" size={16} className="text-muted-foreground" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredRecords.length === 0 && (
          <div className="p-12 text-center">
            <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground font-body">
              No voting records found matching your criteria
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default VotingRecordTab;