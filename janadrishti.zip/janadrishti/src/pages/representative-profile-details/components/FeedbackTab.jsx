import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

import Select from '../../../components/ui/Select';

const FeedbackTab = ({ feedback, onSubmitFeedback }) => {
  const [newFeedback, setNewFeedback] = useState({
    rating: 5,
    comment: "",
    category: "overall",
    anonymous: false
  });
  const [filterRating, setFilterRating] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");

  const ratingOptions = [
    { value: "all", label: "All Ratings" },
    { value: "5", label: "5 Stars" },
    { value: "4", label: "4 Stars" },
    { value: "3", label: "3 Stars" },
    { value: "2", label: "2 Stars" },
    { value: "1", label: "1 Star" }
  ];

  const categoryOptions = [
    { value: "all", label: "All Categories" },
    { value: "overall", label: "Overall Performance" },
    { value: "responsiveness", label: "Responsiveness" },
    { value: "transparency", label: "Transparency" },
    { value: "accessibility", label: "Accessibility" },
    { value: "constituency", label: "Constituency Work" }
  ];

  const feedbackCategories = [
    { value: "overall", label: "Overall Performance" },
    { value: "responsiveness", label: "Responsiveness" },
    { value: "transparency", label: "Transparency" },
    { value: "accessibility", label: "Accessibility" },
    { value: "constituency", label: "Constituency Work" }
  ];

  const filteredFeedback = feedback.filter(item => {
    const matchesRating = filterRating === "all" || item.rating.toString() === filterRating;
    const matchesCategory = filterCategory === "all" || item.category === filterCategory;
    return matchesRating && matchesCategory;
  });

  const averageRating = feedback.reduce((sum, item) => sum + item.rating, 0) / feedback.length;
  const ratingDistribution = [5, 4, 3, 2, 1].map(rating => ({
    rating,
    count: feedback.filter(item => item.rating === rating).length,
    percentage: (feedback.filter(item => item.rating === rating).length / feedback.length) * 100
  }));

  const handleSubmitFeedback = () => {
    if (newFeedback.comment.trim()) {
      onSubmitFeedback({
        ...newFeedback,
        id: Date.now(),
        date: new Date().toLocaleDateString(),
        author: newFeedback.anonymous ? "Anonymous" : "Current User"
      });
      setNewFeedback({
        rating: 5,
        comment: "",
        category: "overall",
        anonymous: false
      });
    }
  };

  const renderStars = (rating, size = 16, interactive = false, onRatingChange = null) => {
    return (
      <div className="flex items-center space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onClick={() => interactive && onRatingChange && onRatingChange(star)}
            className={`${interactive ? 'cursor-pointer hover:scale-110' : 'cursor-default'} transition-transform`}
            disabled={!interactive}
          >
            <Icon
              name="Star"
              size={size}
              className={star <= rating ? 'text-warning fill-current' : 'text-muted-foreground'}
            />
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-8">
      {/* Rating Overview */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Average Rating */}
          <div className="text-center">
            <div className="text-4xl font-heading font-bold text-foreground mb-2">
              {averageRating.toFixed(1)}
            </div>
            {renderStars(Math.round(averageRating), 24)}
            <p className="text-sm text-muted-foreground mt-2">
              Based on {feedback.length} reviews
            </p>
          </div>

          {/* Rating Distribution */}
          <div className="lg:col-span-2">
            <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
              Rating Distribution
            </h3>
            <div className="space-y-2">
              {ratingDistribution.map((item) => (
                <div key={item.rating} className="flex items-center space-x-3">
                  <span className="text-sm text-muted-foreground w-8">
                    {item.rating}★
                  </span>
                  <div className="flex-1 bg-muted rounded-full h-2">
                    <div
                      className="bg-warning rounded-full h-2 transition-all duration-300"
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                  <span className="text-sm text-muted-foreground w-12">
                    {item.count}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Submit Feedback */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <h3 className="text-lg font-heading font-semibold text-foreground mb-4">
          Share Your Feedback
        </h3>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-body font-medium text-foreground mb-2">
                Rating
              </label>
              {renderStars(newFeedback.rating, 20, true, (rating) => 
                setNewFeedback(prev => ({ ...prev, rating }))
              )}
            </div>
            <Select
              label="Category"
              options={feedbackCategories}
              value={newFeedback.category}
              onChange={(value) => setNewFeedback(prev => ({ ...prev, category: value }))}
            />
          </div>
          
          <div>
            <label className="block text-sm font-body font-medium text-foreground mb-2">
              Your Feedback
            </label>
            <textarea
              value={newFeedback.comment}
              onChange={(e) => setNewFeedback(prev => ({ ...prev, comment: e.target.value }))}
              placeholder="Share your thoughts about the representative's performance..."
              className="w-full p-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent font-body"
              rows={4}
            />
          </div>

          <div className="flex items-center justify-between">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={newFeedback.anonymous}
                onChange={(e) => setNewFeedback(prev => ({ ...prev, anonymous: e.target.checked }))}
                className="rounded border-border"
              />
              <span className="text-sm text-muted-foreground">Submit anonymously</span>
            </label>
            
            <Button
              variant="default"
              onClick={handleSubmitFeedback}
              disabled={!newFeedback.comment.trim()}
              iconName="Send"
              iconPosition="left"
            >
              Submit Feedback
            </Button>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-card rounded-lg p-6 border border-border">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Select
            label="Filter by Rating"
            options={ratingOptions}
            value={filterRating}
            onChange={setFilterRating}
          />
          <Select
            label="Filter by Category"
            options={categoryOptions}
            value={filterCategory}
            onChange={setFilterCategory}
          />
        </div>
      </div>

      {/* Feedback List */}
      <div className="space-y-4">
        {filteredFeedback.map((item, index) => (
          <div key={index} className="bg-card rounded-lg p-6 border border-border">
            <div className="flex items-start justify-between space-x-4">
              <div className="flex-1">
                <div className="flex items-center space-x-4 mb-3">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                    <Icon name="User" size={16} color="white" />
                  </div>
                  <div>
                    <h4 className="font-body font-medium text-foreground">
                      {item.author}
                    </h4>
                    <div className="flex items-center space-x-2 mt-1">
                      {renderStars(item.rating, 14)}
                      <span className="text-xs text-muted-foreground">
                        {item.date}
                      </span>
                    </div>
                  </div>
                </div>
                
                <p className="text-muted-foreground font-body leading-relaxed">
                  {item.comment}
                </p>
                
                <div className="flex items-center space-x-4 mt-4">
                  <span className="text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                    {item.category}
                  </span>
                  <button className="flex items-center space-x-1 text-xs text-muted-foreground hover:text-foreground transition-civic">
                    <Icon name="ThumbsUp" size={12} />
                    <span>{item.helpful || 0}</span>
                  </button>
                  <button className="flex items-center space-x-1 text-xs text-muted-foreground hover:text-foreground transition-civic">
                    <Icon name="MessageSquare" size={12} />
                    <span>Reply</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredFeedback.length === 0 && (
        <div className="bg-card rounded-lg p-12 text-center border border-border">
          <Icon name="MessageSquare" size={48} className="text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground font-body">
            No feedback found matching your criteria
          </p>
        </div>
      )}
    </div>
  );
};

export default FeedbackTab;