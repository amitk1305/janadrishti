import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Navigation from '../../components/ui/Navigation';
import Breadcrumb from '../../components/ui/Breadcrumb';
import RepresentativeHero from './components/RepresentativeHero';
import TabNavigation from './components/TabNavigation';
import OverviewTab from './components/OverviewTab';
import VotingRecordTab from './components/VotingRecordTab';
import PerformanceTab from './components/PerformanceTab';
import IssuesTab from './components/IssuesTab';
import FeedbackTab from './components/FeedbackTab';
import ContactModal from './components/ContactModal';
import ShareModal from './components/ShareModal';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const RepresentativeProfileDetails = () => {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState("overview");
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Mock representative data
  const representative = {
    id: "rep-001",
    name: "Dr. Rajesh Kumar Sharma",
    designation: "Member of Parliament (Lok Sabha)",
    constituency: "Mumbai North-West",
    party: {
      name: "Bharatiya Janata Party",
      logo: "https://images.pexels.com/photos/8849295/pexels-photo-8849295.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop"
    },
    photo: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
    termPeriod: "2019-2024",
    phone: "+91-11-23034567",
    email: "rajesh.sharma@sansad.nic.in",
    officeAddress: "Room No. 45, Parliament House, New Delhi - 110001",
    stats: {
      attendance: 89,
      billsIntroduced: 12,
      questionsRaised: 45,
      fundsUtilized: 75
    },
    biography: `Dr. Rajesh Kumar Sharma is a seasoned politician and public servant with over 15 years of experience in governance and public policy. Born and raised in Mumbai, he has dedicated his career to improving the lives of citizens through effective legislation and constituency development.\n\nHe holds a Ph.D. in Public Administration from Jawaharlal Nehru University and has been instrumental in several key policy initiatives related to urban development, healthcare, and education. His commitment to transparency and accountability has earned him recognition as one of the most effective parliamentarians in the current Lok Sabha.`,
    committees: [
      {
        name: "Standing Committee on Urban Development",
        role: "Chairperson",
        since: "2020"
      },
      {
        name: "Committee on Public Accounts",
        role: "Member",
        since: "2019"
      },
      {
        name: "Joint Committee on Offices of Profit",
        role: "Member",
        since: "2021"
      }
    ],
    recentActivities: [
      {
        title: "Introduced Private Member\'s Bill on Digital Privacy",
        description: "Proposed comprehensive legislation to protect citizen data privacy in the digital age",
        date: "2 days ago",
        type: "bill",
        icon: "FileText"
      },
      {
        title: "Raised Question on Mumbai Metro Expansion",
        description: "Questioned the Minister about delays in Phase 3 of Mumbai Metro project",
        date: "1 week ago",
        type: "question",
        icon: "HelpCircle"
      },
      {
        title: "Participated in Budget Discussion",
        description: "Spoke on infrastructure allocation for urban constituencies",
        date: "2 weeks ago",
        type: "debate",
        icon: "MessageSquare"
      },
      {
        title: "Committee Meeting on Smart Cities",
        description: "Chaired meeting to review progress of Smart Cities Mission",
        date: "3 weeks ago",
        type: "committee",
        icon: "Users"
      }
    ],
    education: [
      {
        degree: "Ph.D. in Public Administration",
        institution: "Jawaharlal Nehru University",
        year: "2005"
      },
      {
        degree: "Master of Public Policy",
        institution: "Tata Institute of Social Sciences",
        year: "2001"
      },
      {
        degree: "Bachelor of Arts (Political Science)",
        institution: "University of Mumbai",
        year: "1999"
      }
    ],
    professionalBackground: [
      {
        position: "Senior Policy Advisor",
        organization: "Ministry of Urban Development",
        duration: "2015-2019"
      },
      {
        position: "Research Fellow",
        organization: "Observer Research Foundation",
        duration: "2010-2015"
      },
      {
        position: "Assistant Professor",
        organization: "Delhi School of Economics",
        duration: "2005-2010"
      }
    ]
  };

  // Mock voting record data
  const votingRecord = [
    {
      billTitle: "The Personal Data Protection Bill, 2023",
      billNumber: "LS-156/2023",
      description: "A comprehensive bill to protect personal data of individuals and establish a Data Protection Authority",
      category: "social",
      vote: "for",
      date: "15/12/2023",
      result: "Passed"
    },
    {
      billTitle: "The Urban Development (Amendment) Bill, 2023",
      billNumber: "LS-142/2023",
      description: "Amendment to streamline urban planning processes and enhance citizen participation",
      category: "infrastructure",
      vote: "for",
      date: "28/11/2023",
      result: "Passed"
    },
    {
      billTitle: "The Healthcare Infrastructure Bill, 2023",
      billNumber: "LS-138/2023",
      description: "Bill to improve healthcare infrastructure in tier-2 and tier-3 cities",
      category: "healthcare",
      vote: "for",
      date: "20/11/2023",
      result: "Passed"
    },
    {
      billTitle: "The Environmental Protection (Amendment) Bill, 2023",
      billNumber: "LS-134/2023",
      description: "Amendments to strengthen environmental protection measures",
      category: "environment",
      vote: "abstain",
      date: "10/11/2023",
      result: "Passed"
    },
    {
      billTitle: "The Education Reform Bill, 2023",
      billNumber: "LS-129/2023",
      description: "Comprehensive reforms in the education sector including digital learning",
      category: "education",
      vote: "for",
      date: "02/11/2023",
      result: "Passed"
    },
    {
      billTitle: "The Economic Policy Bill, 2023",
      billNumber: "LS-125/2023",
      description: "New economic policies to boost manufacturing and exports",
      category: "economic",
      vote: "against",
      date: "25/10/2023",
      result: "Failed"
    }
  ];

  // Mock performance data
  const performanceData = {
    fundBreakdown: [
      {
        category: "Infrastructure Development",
        amount: "45",
        percentage: 60,
        projects: 12,
        icon: "Building"
      },
      {
        category: "Healthcare Facilities",
        amount: "15",
        percentage: 20,
        projects: 8,
        icon: "Heart"
      },
      {
        category: "Education Infrastructure",
        amount: "10",
        percentage: 13,
        projects: 5,
        icon: "GraduationCap"
      },
      {
        category: "Environmental Projects",
        amount: "5",
        percentage: 7,
        projects: 3,
        icon: "Leaf"
      }
    ],
    achievements: [
      {
        title: "Best Parliamentarian Award 2023",
        description: "Recognized for outstanding contribution to legislative processes and constituency development",
        date: "March 2023"
      },
      {
        title: "Digital Governance Initiative",
        description: "Successfully implemented e-governance solutions in 15 government offices",
        date: "January 2023"
      },
      {
        title: "Healthcare Access Program",
        description: "Established 5 new primary health centers in underserved areas",
        date: "November 2022"
      },
      {
        title: "Education Infrastructure Development",
        description: "Upgraded 25 government schools with modern facilities and technology",
        date: "September 2022"
      }
    ]
  };

  // Mock issues data
  const issues = [
    {
      title: "Pothole on SV Road causing traffic congestion",
      description: "Large pothole near Andheri station is causing severe traffic jams during peak hours. Multiple vehicles have been damaged.",
      category: "infrastructure",
      status: "in-progress",
      location: "SV Road, Andheri West",
      reportedBy: "Priya Sharma",
      reportedDate: "2 days ago",
      upvotes: 45,
      comments: 12,
      image: "https://images.pexels.com/photos/2108845/pexels-photo-2108845.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop",
      updates: [
        {
          message: "Municipal corporation has been notified and inspection scheduled",
          date: "1 day ago"
        },
        {
          message: "Repair work to begin next week pending material availability",
          date: "6 hours ago"
        }
      ]
    },
    {
      title: "Water supply shortage in Lokhandwala Complex",
      description: "Residents facing acute water shortage for the past week. No communication from water department.",
      category: "water",
      status: "pending",
      location: "Lokhandwala Complex, Andheri West",
      reportedBy: "Residents Association",
      reportedDate: "5 days ago",
      upvotes: 78,
      comments: 23,
      image: "https://images.pexels.com/photos/416528/pexels-photo-416528.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop",
      updates: []
    },
    {
      title: "Broken streetlights on Linking Road",
      description: "Multiple streetlights are not working, creating safety concerns for pedestrians and commuters.",
      category: "infrastructure",
      status: "resolved",
      location: "Linking Road, Bandra West",
      reportedBy: "Amit Patel",
      reportedDate: "2 weeks ago",
      upvotes: 32,
      comments: 8,
      image: "https://images.pexels.com/photos/1108572/pexels-photo-1108572.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop",
      updates: [
        {
          message: "All streetlights have been repaired and are now functional",
          date: "3 days ago"
        }
      ]
    },
    {
      title: "Garbage collection irregular in Juhu area",
      description: "Garbage collection has been irregular for the past month, causing hygiene issues.",
      category: "environment",
      status: "in-progress",
      location: "Juhu Tara Road",
      reportedBy: "Neha Gupta",
      reportedDate: "1 week ago",
      upvotes: 56,
      comments: 15,
      image: "https://images.pexels.com/photos/2827392/pexels-photo-2827392.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop",
      updates: [
        {
          message: "New collection schedule implemented with additional vehicles",
          date: "2 days ago"
        }
      ]
    }
  ];

  // Mock feedback data
  const [feedback, setFeedback] = useState([
    {
      id: 1,
      author: "Sunita Mehta",
      rating: 5,
      comment: "Dr. Sharma has been very responsive to our constituency issues. His office staff is helpful and he personally follows up on important matters.",
      category: "responsiveness",
      date: "2 days ago",
      helpful: 12
    },
    {
      id: 2,
      author: "Anonymous",
      rating: 4,
      comment: "Good work on infrastructure development. Would like to see more focus on healthcare facilities in our area.",
      category: "overall",
      date: "1 week ago",
      helpful: 8
    },
    {
      id: 3,
      author: "Rajesh Patel",
      rating: 5,
      comment: "Excellent transparency in fund utilization. Regular updates on development projects are very helpful.",
      category: "transparency",
      date: "2 weeks ago",
      helpful: 15
    },
    {
      id: 4,
      author: "Kavita Singh",
      rating: 3,
      comment: "While the representative is doing good work, accessibility could be improved. It's difficult to get appointments.",
      category: "accessibility",
      date: "3 weeks ago",
      helpful: 6
    },
    {
      id: 5,
      author: "Anonymous",
      rating: 4,
      comment: "Satisfied with the constituency development work. The new health centers have been very beneficial.",
      category: "constituency",
      date: "1 month ago",
      helpful: 10
    }
  ]);

  const tabs = [
    { id: "overview", label: "Overview", icon: "User" },
    { id: "voting", label: "Voting Record", icon: "Vote" },
    { id: "performance", label: "Performance", icon: "BarChart3" },
    { id: "issues", label: "Issues", icon: "AlertTriangle", badge: issues.filter(i => i.status === 'pending').length },
    { id: "feedback", label: "Feedback", icon: "MessageSquare" }
  ];

  const handleSubmitFeedback = (newFeedbackData) => {
    setFeedback(prev => [newFeedbackData, ...prev]);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const renderTabContent = () => {
    switch (activeTab) {
      case "overview":
        return <OverviewTab representative={representative} />;
      case "voting":
        return <VotingRecordTab votingRecord={votingRecord} />;
      case "performance":
        return <PerformanceTab performanceData={performanceData} />;
      case "issues":
        return <IssuesTab issues={issues} />;
      case "feedback":
        return <FeedbackTab feedback={feedback} onSubmitFeedback={handleSubmitFeedback} />;
      default:
        return <OverviewTab representative={representative} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Navigation />
      
      {/* Main Content */}
      <main className="pt-30 lg:pt-30 pb-20 lg:pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumb />
          
          {/* Representative Hero Section */}
          <RepresentativeHero
            representative={representative}
            onContact={() => setIsContactModalOpen(true)}
            onShare={() => setIsShareModalOpen(true)}
          />

          {/* Tab Navigation */}
          <TabNavigation
            activeTab={activeTab}
            onTabChange={setActiveTab}
            tabs={tabs}
          />

          {/* Tab Content */}
          <div className="py-8">
            {renderTabContent()}
          </div>
        </div>
      </main>

      {/* Floating Action Button */}
      <div className="fixed bottom-20 lg:bottom-8 right-4 z-10">
        <div className="flex flex-col space-y-3">
          {showScrollTop && (
            <Button
              variant="outline"
              size="icon"
              onClick={scrollToTop}
              className="w-12 h-12 rounded-full shadow-civic-lg bg-card"
            >
              <Icon name="ArrowUp" size={20} />
            </Button>
          )}
          <Button
            variant="default"
            onClick={() => setIsContactModalOpen(true)}
            className="rounded-full shadow-civic-lg px-6"
            iconName="MessageSquare"
            iconPosition="left"
          >
            Contact
          </Button>
        </div>
      </div>

      {/* Modals */}
      <ContactModal
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
        representative={representative}
      />

      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        representative={representative}
      />
    </div>
  );
};

export default RepresentativeProfileDetails;