import React from 'react';
import Icon from '../../../components/AppIcon';

const EngagementStats = () => {
  const userStats = {
    issuesReported: 12,
    issuesResolved: 8,
    discussionsJoined: 23,
    representativesFollowed: 5,
    communityRating: 4.6,
    badgesEarned: 3
  };

  const badges = [
    {
      name: "Active Reporter",
      description: "Reported 10+ civic issues",
      icon: "Award",
      color: "text-warning",
      bgColor: "bg-warning/10"
    },
    {
      name: "Community Helper",
      description: "Helped resolve 5+ issues",
      icon: "Heart",
      color: "text-destructive",
      bgColor: "bg-destructive/10"
    },
    {
      name: "Discussion Leader",
      description: "Started 3+ policy discussions",
      icon: "MessageSquare",
      color: "text-accent",
      bgColor: "bg-accent/10"
    }
  ];

  const recentAchievements = [
    {
      title: "Issue Resolution",
      description: "Your pothole report was resolved",
      time: "2 days ago",
      icon: "CheckCircle",
      color: "text-success"
    },
    {
      title: "Community Impact",
      description: "Your discussion got 50+ responses",
      time: "1 week ago",
      icon: "TrendingUp",
      color: "text-primary"
    }
  ];

  return (
    <div className="space-y-6">
      {/* User Stats */}
      <div className="bg-card border border-border rounded-lg p-6 shadow-civic">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold text-lg text-foreground">
            Your Civic Impact
          </h3>
          <Icon name="BarChart3" size={20} className="text-primary" />
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="text-center">
            <div className="font-heading font-bold text-2xl text-foreground">{userStats.issuesReported}</div>
            <div className="text-xs text-muted-foreground">Issues Reported</div>
          </div>
          <div className="text-center">
            <div className="font-heading font-bold text-2xl text-success">{userStats.issuesResolved}</div>
            <div className="text-xs text-muted-foreground">Issues Resolved</div>
          </div>
          <div className="text-center">
            <div className="font-heading font-bold text-2xl text-accent">{userStats.discussionsJoined}</div>
            <div className="text-xs text-muted-foreground">Discussions</div>
          </div>
          <div className="text-center">
            <div className="font-heading font-bold text-2xl text-primary">{userStats.representativesFollowed}</div>
            <div className="text-xs text-muted-foreground">Following</div>
          </div>
        </div>

        {/* Community Rating */}
        <div className="border-t border-border pt-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Community Rating</span>
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Icon
                    key={i}
                    name="Star"
                    size={14}
                    className={i < Math.floor(userStats.communityRating) ? "text-warning fill-current" : "text-muted-foreground"}
                  />
                ))}
              </div>
              <span className="text-sm font-medium text-foreground">{userStats.communityRating}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Badges */}
      <div className="bg-card border border-border rounded-lg p-6 shadow-civic">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold text-lg text-foreground">
            Earned Badges
          </h3>
          <span className="text-sm text-muted-foreground">{userStats.badgesEarned} of 10</span>
        </div>

        <div className="space-y-3">
          {badges.map((badge) => (
            <div key={badge.name} className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
              <div className={`w-10 h-10 rounded-full ${badge.bgColor} flex items-center justify-center`}>
                <Icon name={badge.icon} size={20} className={badge.color} />
              </div>
              <div className="flex-1">
                <h4 className="font-body font-medium text-foreground text-sm">{badge.name}</h4>
                <p className="text-xs text-muted-foreground">{badge.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Achievements */}
      <div className="bg-card border border-border rounded-lg p-6 shadow-civic">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold text-lg text-foreground">
            Recent Achievements
          </h3>
          <Icon name="Trophy" size={20} className="text-warning" />
        </div>

        <div className="space-y-3">
          {recentAchievements.map((achievement, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 hover:bg-muted/50 rounded-lg transition-civic">
              <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                <Icon name={achievement.icon} size={16} className={achievement.color} />
              </div>
              <div className="flex-1">
                <h4 className="font-body font-medium text-foreground text-sm">{achievement.title}</h4>
                <p className="text-xs text-muted-foreground">{achievement.description}</p>
                <span className="text-xs text-muted-foreground">{achievement.time}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EngagementStats;