import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActions = () => {
  const quickActions = [
    {
      title: 'Report Issue',
      description: 'Report civic issues in your area',
      icon: 'AlertTriangle',
      color: 'text-warning',
      bgColor: 'bg-warning/10',
      borderColor: 'border-warning/20',
      route: '/civic-issue-reporting',
      badge: null
    },
    {
      title: 'Find Representatives',
      description: 'Connect with your elected officials',
      icon: 'Users',
      color: 'text-primary',
      bgColor: 'bg-primary/10',
      borderColor: 'border-primary/20',
      route: '/political-representatives-directory',
      badge: null
    },
    {
      title: 'Join Discussions',
      description: 'Participate in policy discussions',
      icon: 'MessageSquare',
      color: 'text-accent',
      bgColor: 'bg-accent/10',
      borderColor: 'border-accent/20',
      route: '/civic-dashboard',
      badge: '3 New'
    },
    {
      title: 'Track Issues',
      description: 'Monitor your reported issues',
      icon: 'Eye',
      color: 'text-success',
      bgColor: 'bg-success/10',
      borderColor: 'border-success/20',
      route: '/civic-dashboard',
      badge: null
    }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-civic">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-heading font-semibold text-lg text-foreground">
          Quick Actions
        </h3>
        <Icon name="Zap" size={20} className="text-primary" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {quickActions.map((action) => (
          <Link
            key={action.title}
            to={action.route}
            className={`relative group p-4 rounded-lg border-2 ${action.borderColor} ${action.bgColor} hover:shadow-civic transition-all duration-300 hover:scale-105`}
          >
            <div className="flex items-start space-x-3">
              <div className={`w-10 h-10 rounded-lg ${action.bgColor} border ${action.borderColor} flex items-center justify-center`}>
                <Icon name={action.icon} size={20} className={action.color} />
              </div>
              <div className="flex-1">
                <h4 className="font-body font-semibold text-foreground group-hover:text-primary transition-civic">
                  {action.title}
                </h4>
                <p className="text-sm text-muted-foreground mt-1">
                  {action.description}
                </p>
              </div>
            </div>
            
            {action.badge && (
              <span className="absolute top-2 right-2 bg-destructive text-destructive-foreground text-xs px-2 py-1 rounded-full font-caption">
                {action.badge}
              </span>
            )}

            <div className="flex items-center justify-end mt-3">
              <Icon 
                name="ArrowRight" 
                size={16} 
                className="text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" 
              />
            </div>
          </Link>
        ))}
      </div>

      {/* Emergency Contact */}
      <div className="mt-6 p-4 bg-destructive/5 border border-destructive/20 rounded-lg">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-full bg-destructive/10 flex items-center justify-center">
            <Icon name="Phone" size={16} className="text-destructive" />
          </div>
          <div className="flex-1">
            <h4 className="font-body font-semibold text-foreground">Emergency Services</h4>
            <p className="text-sm text-muted-foreground">For urgent civic emergencies</p>
          </div>
          <Button variant="destructive" size="sm">
            Call 100
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QuickActions;