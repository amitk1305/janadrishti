import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const TrendingTopics = () => {
  const trendingTopics = [
    {
      id: 1,
      title: "Mumbai Metro Line 3 Updates",
      category: "Infrastructure",
      discussions: 156,
      trend: "up",
      trendValue: "+23%",
      icon: "Train",
      color: "text-primary"
    },
    {
      id: 2,
      title: "Waste Management Policy 2024",
      category: "Environment",
      discussions: 89,
      trend: "up",
      trendValue: "+45%",
      icon: "Recycle",
      color: "text-success"
    },
    {
      id: 3,
      title: "Street Lighting Improvements",
      category: "Safety",
      discussions: 67,
      trend: "up",
      trendValue: "+12%",
      icon: "Lightbulb",
      color: "text-warning"
    },
    {
      id: 4,
      title: "Healthcare Center Expansion",
      category: "Healthcare",
      discussions: 134,
      trend: "up",
      trendValue: "+8%",
      icon: "Heart",
      color: "text-destructive"
    },
    {
      id: 5,
      title: "Digital Governance Initiative",
      category: "Technology",
      discussions: 78,
      trend: "up",
      trendValue: "+34%",
      icon: "Smartphone",
      color: "text-accent"
    }
  ];

  const upcomingEvents = [
    {
      id: 1,
      title: "Town Hall Meeting",
      date: "Dec 16, 2023",
      time: "10:00 AM",
      location: "Community Center, Andheri West",
      attendees: 45,
      type: "meeting"
    },
    {
      id: 2,
      title: "Budget Discussion Forum",
      date: "Dec 20, 2023",
      time: "2:00 PM",
      location: "Municipal Office, Bandra",
      attendees: 23,
      type: "discussion"
    },
    {
      id: 3,
      title: "Clean-up Drive",
      date: "Dec 23, 2023",
      time: "7:00 AM",
      location: "Juhu Beach",
      attendees: 89,
      type: "activity"
    }
  ];

  const getEventIcon = (type) => {
    switch (type) {
      case 'meeting':
        return 'Users';
      case 'discussion':
        return 'MessageSquare';
      case 'activity':
        return 'Activity';
      default:
        return 'Calendar';
    }
  };

  return (
    <div className="space-y-6">
      {/* Trending Topics */}
      <div className="bg-card border border-border rounded-lg p-6 shadow-civic">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold text-lg text-foreground">
            Trending Topics
          </h3>
          <Icon name="TrendingUp" size={20} className="text-success" />
        </div>

        <div className="space-y-3">
          {trendingTopics.map((topic, index) => (
            <div key={topic.id} className="flex items-center space-x-3 p-3 hover:bg-muted/50 rounded-lg transition-civic cursor-pointer">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-muted">
                <span className="text-xs font-bold text-muted-foreground">#{index + 1}</span>
              </div>
              
              <div className={`w-8 h-8 rounded-full bg-muted flex items-center justify-center`}>
                <Icon name={topic.icon} size={16} className={topic.color} />
              </div>

              <div className="flex-1 min-w-0">
                <h4 className="font-body font-medium text-foreground text-sm line-clamp-1">
                  {topic.title}
                </h4>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-xs text-muted-foreground">{topic.category}</span>
                  <span className="text-xs text-muted-foreground">•</span>
                  <span className="text-xs text-muted-foreground">{topic.discussions} discussions</span>
                </div>
              </div>

              <div className="flex items-center space-x-1">
                <Icon name="TrendingUp" size={12} className="text-success" />
                <span className="text-xs text-success font-medium">{topic.trendValue}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t border-border">
          <Button variant="ghost" size="sm" className="w-full">
            View All Topics
          </Button>
        </div>
      </div>

      {/* Upcoming Events */}
      <div className="bg-card border border-border rounded-lg p-6 shadow-civic">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold text-lg text-foreground">
            Upcoming Events
          </h3>
          <Icon name="Calendar" size={20} className="text-primary" />
        </div>

        <div className="space-y-4">
          {upcomingEvents.map((event) => (
            <div key={event.id} className="flex items-start space-x-3 p-3 bg-muted/30 rounded-lg">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Icon name={getEventIcon(event.type)} size={16} className="text-primary" />
              </div>
              
              <div className="flex-1 min-w-0">
                <h4 className="font-body font-medium text-foreground text-sm">
                  {event.title}
                </h4>
                <div className="flex items-center space-x-2 mt-1 text-xs text-muted-foreground">
                  <Icon name="Calendar" size={12} />
                  <span>{event.date}</span>
                  <span>•</span>
                  <Icon name="Clock" size={12} />
                  <span>{event.time}</span>
                </div>
                <div className="flex items-center space-x-1 mt-1 text-xs text-muted-foreground">
                  <Icon name="MapPin" size={12} />
                  <span className="line-clamp-1">{event.location}</span>
                </div>
                <div className="flex items-center space-x-1 mt-2 text-xs text-muted-foreground">
                  <Icon name="Users" size={12} />
                  <span>{event.attendees} attending</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t border-border">
          <Button variant="ghost" size="sm" className="w-full">
            View All Events
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TrendingTopics;