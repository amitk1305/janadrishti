import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ConstituencyMap = () => {
  const [selectedFilter, setSelectedFilter] = useState('all');

  const mapFilters = [
    { id: 'all', label: 'All Issues', count: 58, color: 'text-foreground' },
    { id: 'infrastructure', label: 'Infrastructure', count: 23, color: 'text-warning' },
    { id: 'healthcare', label: 'Healthcare', count: 12, color: 'text-destructive' },
    { id: 'education', label: 'Education', count: 8, color: 'text-accent' },
    { id: 'environment', label: 'Environment', count: 15, color: 'text-success' }
  ];

  const nearbyIssues = [
    {
      id: 1,
      title: "Pothole on MG Road",
      category: "Infrastructure",
      distance: "0.5 km",
      status: "Under Review",
      upvotes: 24,
      location: { lat: 19.1136, lng: 72.8697 }
    },
    {
      id: 2,
      title: "Water shortage in Complex",
      category: "Infrastructure", 
      distance: "0.8 km",
      status: "Acknowledged",
      upvotes: 18,
      location: { lat: 19.1150, lng: 72.8710 }
    },
    {
      id: 3,
      title: "Poor street lighting",
      category: "Safety",
      distance: "1.2 km", 
      status: "In Progress",
      upvotes: 31,
      location: { lat: 19.1120, lng: 72.8680 }
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Under Review':
        return 'bg-warning/10 text-warning';
      case 'Acknowledged':
        return 'bg-primary/10 text-primary';
      case 'In Progress':
        return 'bg-accent/10 text-accent';
      case 'Resolved':
        return 'bg-success/10 text-success';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  // Mock coordinates for Mumbai North West constituency
  const constituencyCenter = { lat: 19.1136, lng: 72.8697 };

  return (
    <div className="bg-card border border-border rounded-lg shadow-civic">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold text-lg text-foreground">
            Constituency Map
          </h3>
          <Button variant="outline" size="sm">
            <Icon name="Maximize2" size={16} className="mr-2" />
            Full Screen
          </Button>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-2">
          {mapFilters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setSelectedFilter(filter.id)}
              className={`px-3 py-1 text-xs rounded-full font-caption transition-civic ${
                selectedFilter === filter.id
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              {filter.label} ({filter.count})
            </button>
          ))}
        </div>
      </div>

      {/* Map Container */}
      <div className="relative">
        <div className="aspect-video bg-muted rounded-lg overflow-hidden">
          <iframe
            width="100%"
            height="100%"
            loading="lazy"
            title="Mumbai North West Constituency"
            referrerPolicy="no-referrer-when-downgrade"
            src={`https://www.google.com/maps?q=${constituencyCenter.lat},${constituencyCenter.lng}&z=14&output=embed`}
            className="border-0"
          />
        </div>

        {/* Map Overlay Controls */}
        <div className="absolute top-4 right-4 flex flex-col space-y-2">
          <Button variant="secondary" size="icon" className="shadow-civic">
            <Icon name="Plus" size={16} />
          </Button>
          <Button variant="secondary" size="icon" className="shadow-civic">
            <Icon name="Minus" size={16} />
          </Button>
          <Button variant="secondary" size="icon" className="shadow-civic">
            <Icon name="Navigation" size={16} />
          </Button>
        </div>

        {/* Legend */}
        <div className="absolute bottom-4 left-4 bg-card border border-border rounded-lg p-3 shadow-civic">
          <h4 className="font-body font-semibold text-foreground text-sm mb-2">Legend</h4>
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full bg-warning"></div>
              <span className="text-xs text-muted-foreground">Infrastructure</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full bg-destructive"></div>
              <span className="text-xs text-muted-foreground">Healthcare</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full bg-success"></div>
              <span className="text-xs text-muted-foreground">Environment</span>
            </div>
          </div>
        </div>
      </div>

      {/* Nearby Issues */}
      <div className="p-6 border-t border-border">
        <h4 className="font-body font-semibold text-foreground mb-3">Nearby Issues</h4>
        <div className="space-y-3">
          {nearbyIssues.map((issue) => (
            <div key={issue.id} className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-civic cursor-pointer">
              <div className="w-8 h-8 rounded-full bg-warning/10 flex items-center justify-center">
                <Icon name="MapPin" size={16} className="text-warning" />
              </div>
              <div className="flex-1">
                <h5 className="font-body font-medium text-foreground text-sm">{issue.title}</h5>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-xs text-muted-foreground">{issue.distance} away</span>
                  <span className="text-xs text-muted-foreground">•</span>
                  <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(issue.status)}`}>
                    {issue.status}
                  </span>
                </div>
              </div>
              <div className="flex items-center space-x-1">
                <Icon name="ArrowUp" size={12} className="text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{issue.upvotes}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t border-border">
          <Button variant="ghost" size="sm" className="w-full">
            View All Issues on Map
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ConstituencyMap;