import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ActivityFeed = () => {
  const [loadingMore, setLoadingMore] = useState(false);

  const activities = [
    {
      id: 1,
      type: 'representative_update',
      title: 'MP Sharma posted an update',
      content: `Pleased to announce the completion of the new flyover project at Andheri-Kurla Road. This infrastructure development will significantly reduce traffic congestion and improve connectivity for our constituents.\n\nThe project was completed 2 months ahead of schedule and within budget. Thank you to all citizens for your patience during construction.`,
      author: {
        name: 'Dr. Rajesh Sharma',
        position: 'Member of Parliament',
        avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      timestamp: '3 hours ago',
      engagement: {
        likes: 156,
        comments: 23,
        shares: 12
      },
      images: [
        'https://images.pexels.com/photos/2219024/pexels-photo-2219024.jpeg?auto=compress&cs=tinysrgb&w=400'
      ]
    },
    {
      id: 2,
      type: 'policy_discussion',
      title: 'New policy discussion started',
      content: `The Municipal Corporation is seeking public feedback on the proposed waste management policy for 2024. Key highlights include:\n\n• Mandatory waste segregation at source\n• Introduction of composting units in residential complexes\n• Plastic ban enforcement with penalties\n• Incentives for eco-friendly practices\n\nYour opinions matter! Join the discussion and help shape our city's environmental future.`,
      author: {
        name: 'Mumbai Municipal Corporation',position: 'Official Account',avatar: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      timestamp: '6 hours ago',
      engagement: {
        likes: 89,
        comments: 45,
        shares: 8
      },
      category: 'Environment'
    },
    {
      id: 3,
      type: 'community_issue',title: 'Community issue resolved',
      content: `Great news! The street lighting issue on SV Road has been resolved. Thanks to everyone who reported and supported this issue. The new LED lights have been installed and are now operational.\n\nThis is a perfect example of how community participation can drive positive change.`,
      author: {
        name: 'Priya Patel',position: 'Community Volunteer',avatar: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      timestamp: '1 day ago',
      engagement: {
        likes: 234,
        comments: 18,
        shares: 15
      },
      status: 'Resolved'
    },
    {
      id: 4,
      type: 'event_announcement',title: 'Upcoming town hall meeting',
      content: `Join us for a town hall meeting this Saturday at 10 AM at the Community Center, Andheri West. We'll discuss:\n\n• Upcoming infrastructure projects\n• Budget allocation for 2024\n• Q&A session with local representatives\n• Community feedback and suggestions\n\nRefreshments will be provided. Looking forward to seeing you there!`,
      author: {
        name: 'Andheri West Residents Association',
        position: 'Community Organization',
        avatar: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=400'
      },
      timestamp: '2 days ago',
      engagement: {
        likes: 67,
        comments: 12,
        shares: 25
      },
      eventDate: 'Dec 16, 2023'
    }
  ];

  const getActivityIcon = (type) => {
    switch (type) {
      case 'representative_update':
        return 'Users';
      case 'policy_discussion':
        return 'MessageSquare';
      case 'community_issue':
        return 'AlertTriangle';
      case 'event_announcement':
        return 'Calendar';
      default:
        return 'Bell';
    }
  };

  const getActivityColor = (type) => {
    switch (type) {
      case 'representative_update':
        return 'text-primary';
      case 'policy_discussion':
        return 'text-accent';
      case 'community_issue':
        return 'text-warning';
      case 'event_announcement':
        return 'text-success';
      default:
        return 'text-muted-foreground';
    }
  };

  const handleLoadMore = () => {
    setLoadingMore(true);
    // Simulate loading
    setTimeout(() => {
      setLoadingMore(false);
    }, 1500);
  };

  return (
    <div className="bg-card border border-border rounded-lg shadow-civic">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-semibold text-lg text-foreground">
            Civic Activity Feed
          </h3>
          <Button variant="ghost" size="sm">
            <Icon name="Filter" size={16} className="mr-2" />
            Filter
          </Button>
        </div>
      </div>

      <div className="divide-y divide-border">
        {activities.map((activity) => (
          <div key={activity.id} className="p-6 hover:bg-muted/30 transition-civic">
            <div className="flex items-start space-x-4">
              {/* Activity Icon */}
              <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                <Icon 
                  name={getActivityIcon(activity.type)} 
                  size={20} 
                  className={getActivityColor(activity.type)}
                />
              </div>

              <div className="flex-1 min-w-0">
                {/* Header */}
                <div className="flex items-center space-x-2 mb-2">
                  <div className="w-8 h-8 rounded-full overflow-hidden">
                    <Image 
                      src={activity.author.avatar}
                      alt={activity.author.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-body font-semibold text-foreground text-sm">
                      {activity.author.name}
                    </h4>
                    <p className="text-xs text-muted-foreground">{activity.author.position}</p>
                  </div>
                  <span className="text-xs text-muted-foreground">•</span>
                  <span className="text-xs text-muted-foreground">{activity.timestamp}</span>
                </div>

                {/* Content */}
                <div className="mb-4">
                  <h5 className="font-body font-medium text-foreground mb-2">{activity.title}</h5>
                  <p className="text-sm text-muted-foreground whitespace-pre-line">
                    {activity.content}
                  </p>
                  
                  {/* Status Badge */}
                  {activity.status && (
                    <span className="inline-block mt-2 px-2 py-1 bg-success/10 text-success text-xs rounded-full">
                      {activity.status}
                    </span>
                  )}

                  {/* Category Badge */}
                  {activity.category && (
                    <span className="inline-block mt-2 px-2 py-1 bg-accent/10 text-accent text-xs rounded-full">
                      {activity.category}
                    </span>
                  )}

                  {/* Event Date */}
                  {activity.eventDate && (
                    <div className="flex items-center mt-2 text-xs text-muted-foreground">
                      <Icon name="Calendar" size={12} className="mr-1" />
                      {activity.eventDate}
                    </div>
                  )}
                </div>

                {/* Images */}
                {activity.images && (
                  <div className="mb-4">
                    <div className="grid grid-cols-2 gap-2">
                      {activity.images.map((image, index) => (
                        <div key={index} className="aspect-video rounded-lg overflow-hidden">
                          <Image 
                            src={image}
                            alt={`Activity image ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Engagement */}
                <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                  <button className="flex items-center space-x-1 hover:text-foreground transition-civic">
                    <Icon name="Heart" size={16} />
                    <span>{activity.engagement.likes}</span>
                  </button>
                  <button className="flex items-center space-x-1 hover:text-foreground transition-civic">
                    <Icon name="MessageCircle" size={16} />
                    <span>{activity.engagement.comments}</span>
                  </button>
                  <button className="flex items-center space-x-1 hover:text-foreground transition-civic">
                    <Icon name="Share" size={16} />
                    <span>{activity.engagement.shares}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Load More */}
      <div className="p-6 border-t border-border text-center">
        <Button 
          variant="outline" 
          onClick={handleLoadMore}
          loading={loadingMore}
          disabled={loadingMore}
        >
          {loadingMore ? 'Loading...' : 'Load More Activities'}
        </Button>
      </div>
    </div>
  );
};

export default ActivityFeed;