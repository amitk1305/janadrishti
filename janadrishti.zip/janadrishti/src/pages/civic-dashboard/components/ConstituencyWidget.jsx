import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const ConstituencyWidget = () => {
  const constituencyData = {
    name: "Mumbai North West",
    state: "Maharashtra",
    pincode: "400067",
    population: "1,847,000",
    area: "32.5 sq km",
    lastElection: "2019",
    voterTurnout: "54.2%"
  };

  const currentRepresentative = {
    name: "Dr. Shrikant Shinde",
    party: "Shiv Sena",
    position: "Member of Parliament",
    photo: "https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=400",
    tenure: "2019-2024",
    rating: 4.2,
    totalRatings: 1247
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-civic">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-heading font-semibold text-lg text-foreground">
          Your Constituency
        </h3>
        <Icon name="MapPin" size={20} className="text-primary" />
      </div>

      {/* Constituency Info */}
      <div className="space-y-3 mb-6">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Constituency</span>
          <span className="font-body font-medium text-foreground">{constituencyData.name}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">State</span>
          <span className="font-body font-medium text-foreground">{constituencyData.state}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Population</span>
          <span className="font-body font-medium text-foreground">{constituencyData.population}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Voter Turnout (2019)</span>
          <span className="font-body font-medium text-foreground">{constituencyData.voterTurnout}</span>
        </div>
      </div>

      {/* Current Representative */}
      <div className="border-t border-border pt-4">
        <h4 className="font-body font-semibold text-foreground mb-3">Current Representative</h4>
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-full overflow-hidden">
            <Image 
              src={currentRepresentative.photo}
              alt={currentRepresentative.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex-1">
            <h5 className="font-body font-medium text-foreground">{currentRepresentative.name}</h5>
            <p className="text-sm text-muted-foreground">{currentRepresentative.party}</p>
            <div className="flex items-center space-x-2 mt-1">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Icon
                    key={i}
                    name="Star"
                    size={12}
                    className={i < Math.floor(currentRepresentative.rating) ? "text-warning fill-current" : "text-muted-foreground"}
                  />
                ))}
              </div>
              <span className="text-xs text-muted-foreground">
                {currentRepresentative.rating} ({currentRepresentative.totalRatings} ratings)
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConstituencyWidget;