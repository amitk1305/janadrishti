import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const IssuesOverview = () => {
  const issueStats = [
    {
      category: "Infrastructure",
      count: 23,
      icon: "Construction",
      color: "text-warning",
      bgColor: "bg-warning/10",
      trend: "+5"
    },
    {
      category: "Healthcare",
      count: 12,
      icon: "Heart",
      color: "text-destructive",
      bgColor: "bg-destructive/10",
      trend: "+2"
    },
    {
      category: "Education",
      count: 8,
      icon: "GraduationCap",
      color: "text-accent",
      bgColor: "bg-accent/10",
      trend: "+1"
    },
    {
      category: "Environment",
      count: 15,
      icon: "Leaf",
      color: "text-success",
      bgColor: "bg-success/10",
      trend: "+3"
    }
  ];

  const recentIssues = [
    {
      id: 1,
      title: "Pothole on MG Road causing traffic issues",
      category: "Infrastructure",
      location: "Andheri West",
      status: "Under Review",
      reportedBy: "Rajesh Kumar",
      timeAgo: "2 hours ago",
      upvotes: 24
    },
    {
      id: 2,
      title: "Water shortage in residential complex",
      category: "Infrastructure",
      location: "Malad East",
      status: "Acknowledged",
      reportedBy: "Priya Sharma",
      timeAgo: "5 hours ago",
      upvotes: 18
    },
    {
      id: 3,
      title: "Lack of proper lighting in park area",
      category: "Safety",
      location: "Borivali West",
      status: "In Progress",
      reportedBy: "Anonymous",
      timeAgo: "1 day ago",
      upvotes: 31
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Under Review':
        return 'bg-warning/10 text-warning';
      case 'Acknowledged':
        return 'bg-primary/10 text-primary';
      case 'In Progress':
        return 'bg-accent/10 text-accent';
      case 'Resolved':
        return 'bg-success/10 text-success';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-civic">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-heading font-semibold text-lg text-foreground">
          Local Issues Overview
        </h3>
        <Button variant="outline" size="sm">
          View All
        </Button>
      </div>

      {/* Issue Categories Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {issueStats.map((stat) => (
          <div key={stat.category} className="text-center">
            <div className={`w-12 h-12 rounded-full ${stat.bgColor} flex items-center justify-center mx-auto mb-2`}>
              <Icon name={stat.icon} size={20} className={stat.color} />
            </div>
            <div className="font-heading font-bold text-xl text-foreground">{stat.count}</div>
            <div className="text-xs text-muted-foreground">{stat.category}</div>
            <div className="text-xs text-success font-medium">+{stat.trend} this week</div>
          </div>
        ))}
      </div>

      {/* Recent Issues */}
      <div className="border-t border-border pt-4">
        <h4 className="font-body font-semibold text-foreground mb-3">Recent Issues</h4>
        <div className="space-y-3">
          {recentIssues.map((issue) => (
            <div key={issue.id} className="flex items-start space-x-3 p-3 bg-muted/50 rounded-lg hover:bg-muted transition-civic">
              <div className="flex-1">
                <h5 className="font-body font-medium text-foreground text-sm line-clamp-1">
                  {issue.title}
                </h5>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-xs text-muted-foreground">{issue.location}</span>
                  <span className="text-xs text-muted-foreground">•</span>
                  <span className="text-xs text-muted-foreground">{issue.timeAgo}</span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(issue.status)}`}>
                    {issue.status}
                  </span>
                  <div className="flex items-center space-x-1">
                    <Icon name="ArrowUp" size={12} className="text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{issue.upvotes}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default IssuesOverview;