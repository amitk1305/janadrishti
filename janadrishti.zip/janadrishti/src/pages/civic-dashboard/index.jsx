import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import Navigation from '../../components/ui/Navigation';
import Breadcrumb from '../../components/ui/Breadcrumb';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

// Import dashboard components
import ConstituencyWidget from './components/ConstituencyWidget';
import IssuesOverview from './components/IssuesOverview';
import ActivityFeed from './components/ActivityFeed';
import QuickActions from './components/QuickActions';
import TrendingTopics from './components/TrendingTopics';
import EngagementStats from './components/EngagementStats';
import ConstituencyMap from './components/ConstituencyMap';

const CivicDashboard = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  // Check for saved language preference on component mount
  useEffect(() => {
    const savedLanguage = localStorage.getItem('selectedLanguage');
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  // Handle pull-to-refresh functionality
  const handleRefresh = async () => {
    setIsRefreshing(true);
    // Simulate data refresh
    await new Promise(resolve => setTimeout(resolve, 1500));
    setLastUpdated(new Date());
    setIsRefreshing(false);
  };

  // Welcome message based on time of day
  const getWelcomeMessage = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const userName = "Rahul Sharma";

  return (
    <>
      <Helmet>
        <title>Civic Dashboard - Janadrishti</title>
        <meta name="description" content="Your personalized civic dashboard showing local issues, representative updates, and community engagement opportunities in your constituency." />
        <meta name="keywords" content="civic dashboard, local issues, political representatives, community engagement, Mumbai North West" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Header />
        <Navigation />
        
        {/* Main Content */}
        <main className="pt-16 lg:pt-30 pb-20 lg:pb-8">
          <div className="max-w-7xl mx-auto px-4 lg:px-6">
            <Breadcrumb />
            
            {/* Welcome Section */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h1 className="font-heading font-bold text-2xl lg:text-3xl text-foreground">
                    {getWelcomeMessage()}, {userName}
                  </h1>
                  <p className="text-muted-foreground mt-1">
                    Stay updated with your constituency's civic activities
                  </p>
                </div>
                
                {/* Refresh Button */}
                <div className="flex items-center space-x-3">
                  <div className="hidden lg:block text-sm text-muted-foreground">
                    Last updated: {lastUpdated.toLocaleTimeString()}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleRefresh}
                    loading={isRefreshing}
                    disabled={isRefreshing}
                  >
                    <Icon name="RefreshCw" size={16} className="mr-2" />
                    {isRefreshing ? 'Refreshing...' : 'Refresh'}
                  </Button>
                </div>
              </div>

              {/* Quick Stats Bar */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div className="bg-card border border-border rounded-lg p-4 text-center">
                  <div className="font-heading font-bold text-xl text-primary">58</div>
                  <div className="text-sm text-muted-foreground">Active Issues</div>
                </div>
                <div className="bg-card border border-border rounded-lg p-4 text-center">
                  <div className="font-heading font-bold text-xl text-success">23</div>
                  <div className="text-sm text-muted-foreground">Resolved</div>
                </div>
                <div className="bg-card border border-border rounded-lg p-4 text-center">
                  <div className="font-heading font-bold text-xl text-accent">156</div>
                  <div className="text-sm text-muted-foreground">Discussions</div>
                </div>
                <div className="bg-card border border-border rounded-lg p-4 text-center">
                  <div className="font-heading font-bold text-xl text-warning">5</div>
                  <div className="text-sm text-muted-foreground">Representatives</div>
                </div>
              </div>
            </div>

            {/* Dashboard Grid Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column - Main Content */}
              <div className="lg:col-span-8 space-y-6">
                {/* Top Row - Constituency & Issues */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <ConstituencyWidget />
                  <IssuesOverview />
                </div>

                {/* Quick Actions */}
                <QuickActions />

                {/* Activity Feed */}
                <ActivityFeed />

                {/* Constituency Map - Mobile */}
                <div className="lg:hidden">
                  <ConstituencyMap />
                </div>
              </div>

              {/* Right Column - Sidebar */}
              <div className="lg:col-span-4 space-y-6">
                {/* Trending Topics */}
                <TrendingTopics />

                {/* Engagement Stats */}
                <EngagementStats />

                {/* Constituency Map - Desktop */}
                <div className="hidden lg:block">
                  <ConstituencyMap />
                </div>
              </div>
            </div>

            {/* Mobile Pull-to-Refresh Indicator */}
            {isRefreshing && (
              <div className="fixed top-20 left-1/2 transform -translate-x-1/2 bg-primary text-primary-foreground px-4 py-2 rounded-full shadow-civic-lg z-50 lg:hidden">
                <div className="flex items-center space-x-2">
                  <Icon name="RefreshCw" size={16} className="animate-spin" />
                  <span className="text-sm font-medium">Refreshing...</span>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </>
  );
};

export default CivicDashboard;